#!/usr/bin/env python3
"""نشر Update.json v1.3.4 (code 11): محلي + المخزنان الحيان (PUT ×2) + تحقق"""
import json, urllib.request, hashlib, os

BINS = ["https://extendsclass.com/api/json-storage/bin/cbdaccd",
        "https://extendsclass.com/api/json-storage/bin/ddbcdcf"]
APK = "/home/z/my-project/AiPlusGLM/app/build/outputs/apk/release/app-release.apk"

sha = hashlib.sha256(open(APK, "rb").read()).hexdigest()

UPDATE = {
    "appName": "Ai Plus GLM",
    "developer": "مروان السيدى (Marwan Alsidi) — ليبيا 🇱🇾",
    "versionName": "1.3.4",
    "versionCode": 11,
    "minSupportedCode": 2,
    "apkUrl": "https://gofile.io/d/Aq1vzhGV",  # يُستبدل برابط v1.3.4 الجديد بعد الرفع
    "sha256": sha,
    "sizeBytes": os.path.getsize(APK),
    "releasedAt": "2026-10-29",
    "whatsNew": "إصلاح المظهر النهاري/الليلي للواجهة والأيقونات، ولغة التطبيق تغيّر كل النصوص فعلياً (9 لغات)، وأيقونة جديدة Ai مع كتب وأكواد من خارج وداخل، وخط Cairo الأنيق، وأيقونات مدوّرة للخدمات، وحماية خدمات قوقل، وفتح فوري للواجهة الرسمية.",
    "additions": [
        "🌍 لغة التطبيق تغيّر كل نصوص الواجهة فعلياً — ترجمة كاملة بـ 9 لغات (العربية 🇱🇾 والإنجليزية والفرنسية والإيطالية والروسية والتركية والصينية واليابانية والهندية) + ردود النموذج والنطق والإدخال الصوتي يتبعون اللغة",
        "🎨 أيقونة تطبيق جديدة فاخرة: كلمة Ai أمام كتاب مفتوح ولوحات أكواد وأبحاث — أيقونة تكيفية من خارج وداخل (خلفية + مقدمة + أحادية اللون لمظهر Material You)",
        "🔤 خط Cairo الأنيق متعدد الأوزان على كل واجهة التطبيق (عربي + لاتيني)",
        "✨ أيقونات مدوّرة احترافية جديدة لكل الخدمات والأدوات: شريط التنقل وأزرار المحادثة والإعدادات وحول",
        "🛡 خدمات قوقل للحماية: تحديث مزوّد الأمان تلقائياً عبر Google Play Services (ترقيع TLS/SSL) + إعدادات اللغة للنظام (API 33+)"
    ],
    "fixes": [
        "☀☾ إصلاح جذري لعدم تغيّر مظهر الواجهة والأيقونات بين النهار والليل: نظام ألوان موحّد يشتق نسخة نهارية/ليلية لكل مظر ويصبغ كل المكوّنات والأيقونات وشريط الحالة",
        "⚡ إصلاح بطء/تعذر فتح الواجهة الرسمية لنموذج GLM-5.3-Flash: WebView دائم يعاد استخدامه + تسخين مبكر عند الإقلاع + كاش ذكي + أولوية رسم قصوى + صفحة خطأ ودية مع إعادة محاولة"
    ],
    "changes": [
        "⚙️ رفع الإصدار إلى 1.3.4 (versionCode 11) — نفس توقيع الشهادة، التثبيت فوق كل الإصدارات السابقة مباشرة دون حذف"
    ],
    "notes": [
        "نفس شهادة التوقيع من v1.1.0 حتى v1.3.4 (CN=Marwan Alsidi)",
        "التحديث يُكتشف تلقائياً عبر المخزن الحي أو بزر «البحث عن تحديثات» في حول التطبيق"
    ]
}

payload = json.dumps(UPDATE, ensure_ascii=False, indent=2)
for p in ("/home/z/my-project/AiPlusGLM/Update.json",
          "/home/z/my-project/download/AiPlusGLM/Update.json"):
    with open(p, "w", encoding="utf-8") as f:
        f.write(payload)
print("local Update.json written (v1.3.4, code 11)")

for bin_url in BINS:
    req = urllib.request.Request(bin_url, data=payload.encode("utf-8"), method="PUT",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        res = json.loads(r.read().decode())
    with urllib.request.urlopen(bin_url, timeout=60) as r:
        back = json.loads(r.read().decode())
    ok = back.get("versionCode") == 11
    print(f"PUT {bin_url} -> status={res.get('status')} verify_code={back.get('versionCode')} {'OK' if ok else 'FAIL'}")
