#!/usr/bin/env python3
"""معالجة الأيقونة الجديدة v1.3.4 — Ai + كتب وأكواد وأبحاث (المتطلب ⑤⑥)
• أيقونة تكيفية adaptive من خارج وداخل: طبقة خلفية كاملة + طبقة أمامية بالمنطقة الآمنة + monochrome
• mipmaps قديمة بكل الكثافات (مربعة مستديرة + دائرية)
• icon-512.png لمتجر Play"""
from PIL import Image, ImageDraw, ImageFilter, ImageOps

RAW = "/home/z/my-project/tmp/icon_aiplus_raw.png"
RES = "/home/z/my-project/AiPlusGLM/app/src/main/res"
OUT512 = "/home/z/my-project/AiPlusGLM/icon-512.png"

img = Image.open(RAW).convert("RGBA")
W, H = img.size  # 1024

# ① قص الزجاجية الداخلية من الخلفية الرمادية (حدود الرسمة تقريباً 13%→88%)
crop = img.crop((int(W * 0.115), int(H * 0.135), int(W * 0.885), int(H * 0.895))).convert("RGBA")
crop = crop.resize((1024, 1024), Image.LANCZOS)

# استخراج الخلفية البنفسجية السادة من زوايا القصّة — لون طبقة الخلفية التكيفية
corner = crop.getpixel((18, 18))
bg_color = corner[:3]
print("لون الخلفية المستخرج:", bg_color)

# ── ② طبقة الخلفية التكيفية: نفس التصميم مكبّراً يملأ الكانفس بالكامل (من الخارج) ──
bg = crop.resize((1152, 1152), Image.LANCZOS)  # زوم 1.125 ليملأ حتى مع اقتصاص الشكل
left = (1152 - 1024) // 2
bg_layer = Image.new("RGBA", (1024, 1024), (*bg_color, 255))
# مركزية: قصّ من الزوم المكبّر
bg_canvas = Image.new("RGBA", (1080, 1080), (*bg_color, 255))
z = bg.crop((left, left, left + 1024, left + 1024)).resize((1080, 1080), Image.LANCZOS)
bg_canvas.alpha_composite(z)
bg_canvas = bg_canvas.resize((432, 432), Image.LANCZOS)
bg_canvas.save(f"{RES}/mipmap-xxxhdpi/ic_launcher_bg.png")

# ── ③ الطبقة الأمامية التكيفية: التصميم كاملاً داخل المنطقة الآمنة 66/108 (من الداخل) ──
FG_CANVAS = 432           # 108dp × 4 (xxxhdpi)
SAFE = 0.58               # التصميم يشغل 58% من الكانفس — يبقى آمناً داخل أي قناع
fg = Image.new("RGBA", (FG_CANVAS, FG_CANVAS), (0, 0, 0, 0))
inner = crop.resize((int(FG_CANVAS * SAFE), int(FG_CANVAS * SAFE)), Image.LANCZOS)
off = (FG_CANVAS - inner.size[0]) // 2
fg.alpha_composite(inner, (off, off))
fg.save(f"{RES}/mipmap-xxxhdpi/ic_launcher_fg.png")

# ── ④ monochrome للأيقونات الموضوعية (Material You) — سلويت أبيض ──
mono_src = inner.convert("RGBA")
alpha = mono_src.split()[3]
mono = Image.new("RGBA", (FG_CANVAS, FG_CANVAS), (0, 0, 0, 0))
white = Image.new("RGBA", inner.size, (255, 255, 255, 255))
white.putalpha(alpha)
mono.alpha_composite(white, (off, off))
mono.save(f"{RES}/mipmap-xxxhdpi/ic_launcher_mono.png")

# ── ⑤ mipmaps قديمة بكل الكثافات ──
def rounded(im, radius_ratio):
    size = im.size[0]
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=int(size * radius_ratio), fill=255)
    out = im.copy()
    out.putalpha(mask)
    return out

def circle(im):
    size = im.size[0]
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.ellipse([0, 0, size - 1, size - 1], fill=255)
    out = im.copy()
    out.putalpha(mask)
    return out

densities = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
full = crop  # التصميم الكامل (سيُقنّع)
for dpi, px in densities.items():
    base = full.resize((px, px), Image.LANCZOS)
    rounded(base, 0.22).save(f"{RES}/mipmap-{dpi}/ic_launcher.png")
    circle(base).save(f"{RES}/mipmap-{dpi}/ic_launcher_round.png")

# ── ⑥ أيقونة متجر Play 512 ──
full.resize((512, 512), Image.LANCZOS).save(OUT512)
# نسخة للطبقة الأمامية/الخلفية بكثافات إضافية شائعة (xxhdpi مثلاً ليست إلزامية للتكيفية)
print("تمت معالجة الأيقونة لكل الكثافات ✓")
