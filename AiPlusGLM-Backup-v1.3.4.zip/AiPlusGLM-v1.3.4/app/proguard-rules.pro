-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class com.marwan.aiplusglm.** { *; }

# خدمات Google Play — مزود الأمان (ProviderInstaller)
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**
