package com.marwan.aiplusglm.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.marwan.aiplusglm.data.AppLanguage
import com.marwan.aiplusglm.data.LocalS
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.ui.theme.BgPattern
import com.marwan.aiplusglm.ui.theme.DisplayMode
import com.marwan.aiplusglm.ui.theme.Themes
import com.marwan.aiplusglm.vm.AppViewModel

/**
 * الإعدادات (v1.3.4):
 * ① خانة «المظهر» — قائمة مخصصة تتوسع وتنغلق تضم المظاهر الثمانية وأنماط الخلفية
 *    + وضع العرض نهاري/ليلي/تلقائي — كل الألوان الآن من ثيم واحد متماسك (إصلاح النهار/الليل)
 * ② خانة «لغة التطبيق» — قائمة منفصلة تتوسع وتنطوي بـ 9 لغات كل لغة بعلمها (المتطلب ② v1.3.4)
 * ③ مركز الأذونات الحقيقية — الست صلاحيات المطلوبة بأزرار طلب فعّالة
 * ④ زر رجوع في الأعلى + تفضيلات المحادثة
 */
@Composable
fun SettingsScreen(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color,
    thinking: Boolean,
    tts: Boolean,
    onBack: () -> Unit
) {
    val s = LocalS.current
    val scroll = rememberScrollState()
    val selectedThemeId by vm.themeId.collectAsState()
    val selectedPatternId by vm.patternId.collectAsState()
    val displayMode by vm.displayMode.collectAsState()
    val currentLanguage by vm.appLanguage.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(horizontal = 14.dp)
            .padding(bottom = 90.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        // رأس الشاشة مع زر الرجوع
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, s.back, tint = theme.textPrimaryColor)
            }
            Text(s.settingsTitle, color = theme.textPrimaryColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))

        // ═══════════ خانة لغة التطبيق — قائمة منفصلة تتوسع وتنطوي (المتطلب ② v1.3.4) ═══════════
        var langOpen by remember { mutableStateOf(false) }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.72f))
                .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { langOpen = !langOpen }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // الكرة الأرضية بلون المظهر
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Translate, null, tint = accent, modifier = Modifier.size(21.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.appLanguage, color = theme.textPrimaryColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(s.appLanguageDesc, color = theme.textSecondaryColor, fontSize = 11.5.sp, lineHeight = 16.sp)
                }
                // اللغة الحالية بعلمها على رأس الخانة
                Text(
                    "${currentLanguage.flag} ${currentLanguage.nativeName}",
                    color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(8.dp))
                Icon(
                    if (langOpen) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    "expand", tint = accent, modifier = Modifier.size(24.dp)
                )
            }

            AnimatedVisibility(
                visible = langOpen,
                enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                exit = shrinkVertically(tween(220)) + fadeOut(tween(180))
            ) {
                Column(Modifier.padding(horizontal = 10.dp).padding(bottom = 12.dp)) {
                    Text(
                        s.langApplied,
                        color = theme.textSecondaryColor, fontSize = 10.5.sp, lineHeight = 15.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                    Spacer(Modifier.height(4.dp))
                    // اللغات التسع — كل لغة بعلمها واسمها الأصلي (المتطلب: كل لغة أمامها العلم المناسب)
                    AppLanguage.entries.forEach { lang ->
                        val selected = currentLanguage == lang
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(if (selected) accent.copy(alpha = 0.14f) else theme.surfaceColor.copy(alpha = 0.65f))
                                .border(
                                    1.dp,
                                    if (selected) accent else theme.borderColor,
                                    RoundedCornerShape(13.dp)
                                )
                                .clickable { vm.setAppLanguage(lang) }
                                .padding(horizontal = 13.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(lang.flag, fontSize = 21.sp)
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    lang.nativeName,
                                    color = if (selected) accent else theme.textPrimaryColor,
                                    fontSize = 14.sp, fontWeight = FontWeight.Bold
                                )
                                Text(
                                    if (selected) s.langSelected else lang.id.uppercase(),
                                    color = theme.textSecondaryColor, fontSize = 9.5.sp
                                )
                            }
                            if (selected) {
                                Icon(Icons.Rounded.CheckCircle, null, tint = accent, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ═══════════ خانة المظهر — قائمة تتوسع وتنغلق (المتطلب ② v1.3.0) ═══════════
        var appearanceOpen by remember { mutableStateOf(false) }

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.72f))
                .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            // رأس القائمة — يعرض المظهر الحالي ووضع العرض دائماً
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { appearanceOpen = !appearanceOpen }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // عيّنة المظهر الحالي
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Themes.byId(selectedThemeId).bgColorTop, Themes.byId(selectedThemeId).bgColorBottom)
                            )
                        )
                        .border(1.dp, theme.borderColor, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(13.dp).background(Themes.byId(selectedThemeId).accentColor, CircleShape))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.appearance, color = theme.textPrimaryColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${Themes.byId(selectedThemeId).nameAr} · ${displayModeLabel(displayMode, s)}",
                        color = theme.textSecondaryColor, fontSize = 11.5.sp
                    )
                }
                Icon(
                    if (appearanceOpen) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    "expand", tint = accent, modifier = Modifier.size(24.dp)
                )
            }

            // محتوى القائمة — يتوسع وينغلق بحركة سلسة
            AnimatedVisibility(
                visible = appearanceOpen,
                enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                exit = shrinkVertically(tween(220)) + fadeOut(tween(180))
            ) {
                Column(Modifier.padding(horizontal = 14.dp).padding(bottom = 14.dp)) {
                    // وضع العرض: تلقائي / نهاري / ليلي
                    Text(s.displayMode, color = theme.textPrimaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        DisplayMode.entries.forEach { m ->
                            val selected = displayMode == m
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(if (selected) accent.copy(alpha = 0.2f) else theme.surfaceColor.copy(alpha = 0.6f))
                                    .border(1.dp, if (selected) accent else theme.borderColor, RoundedCornerShape(11.dp))
                                    .clickable { vm.setDisplayMode(m) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) { Text(displayModeLabel(m, s), color = if (selected) accent else theme.textSecondaryColor, fontSize = 11.5.sp) }
                        }
                    }

                    Spacer(Modifier.height(13.dp))
                    Text(s.themes8, color = theme.textPrimaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))

                    // شبكة المظاهر — المظهر النشط يُعلّم بعلامة صح
                    for (row in Themes.all.chunked(4)) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            row.forEach { t ->
                                ThemeCard(t, selectedThemeId == t.id, Modifier.weight(1f)) { vm.setTheme(t.id) }
                            }
                            if (row.size < 4) repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(s.bgPattern, color = theme.textPrimaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BgPattern.entries.forEach { p ->
                            val selected = selectedPatternId == p.id
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) accent.copy(alpha = 0.2f) else theme.surfaceColor.copy(alpha = 0.6f))
                                    .border(1.dp, if (selected) accent else theme.borderColor, RoundedCornerShape(10.dp))
                                    .clickable { vm.setPattern(p.id) }
                                    .padding(horizontal = 10.dp, vertical = 7.dp)
                            ) { Text(patternLabel(p, s), color = if (selected) accent else theme.textSecondaryColor, fontSize = 11.sp) }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(s.connection, color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        // بطاقة حالة الاتصال — ألوان الحالة من نظام موحد يعمل في الوضعين
        val connected by vm.endpointReady.collectAsState()
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (connected) OkColor.copy(alpha = 0.1f) else WarnColor.copy(alpha = 0.12f))
                .border(1.dp, if (connected) OkColor.copy(alpha = 0.5f) else WarnColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                .clickable { vm.openSetup() }
                .padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (connected) Icons.Rounded.CloudDone else Icons.Rounded.CloudOff,
                null,
                tint = if (connected) OkColor else WarnColor,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (connected) s.connected else s.notConnected,
                    color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    if (connected) s.connectedHint else s.notConnectedHint,
                    color = theme.textSecondaryColor, fontSize = 11.sp
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(s.chatPrefs, color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        SettingSwitch(
            icon = { Icon(Icons.Rounded.Psychology, null, tint = accent, modifier = Modifier.size(20.dp)) },
            title = s.thinkingDeep,
            subtitle = s.deepThinkingDesc,
            checked = thinking,
            accent = accent, theme = theme
        ) { vm.setThinking(it) }

        Spacer(Modifier.height(8.dp))
        SettingSwitch(
            icon = { Icon(Icons.Rounded.VolumeUp, null, tint = accent, modifier = Modifier.size(20.dp)) },
            title = s.ttsTitle,
            subtitle = s.ttsDesc,
            checked = tts,
            accent = accent, theme = theme
        ) { vm.setTts(it) }

        Spacer(Modifier.height(20.dp))
        // ═══════════ خانة الأذونات والصلاحيات — قائمة منفصلة تتوسع وتنطوي ═══════════
        var permsOpen by remember { mutableStateOf(false) }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.72f))
                .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { permsOpen = !permsOpen }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Security, null, tint = accent, modifier = Modifier.size(21.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.permissions, color = theme.textPrimaryColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(s.permissionsDesc, color = theme.textSecondaryColor, fontSize = 11.5.sp, lineHeight = 16.sp)
                }
                Icon(
                    if (permsOpen) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    "expand", tint = accent, modifier = Modifier.size(24.dp)
                )
            }

            AnimatedVisibility(
                visible = permsOpen,
                enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                exit = shrinkVertically(tween(220)) + fadeOut(tween(180))
            ) {
                Column(Modifier.padding(horizontal = 10.dp).padding(bottom = 12.dp)) {
                    PermissionCenter(theme, accent)
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            s.privacyNote,
            color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 16.sp
        )
    }
}

// ═════════════════════ تسميات مترجمة ── الأوضاع والأنماط ═════════════════════

@Composable
private fun displayModeLabel(m: DisplayMode, s: com.marwan.aiplusglm.data.AppStrings): String = when (m) {
    DisplayMode.AUTO -> "◐ ${s.modeAuto}"
    DisplayMode.LIGHT -> "☀ ${s.modeLight}"
    DisplayMode.DARK -> "☾ ${s.modeDark}"
}

@Composable
private fun patternLabel(p: BgPattern, s: com.marwan.aiplusglm.data.AppStrings): String = when (p) {
    BgPattern.NONE -> s.patNone
    BgPattern.DOTS -> s.patDots
    BgPattern.WAVES -> s.patWaves
    BgPattern.GLOW -> s.patGlow
    BgPattern.GRID -> s.patGrid
}

// ═════════════════════ ألوان الحالة الموحدة — تعمل في الوضعين النهاري والليلي ═════════════════════
private val OkColor = Color(0xFF2FBF71)
private val WarnColor = Color(0xFFFF7043)

// ═════════════════════ مركز الأذونات الحقيقية ═════════════════════

@Composable
private fun PermissionCenter(theme: AppTheme, accent: Color) {
    val s = LocalS.current
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }

    fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    // ── ① الإشعارات ──
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    PermissionRow(
        icon = Icons.Rounded.Notifications, accent = accent, theme = theme,
        title = s.permNotif,
        subtitle = {
            val prefs = context.getSharedPreferences("aiplus_permissions", Context.MODE_PRIVATE)
            val connectedListener = prefs.getBoolean("notif_listener_connected", false)
            val lastTitle = prefs.getString("notif_last_title", null)
            val count = prefs.getInt("notif_count", 0)
            when {
                connectedListener && lastTitle != null ->
                    String.format(s.permNotifOn, lastTitle.take(28), count)
                connectedListener -> s.permNotifReady
                else -> s.permNotifOff
            }
        },
        grantedState = { Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS) },
        buttonText = { if (Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)) s.btnNotifListener else s.btnRequest }
    ) {
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            runCatching {
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    // ── ② حالة الاتصال بالإنترنت (WiFi أو بيانات الهاتف) ──
    PermissionRow(
        icon = Icons.Rounded.Wifi, accent = accent, theme = theme,
        title = s.permNet,
        subtitle = {
            val connText = connectionTypeText(context, s)
            String.format(s.permNetAuto, connText)
        },
        grantedState = { granted(Manifest.permission.ACCESS_NETWORK_STATE) },
        buttonText = { s.btnRefresh }
    ) { refresh++ }

    // ── ③ قراءة الملفات والتعديل عليها ──
    val allFiles = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh++ }
    val mediaPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    PermissionRow(
        icon = Icons.Rounded.FolderOpen, accent = accent, theme = theme,
        title = s.permFiles,
        subtitle = {
            if (Build.VERSION.SDK_INT >= 30) {
                val manage = runCatching { android.os.Environment.isExternalStorageManager() }.getOrDefault(false)
                if (manage) s.permFilesFull else s.permFilesOff
            } else if (granted(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                s.permFilesLegacy
            } else s.permFilesAsk
        },
        grantedState = {
            (Build.VERSION.SDK_INT >= 30 && runCatching { android.os.Environment.isExternalStorageManager() }.getOrDefault(false)) ||
                granted(Manifest.permission.READ_EXTERNAL_STORAGE)
        },
        buttonText = { s.btnGrant }
    ) {
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                allFiles.launch(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }.onFailure {
                runCatching { allFiles.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        } else {
            mediaPerms.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }

    // ── ④ رفع ملفات الهاتف ──
    val uploadTest = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        refresh++
        if (uri != null) {
            android.widget.Toast.makeText(context, s.toastUploadOk, android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    PermissionRow(
        icon = Icons.Rounded.UploadFile, accent = accent, theme = theme,
        title = s.permUpload,
        subtitle = { s.permUploadDesc },
        grantedState = { true },
        buttonText = { s.btnTryUpload }
    ) { uploadTest.launch("*/*") }

    // ── ⑤ الكاميرا والصوت والتسجيل ──
    val avPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    PermissionRow(
        icon = Icons.Rounded.PhotoCamera, accent = accent, theme = theme,
        title = s.permCamAudio,
        subtitle = {
            val cam = granted(Manifest.permission.CAMERA)
            val mic = granted(Manifest.permission.RECORD_AUDIO)
            when {
                cam && mic -> s.permCamMicOk
                cam -> s.permCamOnly
                mic -> s.permMicOnly
                else -> s.permCamMicOff
            }
        },
        grantedState = { granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO) },
        buttonText = { if (granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO)) s.btnGranted else s.btnBoth }
    ) {
        if (!(granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO))) {
            avPerms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    // ── ⑥ موقع GPS الدقيق ──
    val locationPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    PermissionRow(
        icon = Icons.Rounded.LocationOn, accent = accent, theme = theme,
        title = s.permGps,
        subtitle = {
            if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
                val loc = lastKnownLocation(context)
                if (loc != null) String.format(s.permGpsCoords, "%.4f, %.4f".format(loc.first, loc.second))
                else s.permGpsHint
            } else s.permGpsOff
        },
        grantedState = { granted(Manifest.permission.ACCESS_FINE_LOCATION) },
        buttonText = { if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) s.btnUpdateLoc else s.btnRequest }
    ) { locationPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }

    key(refresh) { Spacer(Modifier.height(2.dp)) }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    accent: Color,
    theme: AppTheme,
    title: String,
    subtitle: @Composable () -> String,
    grantedState: () -> Boolean,
    buttonText: () -> String,
    onClick: () -> Unit
) {
    val s = LocalS.current
    val ok = grantedState()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(
                1.dp,
                if (ok) OkColor.copy(alpha = 0.45f) else theme.borderColor,
                RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(36.dp).background(
                if (ok) OkColor.copy(alpha = 0.15f) else accent.copy(alpha = 0.15f),
                CircleShape
            ),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (ok) Icons.Rounded.CheckCircle else icon, null,
                tint = if (ok) OkColor else accent, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            Text(subtitle(), color = theme.textSecondaryColor, fontSize = 10.5.sp, lineHeight = 14.sp)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (ok) OkColor.copy(alpha = 0.14f) else accent.copy(alpha = 0.16f))
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = 7.dp)
        ) {
            Text(buttonText(), color = if (ok) OkColor else accent, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ═════════════════════ أدوات مساعدة للأذونات ═════════════════════

/** نوع الاتصال الحالي: WiFi أو بيانات الهاتف أو غير متصل (مترجم حسب لغة التطبيق) */
private fun connectionTypeText(context: Context, s: com.marwan.aiplusglm.data.AppStrings): String = runCatching {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    when {
        caps == null -> s.connOff
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> s.connWifi
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> s.connCell
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> s.connEth
        else -> s.connOn
    }
}.getOrDefault(s.connUnknown)

/** آخر موقع معروف من GPS أو الشبكة */
private fun lastKnownLocation(context: Context): Pair<Double, Double>? = runCatching {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) return@runCatching null
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val gps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
    val net = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
    val loc = gps ?: net ?: return@runCatching null
    loc.latitude to loc.longitude
}.getOrNull()

// ═════════════════════ عناصر واجهة عامة ═════════════════════

@Composable
private fun ThemeCard(t: AppTheme, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) t.accentColor else t.borderColor,
                RoundedCornerShape(13.dp)
            )
            .background(if (selected) t.accentColor.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Brush.verticalGradient(listOf(Color(t.bgTop), Color(t.bgBottom))))
        ) {
            Box(
                Modifier.align(Alignment.Center).size(14.dp).background(Color(t.accent), CircleShape)
            )
            // علامة صح على المظهر النشط
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(3.dp)
                        .size(15.dp)
                        .background(t.accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.CheckCircle, null,
                        tint = Color.White, modifier = Modifier.size(11.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            t.nameAr,
            color = if (selected) t.accentColor else Color(t.textPrimary),
            fontSize = 10.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun SettingSwitch(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    checked: Boolean,
    accent: Color,
    theme: AppTheme,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent,
                uncheckedThumbColor = theme.textSecondaryColor,
                uncheckedTrackColor = theme.borderColor
            )
        )
    }
}
