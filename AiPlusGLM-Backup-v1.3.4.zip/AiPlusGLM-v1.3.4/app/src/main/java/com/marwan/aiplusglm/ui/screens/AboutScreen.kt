package com.marwan.aiplusglm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.marwan.aiplusglm.data.LocalS
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.vm.AppViewModel

/**
 * حول التطبيق (v1.3.4):
 * ① الشعار الجديد + النص التعريفي تحت الشعار
 * ② خانة «الترخيص» — نافذة منبثقة بنص رخصة MIT المدمجة داخل التطبيق
 * ③ زر «البحث عن تحديثات» في الأسفل + زر رجوع في الأعلى
 * كل النصوص مترجمة بـ 9 لغات (v1.3.4)
 */
@Composable
fun AboutScreen(
    theme: AppTheme,
    accent: Color,
    versionName: String,
    updateState: AppViewModel.UpdateState,
    onCheckUpdates: () -> Unit,
    onOpenUrl: (String) -> Unit,
    onBack: () -> Unit
) {
    val s = LocalS.current
    val context = LocalContext.current
    var showLicense by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            // زر الرجوع في الأعلى — يعود للمحادثة تلقائياً
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, s.back, tint = theme.textPrimaryColor)
                }
                Spacer(Modifier.width(2.dp))
                Text(s.aboutTitle, color = theme.textPrimaryColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }

            // الشعار — نفس هوية أيقونة التطبيق الجديدة (Ai + كتب وأكواد)
            Box(
                Modifier
                    .size(88.dp)
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.5f))), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("Ai", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
                Text(
                    "📚",
                    fontSize = 17.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 9.dp)
                )
            }

            Spacer(Modifier.height(14.dp))
            Text("Ai Plus GLM", color = theme.textPrimaryColor, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text(
                "v$versionName", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                s.tagline,
                color = theme.textSecondaryColor, fontSize = 13.sp, lineHeight = 20.sp, textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(22.dp))

            // بطاقة المطور
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(theme.surfaceColor.copy(alpha = 0.75f))
                    .border(1.dp, theme.borderColor, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text(s.developer, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(s.devName, color = theme.textPrimaryColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(s.devCountry, color = theme.textSecondaryColor, fontSize = 13.sp)
            }

            Spacer(Modifier.height(12.dp))

            LinkRow(Icons.Rounded.Language, s.linkSite, s.linkSiteDesc, theme, accent) { onOpenUrl("https://chat.z.ai") }
            LinkRow(Icons.Rounded.Code, s.linkDocs, s.linkDocsDesc, theme, accent) { onOpenUrl("https://docs.z.ai") }
            LinkRow(Icons.Rounded.Star, s.linkModels, s.linkModelsDesc, theme, accent) { onOpenUrl("https://docs.z.ai/guides/llm/glm-4.6") }

            // ═══ خانة الترخيص ═══
            LinkRow(
                Icons.Rounded.Description,
                s.license,
                s.licenseDesc,
                theme, accent
            ) { showLicense = true }

            Spacer(Modifier.height(18.dp))

            // ═══ زر البحث عن تحديثات — في الأسفل ═══
            Text(s.updates, color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.6f))))
                    .clickable(onClick = onCheckUpdates)
                    .padding(vertical = 13.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (updateState is AppViewModel.UpdateState.Loading) s.checking else s.checkUpdates,
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
                    )
                }
            }

            // بطاقات حالة الفحص
            when (updateState) {
                is AppViewModel.UpdateState.UpToDate ->
                    StatusCard(s.upToDate, OkColor, theme)
                is AppViewModel.UpdateState.Available ->
                    StatusCard(
                        String.format(s.updateAvailable, updateState.info.versionName),
                        accent, theme
                    )
                is AppViewModel.UpdateState.Failed ->
                    StatusCard(String.format(s.updateFailed, updateState.message), WarnColor, theme)
                else -> {}
            }

            Spacer(Modifier.height(16.dp))
            Text(
                s.mitFooter,
                color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.Center
            )
        }
    }

    // ═══ نافذة الترخيص المنبثقة — نص MIT المدمج ═══
    if (showLicense) {
        LicenseDialog(theme, accent) { showLicense = false }
    }
}

private val OkColor = Color(0xFF2FBF71)
private val WarnColor = Color(0xFFFF7043)

/** نافذة عرض نص رخصة MIT المدمجة في أصول التطبيق */
@Composable
private fun LicenseDialog(theme: AppTheme, accent: Color, onDismiss: () -> Unit) {
    val s = LocalS.current
    val context = LocalContext.current
    val licenseText = remember {
        runCatching {
            context.assets.open("license.txt").bufferedReader().use { it.readText() }
        }.getOrDefault("MIT License\n\nCopyright (c) 2026 Marwan Alsidi — Libya")
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(theme.surfaceColor)
                .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .background(accent.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Gavel, null, tint = accent, modifier = Modifier.size(21.dp)) }
                Spacer(Modifier.width(11.dp))
                Column {
                    Text(s.mitTitle, color = theme.textPrimaryColor, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(s.mitSub, color = theme.textSecondaryColor, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                licenseText,
                color = theme.textSecondaryColor,
                fontSize = 11.5.sp,
                lineHeight = 17.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState())
                    .clip(RoundedCornerShape(12.dp))
                    .background(theme.bgColorTop.copy(alpha = 0.5f))
                    .border(1.dp, theme.borderColor, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            )
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.65f))))
                    .clickable(onClick = onDismiss)
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) { Text(s.close, color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun StatusCard(text: String, color: Color, theme: AppTheme) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 13.dp, vertical = 10.dp)
    ) { Text(text, color = color, fontSize = 12.sp, lineHeight = 17.sp) }
}

@Composable
private fun LinkRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    theme: AppTheme,
    accent: Color,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(36.dp)
                .background(accent.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = theme.textSecondaryColor, fontSize = 11.sp)
        }
    }
}
