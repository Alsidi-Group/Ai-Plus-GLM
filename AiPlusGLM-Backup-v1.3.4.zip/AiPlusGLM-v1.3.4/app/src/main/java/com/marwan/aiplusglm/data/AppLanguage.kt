package com.marwan.aiplusglm.data

import java.util.Locale

/**
 * لغات التطبيق التسع (v1.3.4) — كل لغة بعلمها واسمها الأصلي:
 * العربية بعلم ليبيا 🇱🇾 بطلب المطور، ثم الإنجليزية والفرنسية والإيطالية
 * والروسية والتركية والصينية واليابانية والهندية.
 *
 * اللغة المختارة تتحكم في: نصوص الواجهة كلها + لغة ردود النموذج (system prompt)
 * + لغة النطق الصوتي TTS + لغة الإدخال الصوتي.
 */
enum class AppLanguage(
    val id: String,
    val nativeName: String,
    val flag: String,
    val tag: String,          // BCP-47 — للنظام وTTS والإدخال الصوتي
    val rtl: Boolean = false
) {
    ARABIC("ar", "العربية", "🇱🇾", "ar", rtl = true),
    ENGLISH("en", "English", "🇬🇧", "en"),
    FRENCH("fr", "Français", "🇫🇷", "fr"),
    ITALIAN("it", "Italiano", "🇮🇹", "it"),
    RUSSIAN("ru", "Русский", "🇷🇺", "ru"),
    TURKISH("tr", "Türkçe", "🇹🇷", "tr"),
    CHINESE("zh", "中文", "🇨🇳", "zh"),
    JAPANESE("ja", "日本語", "🇯🇵", "ja"),
    HINDI("hi", "हिन्दी", "🇮🇳", "hi");

    val locale: Locale get() = Locale.forLanguageTag(tag)

    companion object {
        fun byId(id: String): AppLanguage = entries.firstOrNull { it.id == id } ?: ARABIC
    }
}

/**
 * تعليمات لغة الردود — تُحقن كرسالة نظام في طلب GLM ليتبع النموذج اللغة المختارة
 * حتى لو كتب المستخدم سؤاله بلغة أخرى (المتطلب: الردود تتبع لغة التطبيق).
 */
fun AppLanguage.systemPrompt(): String = when (this) {
    AppLanguage.ARABIC ->
        "أجب دائماً وبشكل كامل باللغة العربية الفصحى المبسطة بلهجة ودّية، مهما كانت لغة سؤال المستخدم. الأرقام والتقنيات تُكتب بالعربية مع إبقاء أسماء التقنيات بلغتها الأصلية."
    AppLanguage.ENGLISH ->
        "Always respond fully in English regardless of the language of the user's question. Keep technical names in their original form."
    AppLanguage.FRENCH ->
        "Réponds toujours intégralement en français, quelle que soit la langue de la question de l'utilisateur. Conserve les noms techniques dans leur forme d'origine."
    AppLanguage.ITALIAN ->
        "Rispondi sempre completamente in italiano, indipendentemente dalla lingua della domanda dell'utente. Mantieni i nomi tecnici nella loro forma originale."
    AppLanguage.RUSSIAN ->
        "Всегда отвечай полностью на русском языке, независимо от языка вопроса пользователя. Технические названия сохраняй в оригинале."
    AppLanguage.TURKISH ->
        "Kullanıcının sorusunun dili ne olursa olsun her zaman tamamen Türkçe yanıtla. Teknik adları orijinal biçimlerinde koru."
    AppLanguage.CHINESE ->
        "无论用户使用什么语言提问，请始终用简体中文完整回答。技术名称保留原文。"
    AppLanguage.JAPANESE ->
        "ユーザーの質問の言語に関わらず、常に日本語で完全に回答してください。技術用語の名称は原文のまま保ってください。"
    AppLanguage.HINDI ->
        "उपयोगकर्ता के प्रश्न की भाषा चाहे जो हो, सदा पूर्ण रूप से हिन्दी में उत्तर दें। तकनीकी नामों को मूल रूप में रखें।"
}
