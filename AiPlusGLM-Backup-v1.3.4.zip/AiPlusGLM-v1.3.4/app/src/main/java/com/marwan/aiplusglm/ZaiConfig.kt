package com.marwan.aiplusglm

/**
 * ═══════════════════════════════════════════════════════════════
 *  الإعدادات المدمجة — كل شيء جاهز داخل التطبيق بدون خانات إعدادات
 * ═══════════════════════════════════════════════════════════════
 *
 *  أولويات الاتصال (من الأعلى للأدنى):
 *    ① السيرفر الوسيط المدمج وقت البناء  EMBEDDED_PROXY_URL
 *    ② المفتاح المدمج وقت البناء          EMBEDDED_API_KEY
 *    ③ السيرفر الوسيط المحفوظ على الجهاز  (شاشة التفعيل — KeyVault)
 *    ④ المفتاح المحفوظ على الجهاز          (شاشة التفعيل — KeyVault)
 *
 *  إن كان كل شيء فارغاً تظهر شاشة التفعيل الأنيقة مرة واحدة،
 *  ويُحفظ ما يدخله المستخدم على جهازه في مساحة التطبيق الخاصة.
 */
object ZaiConfig {

    /** 🔴 الصق مفتاح API هنا ليكون مدمجاً داخل التطبيق (يُلغي شاشة التفعيل نهائياً) */
    const val EMBEDDED_API_KEY = ""

    /** 🔵 أو الصق رابط السيرفر الوسيط هنا (الأفضل والأكثر أماناً) */
    const val EMBEDDED_PROXY_URL = ""

    /** رابط الحصول على مفتاح مجاني — يُفتح من شاشة التفعيل */
    const val GET_KEY_URL = "https://z.ai/model-api"

    /** نقطة نهاية Z.ai الرسمية — الدفع حسب الاستخدام (GLM-4.5-Flash مجاني عليها) */
    const val OFFICIAL_BASE_URL = "https://api.z.ai/api/paas/v4"

    /** نقطة نهاية اشتراك «خطة البرمجة GLM Coding Plan» — مفتاح الاشتراك يعمل عليها فقط */
    const val CODING_BASE_URL = "https://api.z.ai/api/coding/paas/v4"

    /** رابط شحن الحساب — يُفتح من بطاقة حلول الرصيد */
    const val RECHARGE_URL = "https://z.ai/model-api"

    /**
     * رابط ملف فحص التحديثات — مخزن حي قابل للتحديث الدائم (v1.3.2):
     * السابق كان ملفاً جامداً على pomf لا يمكن تعديل محتواه، فكانت النسخ المثبتة
     * تقرأ إصدارها نفسها للأبد — لهذا كان زر «البحث عن تحديثات» لا يعطي نتائج.
     * الآن: تحديث المحتوى يتم بطلب PUT على نفس الرابط وكل النسخ المثبتة تراه فوراً.
     */
    const val UPDATE_JSON_URL = "https://extendsclass.com/api/json-storage/bin/cbdaccd"

    /** مصدر احتياطي حي بنفس المحتوى — يُستخدم تلقائياً إن تعذر المصدر الأول */
    const val UPDATE_JSON_URL_FALLBACK = "https://extendsclass.com/api/json-storage/bin/ddbcdcf"

    /** رابط الموقع الرسمي (يُفتح في شاشة الويب المدمجة) */
    const val OFFICIAL_SITE = "https://chat.z.ai"
    const val OFFICIAL_DOCS = "https://docs.z.ai"

    /**
     * يحدد قاعدة الاتصال الفعلية تلقائياً:
     * وسيط مدمج ← مفتاح مدمج ← وسيط محفوظ ← مفتاح محفوظ ← لا شيء
     *
     * @param codingMode عند تفعيله يُوجّه المفتاح المحفوظ إلى نقطة نهاية
     *        خطة البرمجة (مفاتيح الاشتراك لا تعمل على النقطة العادية
     *        وتُرجع خطأ «Insufficient balance or no resource package»).
     */
    fun resolveEndpoint(
        savedKey: String = "",
        savedProxy: String = "",
        codingMode: Boolean = false
    ): Endpoint {
        val proxy = EMBEDDED_PROXY_URL.trim().ifBlank { savedProxy.trim() }.trimEnd('/')
        if (proxy.isNotEmpty()) {
            val base = if (proxy.contains("/api/")) proxy else "$proxy/api/paas/v4"
            return Endpoint(base, "", true)
        }
        val key = EMBEDDED_API_KEY.trim().ifBlank { savedKey.trim() }
        if (key.isNotEmpty()) {
            val base = if (codingMode) CODING_BASE_URL else OFFICIAL_BASE_URL
            return Endpoint(base, key, true)
        }
        return Endpoint(OFFICIAL_BASE_URL, "", false)
    }

    data class Endpoint(val baseUrl: String, val apiKey: String, val ready: Boolean)

    /** سلسلة مصادر ملف التحديثات — أول مصدر ينجح يُعتمد */
    fun updateSources(): List<String> =
        listOf(UPDATE_JSON_URL, UPDATE_JSON_URL_FALLBACK).filter { it.isNotBlank() }
}
