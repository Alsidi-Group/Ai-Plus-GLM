package com.marwan.aiplusglm.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.marwan.aiplusglm.R
import kotlin.math.sin

// ═════════════ خط التطبيق — Cairo المتغيّر الأنيق (المتطلب: خط أجمل) ═════════════
// خط عربي/لاتيني فاخر يدعم 11 وزناً — نربط الأوزان المهمة بمحور wght للخط المتغيّر
@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
val CairoFamily = FontFamily(
    Font(R.font.cairo_variable, weight = FontWeight.Normal,
        variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.cairo_variable, weight = FontWeight.Medium,
        variationSettings = FontVariation.Settings(FontVariation.weight(500))),
    Font(R.font.cairo_variable, weight = FontWeight.SemiBold,
        variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.cairo_variable, weight = FontWeight.Bold,
        variationSettings = FontVariation.Settings(FontVariation.weight(700))),
    Font(R.font.cairo_variable, weight = FontWeight.ExtraBold,
        variationSettings = FontVariation.Settings(FontVariation.weight(800))),
    Font(R.font.cairo_variable, weight = FontWeight.Black,
        variationSettings = FontVariation.Settings(FontVariation.weight(900)))
)

/** طباعة التطبيق — Cairo على كل الأنماط (v1.3.4: الإصلاح الجذري لبلاغ «غيّر نوع الخط») */
val AppTypography = Typography(
    displayLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Black, fontSize = 40.sp),
    displayMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Black, fontSize = 32.sp),
    displaySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 28.sp),
    headlineLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 24.sp),
    headlineMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 20.sp),
    headlineSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 17.sp),
    titleLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 19.sp),
    titleMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 15.sp),
    titleSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 13.sp),
    bodyLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 15.sp),
    bodyMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 13.5.sp),
    bodySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 11.5.sp),
    labelLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 13.sp),
    labelMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 11.5.sp),
    labelSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
)

/** ثيم كامل قابل للاختيار — 8 مظاهر فاخرة (المتطلب: العديد من المظاهر والخلفيات) */
data class AppTheme(
    val id: String,
    val nameAr: String,
    val isDark: Boolean,
    val bgTop: Long,
    val bgBottom: Long,
    val surface: Long,
    val surfaceBorder: Long,
    val textPrimary: Long,
    val textSecondary: Long,
    val accent: Long
) {
    val bgColorTop: Color get() = Color(bgTop)
    val bgColorBottom: Color get() = Color(bgBottom)
    val surfaceColor: Color get() = Color(surface)
    val borderColor: Color get() = Color(surfaceBorder)
    val textPrimaryColor: Color get() = Color(textPrimary)
    val textSecondaryColor: Color get() = Color(textSecondary)
    val accentColor: Color get() = Color(accent)
}

object Themes {
    val all = listOf(
        AppTheme("midnight", "منتصف الليل", true,
            0xFF0B1026, 0xFF1A1040, 0xFF161B35, 0xFF2A3157, 0xFFF3F5FF, 0xFF9BA3C7, 0xFF7C6BFF),
        AppTheme("libya", "ليبيا الليلية", true,
            0xFF071A12, 0xFF0E2A1C, 0xFF0F241A, 0xFF1E4030, 0xFFF0FFF7, 0xFF93B8A5, 0xFF00C896),
        AppTheme("aurora", "الشفق القطبي", true,
            0xFF04121F, 0xFF0A2E3D, 0xFF0B2233, 0xFF14405A, 0xFFEAFBFF, 0xFF8FB4C7, 0xFF00E5C7),
        AppTheme("ocean", "المحيط الأزرق", true,
            0xFF041428, 0xFF0A2A52, 0xFF0C2440, 0xFF16406E, 0xFFEFF7FF, 0xFF8FB0D0, 0xFF4E9BFF),
        AppTheme("royal", "الملكي البنفسجي", true,
            0xFF14051F, 0xFF2A0A45, 0xFF200A33, 0xFF3D1560, 0xFFF8F0FF, 0xFFB99BC9, 0xFFB36BFF),
        AppTheme("sunset", "الغروب الذهبي", true,
            0xFF1F0A05, 0xFF3D150A, 0xFF2E1009, 0xFF55241A, 0xFFFFF5EF, 0xFFCFA791, 0xFFFF8A50),
        AppTheme("soft", "الفاتح الناعم", false,
            0xFFF7F8FC, 0xFFEBEEF7, 0xFFFFFFFF, 0xFFE2E6F0, 0xFF141A2E, 0xFF5D6784, 0xFF5B5BFF),
        AppTheme("amoled", "الأسود الفاخر", true,
            0xFF000000, 0xFF0A0A0F, 0xFF101014, 0xFF23232B, 0xFFF5F5F7, 0xFF8E8E9A, 0xFF00D4AA)
    )

    fun byId(id: String): AppTheme = all.firstOrNull { it.id == id } ?: all[0]
}

// ═════════════ وضع العرض: نهاري ☀ / ليلي ☾ / تلقائي ◐ حسب النظام ═════════════

enum class DisplayMode(val id: String, val label: String) {
    AUTO("auto", "تلقائي ◐"),
    LIGHT("light", "نهاري ☀"),
    DARK("dark", "ليلي ☾");

    companion object {
        fun byId(id: String): DisplayMode = entries.firstOrNull { it.id == id } ?: AUTO
    }
}

// ═════════════ اشتقاق نسخة نهارية/ليلية لكل مظهر ═════════════
// (الإصلاح الجذري لبلاغ «المظهر لا يعمل مع النهار أو التلقائي»: كانت الأوضاع تفرض
//  مظهراً فاتحاً واحداً فقط فبدا وكأن 7 من 8 اختيارات لا تفعل شيئاً.
//  الآن يُشتق من كل مظر نسخ فاتح وداكن متسقان مع هوية لونه — فكل اختيار يعمل في كل الأوضاع)

private fun lightenTo(c: Color, f: Float): Color = Color(
    red = c.red + (1f - c.red) * f,
    green = c.green + (1f - c.green) * f,
    blue = c.blue + (1f - c.blue) * f
)

private fun darkenTo(c: Color, f: Float): Color =
    Color(red = c.red * f, green = c.green * f, blue = c.blue * f)

private fun argbOf(c: Color): Long {
    val r = (c.red * 255f).toInt().coerceIn(0, 255)
    val g = (c.green * 255f).toInt().coerceIn(0, 255)
    val b = (c.blue * 255f).toInt().coerceIn(0, 255)
    return 0xFF000000L or (r.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()
}

/** نسخة نهارية مشتقة — تحافظ على هوية لون المظر الداكن وتفتّح خلفياته */
private fun deriveLight(t: AppTheme): AppTheme = AppTheme(
    id = "${t.id}__day",
    nameAr = t.nameAr,
    isDark = false,
    bgTop = argbOf(lightenTo(t.bgColorTop, 0.86f)),
    bgBottom = argbOf(lightenTo(t.bgColorBottom, 0.82f)),
    surface = argbOf(lightenTo(t.surfaceColor, 0.90f)),
    surfaceBorder = argbOf(lightenTo(t.surfaceColor, 0.55f)),
    textPrimary = 0xFF141A2E,
    textSecondary = 0xFF5D6784,
    accent = argbOf(darkenTo(t.accentColor, 0.84f))
)

/** نسخة ليلية مشتقة — تحافظ على هوية لون المظر الفاتح وتعمّق خلفياته */
private fun deriveDark(t: AppTheme): AppTheme = AppTheme(
    id = "${t.id}__night",
    nameAr = t.nameAr,
    isDark = true,
    bgTop = argbOf(darkenTo(t.bgColorTop, 0.16f)),
    bgBottom = argbOf(darkenTo(t.bgColorBottom, 0.20f)),
    surface = argbOf(darkenTo(t.surfaceColor, 0.22f)),
    surfaceBorder = argbOf(darkenTo(t.surfaceColor, 0.60f)),
    textPrimary = 0xFFF3F5FF,
    textSecondary = 0xFF9BA3C7,
    accent = argbOf(lightenTo(t.accentColor, 0.16f))
)

private val lightCache = HashMap<String, AppTheme>()
private val darkCache = HashMap<String, AppTheme>()

/** النسخة الفعالة للوضع النهاري — المظاهر الفاتحة تعود كما هي والداكنة تُشتق منها نسخة نهارية */
fun AppTheme.effectiveLight(): AppTheme = if (!isDark) this else lightCache.getOrPut(id) { deriveLight(this) }

/** النسخة الفعالة للوضع الليلي — المظاهر الداكنة تعود كما هي والفاتحة تُشتق منها نسخة ليلية */
fun AppTheme.effectiveDark(): AppTheme = if (isDark) this else darkCache.getOrPut(id) { deriveDark(this) }

/**
 * يحسم المظهر الفعلي المطبق — كل اختيار يعمل الآن في كل الأوضاع:
 * • نهاري ☀ — النسخة النهارية للمظهر المختار
 * • ليلي ☾ — النسخة الليلية للمظهر المختار
 * • تلقائي ◐ — يتبع النظام: نهاري على النظام الفاتح وليلي على الداكن (بنفس هوية اللون)
 */
fun resolveTheme(selectedId: String, mode: DisplayMode, systemDark: Boolean): AppTheme {
    val selected = Themes.byId(selectedId)
    return when (mode) {
        DisplayMode.AUTO -> if (systemDark) selected.effectiveDark() else selected.effectiveLight()
        DisplayMode.LIGHT -> selected.effectiveLight()
        DisplayMode.DARK -> selected.effectiveDark()
    }
}

// ═════════════ جسر MaterialTheme — يُلزم كل مكونات النظام بلون المظهر ═════════════
// (الإصلاح الجذري لبلاغ «المظهر لا يُطبق على الأزرار وحقول الكتابة»: مكونات Material3
//  كانت تتبع colorScheme الافتراضي لأن الثيم المخصص لم يكن مربوطاً بها)

fun AppTheme.toColorScheme(accent: Color): ColorScheme {
    val primary = accent
    val isDark = this.isDark
    val base = if (isDark) darkColorScheme() else lightColorScheme()
    return base.copy(
        primary = primary,
        onPrimary = Color.White,
        primaryContainer = primary.copy(alpha = 0.22f),
        onPrimaryContainer = textPrimaryColor,
        secondary = accentColor,
        onSecondary = Color.White,
        secondaryContainer = accentColor.copy(alpha = 0.18f),
        onSecondaryContainer = textPrimaryColor,
        tertiary = accentColor,
        background = bgColorBottom,
        onBackground = textPrimaryColor,
        surface = surfaceColor,
        onSurface = textPrimaryColor,
        surfaceVariant = surfaceColor,
        onSurfaceVariant = textSecondaryColor,
        surfaceTint = Color.Transparent,
        outline = borderColor,
        outlineVariant = borderColor.copy(alpha = 0.6f),
        error = Color(0xFFFF7043),
        onError = Color.White,
        errorContainer = Color(0xFF4A1F1F),
        onErrorContainer = Color(0xFFFFB4AB),
        inverseSurface = if (isDark) Color(0xFFF3F5FF) else Color(0xFF161B35),
        inverseOnSurface = if (isDark) Color(0xFF161B35) else Color(0xFFF3F5FF)
    )
}

/** أنماط الخلفية الزخرفية */
enum class BgPattern(val id: String, val nameAr: String) {
    NONE("none", "بدون"),
    DOTS("dots", "نقاط شبكية"),
    WAVES("waves", "أمواج حريرية"),
    GLOW("glow", "هالات متوهجة"),
    GRID("grid", "شبكة هندسية");

    companion object { fun byId(id: String): BgPattern = entries.firstOrNull { it.id == id } ?: NONE }
}

/** خلفية التطبيق: تدرج + نمط زخرفي مرسوم برمجياً */
@Composable
fun ThemedBackground(
    theme: AppTheme,
    pattern: BgPattern,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Box(modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(listOf(theme.bgColorTop, theme.bgColorBottom)))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val a = accent.copy(alpha = if (theme.isDark) 0.16f else 0.20f)
            when (pattern) {
                BgPattern.NONE -> {}
                BgPattern.DOTS -> {
                    val step = 46f
                    var y = 0f
                    var row = 0
                    while (y < size.height) {
                        var x = if (row % 2 == 0) 0f else step / 2
                        while (x < size.width) {
                            drawCircle(color = a, radius = 2.2f, center = Offset(x, y))
                            x += step
                        }
                        y += step; row++
                    }
                }
                BgPattern.WAVES -> {
                    for (i in 0 until 7) {
                        val amp = 42f + i * 14f
                        val yBase = size.height * (0.18f + i * 0.11f)
                        val path = Path()
                        var x = 0f
                        path.moveTo(0f, yBase)
                        while (x <= size.width) {
                            path.lineTo(x, yBase + sin(x / 160f + i) * amp)
                            x += 18f
                        }
                        drawPath(path, color = a.copy(alpha = 0.05f + i * 0.012f), style = Stroke(width = 1.6f))
                    }
                }
                BgPattern.GLOW -> {
                    val r = size.width * 0.55f
                    drawCircle(accent.copy(alpha = 0.10f), r * 0.9f, Offset(size.width * 0.15f, size.height * 0.12f))
                    drawCircle(theme.bgColorBottom.copy(alpha = 0.0f), 1f)
                    drawCircle(Color(0xFF7C6BFF).copy(alpha = 0.08f), r, Offset(size.width * 0.9f, size.height * 0.3f))
                    drawCircle(a, r * 0.7f, Offset(size.width * 0.4f, size.height * 0.85f))
                }
                BgPattern.GRID -> {
                    val step = 64f
                    var y = 0f
                    while (y < size.height) {
                        drawLine(a.copy(alpha = 0.35f), Offset(0f, y), Offset(size.width, y), 1f)
                        y += step
                    }
                    var x = 0f
                    while (x < size.width) {
                        drawLine(a.copy(alpha = 0.35f), Offset(x, 0f), Offset(x, size.height), 1f)
                        x += step
                    }
                }
            }
        }
    }
}
