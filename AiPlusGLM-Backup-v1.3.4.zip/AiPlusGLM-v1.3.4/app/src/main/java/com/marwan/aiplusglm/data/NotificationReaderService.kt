package com.marwan.aiplusglm.data

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.SharedPreferences

/**
 * خدمة قراءة إشعارات النظام — تُمنح من إعدادات النظام
 * (الإعدادات ← الأذونات ← قراءة الإشعارات ← Ai Plus GLM)
 *
 * عند منحها تسجّل آخر إشعار وصل وعُدّته داخل تفضيلات التطبيق،
 * لتعرضه شاشة الأذونات كإثبات حي أن الصلاحية تعمل فعلاً.
 */
class NotificationReaderService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        runCatching {
            val extras = sbn?.notification?.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            if (title.isBlank() && text.isBlank()) return
            if (sbn.packageName == packageName) return // تجاهل إشعارات التطبيق نفسه

            prefs().edit()
                .putLong("notif_last_time", System.currentTimeMillis())
                .putString("notif_last_title", title.ifBlank { "إشعار" })
                .putString("notif_last_text", text.take(90))
                .putInt("notif_count", prefs().getInt("notif_count", 0) + 1)
                .apply()
        }
    }

    override fun onListenerConnected() {
        runCatching { prefs().edit().putBoolean("notif_listener_connected", true).apply() }
    }

    override fun onListenerDisconnected() {
        runCatching { prefs().edit().putBoolean("notif_listener_connected", false).apply() }
    }

    private fun prefs(): SharedPreferences =
        getSharedPreferences("aiplus_permissions", MODE_PRIVATE)
}
