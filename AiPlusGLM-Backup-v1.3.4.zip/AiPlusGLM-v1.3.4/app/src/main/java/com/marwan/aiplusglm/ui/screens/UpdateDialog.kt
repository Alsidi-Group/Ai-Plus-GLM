package com.marwan.aiplusglm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.marwan.aiplusglm.data.LocalS
import com.marwan.aiplusglm.data.ZaiClient
import com.marwan.aiplusglm.ui.theme.AppTheme

/**
 * نافذة التحديث المنسقة — تظهر تلقائياً عند وجود إصدار أحدث:
 * شعار التطبيق المتوهج في الأعلى، وتحته «ما الجديد في هذا الإصدار» مقسماً:
 * ✨ إضافات جديدة • 🛠 الإصلاحات • 🔄 التغييرات — كل النصوص مترجمة (v1.3.4)
 */
@Composable
fun UpdateDialog(
    info: ZaiClient.UpdateInfo,
    theme: AppTheme,
    accent: Color,
    onDismiss: () -> Unit
) {
    val s = LocalS.current
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(theme.surfaceColor)
                .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            // الشعار المتوهج
            Box(
                Modifier
                    .size(64.dp)
                    .align(Alignment.CenterHorizontally)
                    .background(
                        Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.55f))),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) { Text("Ai", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black) }

            Spacer(Modifier.height(10.dp))
            Text(
                String.format(s.updateTitle, info.versionName),
                color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Text(
                s.whatsNew,
                color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(Modifier.height(14.dp))

            Column(
                Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
            ) {
                if (info.additions.isNotEmpty()) {
                    UpdateSection(s.secAdditions, info.additions, accent, theme)
                }
                if (info.fixes.isNotEmpty()) {
                    UpdateSection(s.secFixes, info.fixes, Color(0xFF4CAF50), theme)
                }
                if (info.changes.isNotEmpty()) {
                    UpdateSection(s.secChanges, info.changes, Color(0xFFFFB300), theme)
                }
                if (info.whatsNew.isNotBlank() && info.additions.isEmpty() && info.fixes.isEmpty() && info.changes.isEmpty()) {
                    Text(info.whatsNew, color = theme.textSecondaryColor, fontSize = 12.5.sp, lineHeight = 19.sp)
                }
            }

            Spacer(Modifier.height(16.dp))

            // زرا التحميل واللاحقاً
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                if (info.apkUrl.isNotBlank()) {
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(13.dp))
                            .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.65f))))
                            .clickable {
                                runCatching {
                                    context.startActivity(
                                        android.content.Intent(
                                            android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse(info.apkUrl)
                                        ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                }
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Download, null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(s.downloadUpdate, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Box(
                    Modifier
                        .weight(if (info.apkUrl.isNotBlank()) 0.6f else 1f)
                        .clip(RoundedCornerShape(13.dp))
                        .background(theme.borderColor.copy(alpha = 0.35f))
                        .clickable(onClick = onDismiss)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text(s.later, color = theme.textSecondaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun UpdateSection(title: String, items: List<String>, color: Color, theme: AppTheme) {
    Column(Modifier.padding(bottom = 12.dp)) {
        Text(title, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        items.forEach { item ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text("•", color = color, fontSize = 12.sp)
                Spacer(Modifier.width(7.dp))
                Text(item, color = theme.textSecondaryColor, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
    }
}
