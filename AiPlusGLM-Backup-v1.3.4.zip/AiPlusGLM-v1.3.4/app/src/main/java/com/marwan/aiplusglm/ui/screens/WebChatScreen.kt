package com.marwan.aiplusglm.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.marwan.aiplusglm.data.LocalS
import com.marwan.aiplusglm.ui.theme.AppTheme

/**
 * حاضنة WebView الدائمة (v1.3.3 + تحسينات v1.3.4) — الإصلاح الجذري لبطء فتح
 * الواجهة الرسمية لنموذج GLM-5.3-Flash:
 * • WebView واحد يُنشأ مرة واحدة ويُعاد استخدامه عند كل فتح — الدخول الثاني فوري
 * • الجلسة والكوكيز محفوظة — لا فقدان للمحادثة عند التنقل بين الشاشات
 * • الإعدادات السريعة: كاش افتراضي + أولوية رسم قصوى + تحميل متزامن أسرع
 * • إيقاف الصوت والفيديو تلقائياً عند الخروج دون فقدان الجلسة
 * • صفحة خطأ ودية مع زر إعادة المحاولة عند فشل الشبكة
 * • التدمير النهائي فقط في MainActivity.onDestroy
 */
object WebChatHolder {
    @Volatile
    private var webView: WebView? = null

    /** يجهز الكوكيز ومحرك الويب مبكراً عند إقلاع التطبيق — يقلل زمن أول فتح */
    fun warmup(context: android.content.Context) {
        runCatching {
            Thread {
                runCatching {
                    CookieManager.getInstance().setAcceptCookie(true)
                    WebView(context.applicationContext) // يهيّئ مزود WebView في خيط خلفي ثم يُهدم فوراً
                        .destroy()
                }
            }.start()
        }
    }

    /** الوصول للـ WebView المحفوظ — لمعرفة تاريخ الرجوع من أزرار الواجهة */
    val current: WebView? get() = webView

    /** يستعيد WebView المحفوظ أو ينشئ جديداً مُهيّأً بالكامل */
    fun obtain(activity: Activity): WebView {
        webView?.let { return it }
        val wv = WebView(activity)
        configure(wv)
        webView = wv
        return wv
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(wv: WebView) = with(wv.settings) {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        loadWithOverviewMode = true
        useWideViewPort = true
        builtInZoomControls = false
        mediaPlaybackRequiresUserGesture = false
        cacheMode = WebSettings.LOAD_DEFAULT // كاش افتراضي — إعادة فتح أسرع بلا إعادة تحميل كل الموارد
        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        userAgentString =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        // تسريع: safe browsing يفحص كل مورد ويبطئ الفتح — الموقع موثوق (chat.z.ai)
        runCatching { setSafeBrowsingEnabled(false) }
        // أولوية قصوى لمحرك الرسم — لا يجمد أثناء التمرير السريع
        runCatching {
            val m = WebSettings::class.java.getMethod(
                "setRendererPriorityPolicy",
                Int::class.javaPrimitiveType, Boolean::class.javaPrimitiveType
            )
            m.invoke(wv, 1 /* RENDERER_PRIORITY_IMPORTANT */, false)
        }
        // جلسة مشتركة دائمة
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
    }

    /** إيقاف الصوت والفيديو عند مغادرة الشاشة — دون فقدان الجلسة */
    fun pause() {
        webView?.runCatching {
            onPause()
            pauseTimers()
        }
    }

    /** استئناف عند العودة للشاشة */
    fun resume() {
        webView?.runCatching {
            resumeTimers()
            onResume()
        }
    }

    /** إعادة تحميل الصفحة (زر التحديث / إعادة المحاولة) */
    fun reload() {
        runCatching { webView?.reload() }
    }

    /** تدمير نهائي — من MainActivity.onDestroy فقط */
    fun destroy() {
        runCatching {
            webView?.stopLoading()
            webView?.loadUrl("about:blank")
            webView?.onPause()
            webView?.destroy()
        }
        webView = null
    }
}

/**
 * الواجهة الرسمية لموقع Z.ai (chat.z.ai) داخل التطبيق — v1.3.4
 * تعمل بلا مفتاح API ولا رصيد: المحادثة من الموقع الرسمي مباشرة.
 *
 * • WebView دائم يعاد استخدامه (WebChatHolder) — فتح فوري بلا بطء
 * • دعم رفع الملفات والصور من واجهة الموقع (onShowFileChooser)
 * • شريط تقدم + مؤشر تحميل مركزي + صفحة خطأ ودية مع إعادة محاولة
 * • الروابط الخارجية تفتح في متصفح الجهاز — مواقع Z.ai تبقى داخل التطبيق
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebChatScreen(url: String, title: String, theme: AppTheme, accent: Color, onBack: () -> Unit) {
    val context = LocalContext.current
    val s = LocalS.current
    var progress by remember { mutableStateOf(0) }
    var pageReady by remember { mutableStateOf(false) }
    var loadFailed by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf(url) }
    var reloadKey by remember { mutableStateOf(0) }

    // رفع الملفات والصور من واجهة الموقع نفسها
    var fileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val fileChooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uris = if (result.resultCode == Activity.RESULT_OK) {
            android.webkit.WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        } else null
        fileCallback?.onReceiveValue(uris ?: arrayOf())
        fileCallback = null
    }

    // زر النظام للرجوع: يرجع داخل تاريخ الموقع أولاً ثم يخرج من الشاشة
    BackHandler(enabled = true) {
        val wv = WebChatHolder.current
        if (wv != null && wv.canGoBack()) wv.goBack() else onBack()
    }

    // إيقاف الصوت عند الخروج واستئنافه عند العودة — دون فقدان الجلسة
    DisposableEffect(Unit) {
        WebChatHolder.resume()
        onDispose { WebChatHolder.pause() }
    }

    Column(Modifier.fillMaxSize()) {
        // الشريط العلوي: رجوع + العنوان + تحديث + فتح في المتصفح
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.85f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                val wv = WebChatHolder.current
                if (wv != null && wv.canGoBack()) wv.goBack() else onBack()
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back, tint = theme.textPrimaryColor)
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(s.wcSubtitle, color = accent, fontSize = 10.sp)
            }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable {
                        loadFailed = false
                        pageReady = false
                        progress = 0
                        WebChatHolder.reload()
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Refresh, s.wcRefresh, tint = theme.textSecondaryColor, modifier = Modifier.size(19.dp)) }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.OpenInNew, s.wcOpenExternal, tint = theme.textSecondaryColor, modifier = Modifier.size(18.dp)) }
        }

        // شريط التقدم
        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = accent,
                trackColor = Color.Transparent
            )
        }

        Box(Modifier.fillMaxSize()) {
            // key(reloadKey): عند انهيار محرك الرسم يعاد بناء العرض بWebView نظيف جديد
            key(reloadKey) {
            AndroidView(
                factory = { ctx ->
                    val targetUrl = url
                    WebChatHolder.obtain(ctx as Activity).apply {
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                val u = request.url.toString()
                                return if (u.contains("z.ai") || u.contains("bigmodel.cn")) {
                                    false // مواقع Z.ai تبقى داخل التطبيق
                                } else {
                                    runCatching { // الروابط الخارجية تفتح في المتصفح
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                    }
                                    true
                                }
                            }

                            override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, u, favicon)
                                pageReady = false
                                loadFailed = false
                            }

                            override fun onPageFinished(view: WebView, u: String) {
                                canGoBack = view.canGoBack()
                                currentUrl = u
                                if (!loadFailed) pageReady = true
                            }

                            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                                if (request.isForMainFrame) {
                                    loadFailed = true
                                    pageReady = false
                                }
                            }

                            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                                // انهيار محرك الرسم — إعادة بناء نظيفة بدل شاشة بيضاء ميتة
                                runCatching { view.destroy() }
                                WebChatHolder.destroy()
                                loadFailed = true
                                reloadKey++
                                return true
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                progress = newProgress
                            }

                            override fun onShowFileChooser(
                                view: WebView?,
                                callback: ValueCallback<Array<Uri>>,
                                params: FileChooserParams
                            ): Boolean {
                                fileCallback = callback
                                runCatching {
                                    fileChooser.launch(params.createIntent())
                                }.onFailure {
                                    fileCallback?.onReceiveValue(arrayOf())
                                    fileCallback = null
                                }
                                return true
                            }
                        }

                        val cur = url
                        if (targetUrl.isNotBlank() && (cur == null || cur == "about:blank" || cur.isBlank())) loadUrl(targetUrl)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            }

            // مؤشر التحميل المركزي — يختفي فور جاهزية الصفحة
            if (!pageReady && !loadFailed) {
                Column(
                    Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = accent, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(14.dp))
                    Text(s.wcLoading, color = theme.textSecondaryColor, fontSize = 13.sp)
                }
            }

            // صفحة الخطأ الودية — مع زر إعادة المحاولة
            if (loadFailed) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .background(theme.bgColorBottom.copy(alpha = 0.96f))
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("📡", fontSize = 44.sp)
                    Spacer(Modifier.height(14.dp))
                    Text(s.wcErrorTitle, color = theme.textPrimaryColor, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        s.wcErrorBody, color = theme.textSecondaryColor,
                        fontSize = 12.5.sp, lineHeight = 19.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(20.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.6f))))
                            .clickable {
                                loadFailed = false
                                pageReady = false
                                progress = 0
                                WebChatHolder.reload()
                            }
                            .padding(horizontal = 26.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Refresh, null, tint = Color.White, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(s.wcRetry, color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

