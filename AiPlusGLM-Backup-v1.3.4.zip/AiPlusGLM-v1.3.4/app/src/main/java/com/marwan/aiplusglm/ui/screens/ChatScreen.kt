package com.marwan.aiplusglm.ui.screens

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marwan.aiplusglm.data.Attachment
import com.marwan.aiplusglm.data.ChatMessage
import com.marwan.aiplusglm.data.GlmModel
import com.marwan.aiplusglm.data.LocalS
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.vm.AppViewModel
import kotlinx.coroutines.launch
import java.io.File

/** شاشة المحادثة الفورية — نص + صوت + كاميرا + مرفقات + بث حي + تمرير ذكي */
@Composable
fun ChatScreen(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color,
    model: GlmModel,
    onOpenModels: () -> Unit
) {
    val messages by vm.messages.collectAsState()
    val isStreaming by vm.isStreaming.collectAsState()
    val liveContent by vm.liveContent.collectAsState()
    val liveReasoning by vm.liveReasoning.collectAsState()
    val hasStarted by vm.hasStartedChat.collectAsState()
    val balanceHelp by vm.balanceHelp.collectAsState()
    val lastConversation by vm.lastConversation.collectAsState()

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // ═══════════ حرية التمرير الكاملة (الإصلاح الجذري لبلاغ «الإجبار على متابعة الكتابة») ═══════════
    var follow by remember { mutableStateOf(true) }

    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { interaction ->
            when (interaction) {
                is DragInteraction.Start -> follow = false // المستخدم سحب — الشاشة ملكه
                is DragInteraction.Stop, is DragInteraction.Cancel -> {
                    val li = listState.layoutInfo
                    val lastVisible = li.visibleItemsInfo.lastOrNull()?.index ?: -1
                    if (li.totalItemsCount <= 1 || lastVisible >= li.totalItemsCount - 1) follow = true
                }
            }
        }
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.canScrollForward }.collect { canForward ->
            if (!canForward) follow = true
        }
    }

    LaunchedEffect(messages.size, liveContent.length, liveReasoning.length) {
        if (!follow) return@LaunchedEffect
        if (messages.isEmpty() && liveContent.isEmpty() && liveReasoning.isEmpty()) return@LaunchedEffect
        runCatching {
            val lastIndex = (messages.size + if (isStreaming) 1 else 0) - 1
            if (lastIndex >= 0) listState.scrollToItem(lastIndex)
        }
    }

    val itemCount = messages.size + if (isStreaming) 1 else 0
    val notAtBottom by remember {
        derivedStateOf {
            val li = listState.layoutInfo
            val lastVisible = li.visibleItemsInfo.lastOrNull()?.index ?: -1
            li.totalItemsCount > 1 && lastVisible < li.totalItemsCount - 1
        }
    }

    Column(Modifier.fillMaxSize()) {
        ActiveModelBar(model, accent, theme, onOpenModels)

        LastConversationBar(
            title = lastConversation?.title,
            messageCount = lastConversation?.messages?.size ?: messages.size,
            theme = theme, accent = accent,
            onNewChat = { follow = true; vm.newConversation() }
        )

        if (!hasStarted && !isStreaming) {
            Box(Modifier.weight(1f)) {
                WelcomeSection(model, accent, theme) { suggestion -> vm.send(suggestion) }
            }
        } else {
            Box(Modifier.weight(1f)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        MessageBubble(msg, theme, accent, model)
                    }
                    if (isStreaming) {
                        item(key = "live") {
                            LiveStreamBubble(liveContent, liveReasoning, theme, accent)
                        }
                    }
                }

                // زر القفز للأسفل — يظهر عندما تكون المتابعة موقوفة والشاشة بعيدة عن الأسفل
                androidx.compose.animation.AnimatedVisibility(
                    visible = notAtBottom,
                    enter = fadeIn(tween(180)),
                    exit = fadeOut(tween(180)),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp)
                ) {
                    Box(
                        Modifier
                            .size(40.dp)
                            .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.65f))), CircleShape)
                            .border(2.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable {
                                follow = true
                                scope.launch {
                                    runCatching { listState.animateScrollToItem((itemCount - 1).coerceAtLeast(0)) }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.KeyboardArrowDown, "scroll",
                            tint = Color.White, modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        AnimatedVisibility(visible = balanceHelp && !isStreaming) {
            BalanceHelpCard(vm, theme, accent)
        }

        InputBar(
            vm = vm,
            accent = accent,
            theme = theme,
            isStreaming = isStreaming,
            model = model,
            onSuggestion = null
        )
    }
}

// ═══════════════════ شريط آخر محادثة ═══════════════════

@Composable
private fun LastConversationBar(
    title: String?,
    messageCount: Int,
    theme: AppTheme,
    accent: Color,
    onNewChat: () -> Unit
) {
    val s = LocalS.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(theme.surfaceColor.copy(alpha = 0.55f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(13.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("💬", fontSize = 13.sp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title?.takeIf { it.isNotBlank() } ?: s.lastConvNew,
                color = theme.textPrimaryColor, fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold, maxLines = 1
            )
            Text(
                if (messageCount > 0) String.format(s.lastConvInfo, messageCount) else s.lastConvStartHint,
                color = theme.textSecondaryColor, fontSize = 10.sp
            )
        }
        // زر (+) — فتح محادثة جديدة فوراً
        Box(
            Modifier
                .size(30.dp)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.6f))), CircleShape)
                .clickable(onClick = onNewChat),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Add, s.navNewChat, tint = Color.White, modifier = Modifier.size(18.dp)) }
    }
}

// ═══════════════════ بطاقة حلول الرصيد ═══════════════════

@Composable
private fun BalanceHelpCard(vm: AppViewModel, theme: AppTheme, accent: Color) {
    val s = LocalS.current
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(theme.surfaceColor.copy(alpha = 0.92f))
            .border(1.dp, Color(0xFFFFB74D).copy(alpha = 0.55f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💳", fontSize = 17.sp)
            Spacer(Modifier.width(7.dp))
            Text(
                s.balanceTitle,
                color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                "✕", color = theme.textSecondaryColor, fontSize = 14.sp,
                modifier = Modifier.clickable { vm.consumeBalanceHelp() }.padding(4.dp)
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            s.balanceBody,
            color = theme.textSecondaryColor, fontSize = 11.5.sp, lineHeight = 16.sp
        )
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            HelpChip(s.chipFree, accent) { vm.useFreeModelAndRetry() }
            HelpChip(s.chipPlan, accent) { vm.enableCodingModeAndRetry() }
            HelpChip(s.chipRecharge, accent) {
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, android.net.Uri.parse(com.marwan.aiplusglm.ZaiConfig.RECHARGE_URL))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
        }
    }
}

@Composable
private fun HelpChip(label: String, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(11.dp))
            .background(accent.copy(alpha = 0.14f))
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 8.dp)
    ) { Text(label, color = accent, fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
}

// ═════════════════════ شريط النموذج النشط ═════════════════════

@Composable
private fun ActiveModelBar(model: GlmModel, accent: Color, theme: AppTheme, onClick: () -> Unit) {
    val s = LocalS.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(theme.surfaceColor.copy(alpha = 0.75f))
            .border(1.dp, accent.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.55f))), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(model.icon, fontSize = 15.sp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(model.nameAr, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                when {
                    model.webChat -> s.modelWebDesc
                    model.vision -> s.modelVisionDesc
                    else -> s.modelActiveDesc
                },
                color = accent, fontSize = 11.sp
            )
        }
        model.badge?.let {
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(accent.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) { Text(it, color = accent, fontSize = 10.sp) }
        }
    }
}

// ═════════════════════ شاشة الترحيب ═════════════════════

@Composable
private fun WelcomeSection(model: GlmModel, accent: Color, theme: AppTheme, onSuggestion: (String) -> Unit) {
    val s = LocalS.current
    val transition = rememberInfiniteTransition(label = "pulse")
    val scale by transition.animateFloat(
        initialValue = 0.96f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "s"
    )

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(92.dp)
                .scale(scale)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.45f))), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(model.icon, fontSize = 38.sp) }

        Spacer(Modifier.height(18.dp))
        Text(s.welcomeTitle, color = theme.textPrimaryColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            String.format(s.welcomeSubtitle, model.nameAr),
            color = theme.textSecondaryColor, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(26.dp))

        val suggestions = listOf(s.sug1, s.sug2, s.sug3, s.sug4)
        suggestions.forEach { suggestion ->
            Box(
                Modifier
                    .padding(vertical = 5.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(theme.surfaceColor.copy(alpha = 0.8f))
                    .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
                    .clickable { onSuggestion(suggestion) }
                    .padding(horizontal = 16.dp, vertical = 11.dp)
            ) { Text(suggestion, color = theme.textPrimaryColor, fontSize = 13.sp) }
        }
    }
}

// ═════════════════════ فقاعة رسالة ═════════════════════

@Composable
fun MessageBubble(msg: ChatMessage, theme: AppTheme, accent: Color, model: GlmModel) {
    val s = LocalS.current
    var showReasoning by remember(msg.id) { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp),
        horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
    ) {
        if (!msg.isUser) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp)) {
                Text(model.icon, fontSize = 11.sp)
                Spacer(Modifier.width(4.dp))
                Text(model.nameAr, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // بطاقة التفكير العميق القابلة للطي
        if (!msg.reasoning.isNullOrBlank()) {
            Box(
                Modifier
                    .padding(bottom = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.08f))
                    .clickable { showReasoning = !showReasoning }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (showReasoning) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        null, tint = accent, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(s.thinkingDeep, color = accent, fontSize = 11.sp)
                }
            }
            AnimatedVisibility(visible = showReasoning) {
                Text(
                    msg.reasoning!!,
                    color = theme.textSecondaryColor,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier
                        .padding(bottom = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(theme.surfaceColor.copy(alpha = 0.5f))
                        .padding(10.dp)
                )
            }
        }

        Box(
            Modifier
                .widthIn(max = 310.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = if (msg.isUser) 18.dp else 4.dp,
                        topEnd = if (msg.isUser) 4.dp else 18.dp,
                        bottomStart = 18.dp, bottomEnd = 18.dp
                    )
                )
                .background(
                    if (msg.isUser) Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.72f)))
                    else SolidOrError(msg.isError, theme)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                // شارات المرفقات
                if (msg.attachments.isNotEmpty()) {
                    Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        msg.attachments.forEach { att ->
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.22f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    "📎 ${att.name.take(18)}",
                                    color = Color.White, fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
                Text(
                    msg.content,
                    color = if (msg.isUser) Color.White
                    else if (msg.isError) Color(0xFFFFB4AB) else theme.textPrimaryColor,
                    fontSize = 14.5.sp,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
private fun SolidOrError(isError: Boolean, theme: AppTheme): Brush =
    if (isError) Brush.linearGradient(listOf(Color(0xFF4A1F1F), Color(0xFF3A1616)))
    else Brush.linearGradient(listOf(theme.surfaceColor, theme.surfaceColor.copy(alpha = 0.92f)))

// ═════════════════════ فقاعة البث الحي ═════════════════════

@Composable
fun LiveStreamBubble(content: String, reasoning: String, theme: AppTheme, accent: Color) {
    val s = LocalS.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp)) {
            val t = rememberInfiniteTransition(label = "dot")
            val sc by t.animateFloat(0.6f, 1.2f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "ss")
            Text("●", color = accent, fontSize = 8.sp, modifier = Modifier.scale(sc))
            Spacer(Modifier.width(5.dp))
            Text(
                if (content.isEmpty() && reasoning.isNotEmpty()) s.liveThinking else s.liveWriting,
                color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold
            )
        }

        if (reasoning.isNotBlank()) {
            Text(
                reasoning.takeLast(400),
                color = theme.textSecondaryColor.copy(alpha = 0.85f),
                fontSize = 11.5.sp, lineHeight = 17.sp, fontStyle = FontStyle.Italic,
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(theme.surfaceColor.copy(alpha = 0.45f))
                    .padding(9.dp)
            )
        }

        if (content.isNotBlank()) {
            Box(
                Modifier
                    .widthIn(max = 310.dp)
                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp))
                    .background(theme.surfaceColor)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(content, color = theme.textPrimaryColor, fontSize = 14.5.sp, lineHeight = 22.sp)
            }
        }
    }
}

// ═════════════════════ شريط الإدخال: نص + صوت + كاميرا + مرفقات ═════════════════════

@Composable
fun InputBar(
    vm: AppViewModel,
    accent: Color,
    theme: AppTheme,
    isStreaming: Boolean,
    model: GlmModel,
    onSuggestion: String? = null
) {
    val s = LocalS.current
    var text by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<List<Attachment>>(emptyList()) }
    var listening by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // رفع الملفات من الهاتف
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val att = vm.readAttachment(uri)
                if (att != null) pending = pending + att
            }
        }
    }

    // الكاميرا: طلب الصلاحية ثم التقاط صورة → تُرفق للتحليل بالرؤية
    val photoUri = remember {
        runCatching {
            val dir = File(context.cacheDir, "images").apply { mkdirs() }
            val f = File(dir, "cam_${System.currentTimeMillis()}.jpg")
            androidx.core.content.FileProvider.getUriForFile(
                context, context.packageName + ".fileprovider", f
            )
        }.getOrNull()
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && photoUri != null) {
            scope.launch {
                val att = vm.readAttachment(photoUri)
                if (att != null) pending = pending + att
            }
        }
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && photoUri != null) {
            runCatching { cameraLauncher.launch(photoUri) }
        } else {
            android.widget.Toast.makeText(context, s.toastCamDenied, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    // الإدخال الصوتي — بلغة التطبيق المختارة (v1.3.4)
    val appLanguage by vm.appLanguage.collectAsState()
    val speechRecognizer = remember {
        runCatching {
            if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
        }.getOrNull()
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening(context, speechRecognizer, appLanguage.tag, { listening = it }, { t -> text = t })
        else android.widget.Toast.makeText(context, s.toastMicDenied, android.widget.Toast.LENGTH_SHORT).show()
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        // رقائق المرفقات المعلقة
        if (pending.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                pending.take(3).forEach { att ->
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(accent.copy(alpha = 0.12f))
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("📎 ${att.name.take(14)} · ${att.displaySize}", color = accent, fontSize = 11.sp)
                        Spacer(Modifier.width(6.dp))
                        Text("✕",
                            color = accent.copy(alpha = 0.7f), fontSize = 12.sp,
                            modifier = Modifier.clickable { pending = pending - att }
                        )
                    }
                }
            }
        }

        // ═══ رقاقة التفكير العميق — تحكم كامل للمستخدم في تشغيل/إيقاف الميزة (بدون إجبار) ═══
        if (model.thinking) {
            val thinkingOn by vm.thinkingEnabled.collectAsState()
            Row(
                Modifier.fillMaxWidth().padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(11.dp))
                        .background(if (thinkingOn) accent.copy(alpha = 0.18f) else theme.surfaceColor.copy(alpha = 0.7f))
                        .border(1.dp, if (thinkingOn) accent else theme.borderColor, RoundedCornerShape(11.dp))
                        .clickable { vm.setThinking(!thinkingOn) }
                        .padding(horizontal = 11.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.Psychology, null,
                            tint = if (thinkingOn) accent else theme.textSecondaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (thinkingOn) s.thinkingOn else s.thinkingOff,
                            color = if (thinkingOn) accent else theme.textSecondaryColor,
                            fontSize = 11.5.sp, fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    if (thinkingOn) s.thinkingOffHint else s.thinkingOnHint,
                    color = theme.textSecondaryColor, fontSize = 10.sp,
                    maxLines = 1
                )
            }
        }

        Row(verticalAlignment = Alignment.Bottom) {
            // زر المرفقات — تحليل عميق جداً للملفات
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(theme.surfaceColor.copy(alpha = 0.8f))
                    .border(1.dp, theme.borderColor, CircleShape)
                    .clickable { filePicker.launch("*/*") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.AttachFile, s.attachFile, tint = accent, modifier = Modifier.size(21.dp)) }

            Spacer(Modifier.width(8.dp))

            // زر الكاميرا — التقاط صورة وتحليلها فوراً
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(theme.surfaceColor.copy(alpha = 0.8f))
                    .border(1.dp, theme.borderColor, CircleShape)
                    .clickable {
                        runCatching {
                            cameraPermission.launch(android.Manifest.permission.CAMERA)
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.CameraAlt, s.camera, tint = accent, modifier = Modifier.size(21.dp)) }

            Spacer(Modifier.width(8.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f).heightIn(min = 46.dp, max = 130.dp),
                placeholder = { Text(s.inputHint, color = theme.textSecondaryColor, fontSize = 14.sp) },
                shape = RoundedCornerShape(23.dp),
                keyboardOptions = KeyboardOptions.Default,
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = theme.textPrimaryColor,
                    unfocusedTextColor = theme.textPrimaryColor,
                    cursorColor = accent,
                    focusedBorderColor = accent.copy(alpha = 0.65f),
                    unfocusedBorderColor = theme.borderColor,
                    focusedContainerColor = theme.surfaceColor.copy(alpha = 0.85f),
                    unfocusedContainerColor = theme.surfaceColor.copy(alpha = 0.65f)
                ),
                textStyle = TextStyle(fontSize = 14.5.sp, color = theme.textPrimaryColor)
            )

            Spacer(Modifier.width(8.dp))

            // زر الميكروفون
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (listening) Brush.linearGradient(listOf(Color(0xFFFF5252), Color(0xFFD50000)))
                        else Brush.linearGradient(listOf(theme.surfaceColor, theme.surfaceColor))
                    )
                    .border(1.dp, if (listening) Color.Transparent else theme.borderColor, CircleShape)
                    .clickable {
                        runCatching { micPermission.launch(android.Manifest.permission.RECORD_AUDIO) }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Mic, s.voiceInput, tint = if (listening) Color.White else accent, modifier = Modifier.size(21.dp)) }

            Spacer(Modifier.width(8.dp))

            // زر إرسال / إيقاف — يتوهج أثناء البث
            val glow by rememberInfiniteTransition(label = "g").animateFloat(
                if (isStreaming) 0.75f else 1f, 1f,
                infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "gg"
            )
            Box(
                Modifier
                    .size(46.dp)
                    .scale(if (isStreaming) glow else 1f)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            if (isStreaming) listOf(Color(0xFFFF7043), Color(0xFFE64A19))
                            else listOf(accent, accent.copy(alpha = 0.6f))
                        )
                    )
                    .clickable {
                        if (isStreaming) vm.cancelStreaming()
                        else {
                            vm.send(text, pending)
                            text = ""
                            pending = emptyList()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isStreaming) Icons.Rounded.Stop else Icons.AutoMirrored.Rounded.Send,
                    if (isStreaming) s.stop else s.send,
                    tint = Color.White, modifier = Modifier.size(21.dp)
                )
            }
        }
    }
}

// ═════════════════════ الإدخال الصوتي ═════════════════════

private fun startListening(
    context: android.content.Context,
    speechRecognizer: SpeechRecognizer?,
    languageTag: String,
    onListening: (Boolean) -> Unit,
    onResult: (String) -> Unit
) {
    if (speechRecognizer == null) {
        android.widget.Toast.makeText(
            context,
            com.marwan.aiplusglm.data.AppLocale.s.toastNoSpeech,
            android.widget.Toast.LENGTH_SHORT
        ).show()
        return
    }
    onListening(true)
    runCatching {
        speechRecognizer.setRecognitionListener(object : android.speech.RecognitionListener by emptyListener() {
            override fun onResults(results: Bundle?) {
                onListening(false)
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onResult(t.trim())
            }
            override fun onError(error: Int) { onListening(false) }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag) // لغة الإدخال تتبع لغة التطبيق
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer.startListening(intent)
    }.onFailure { onListening(false) }
}

/** مستمع فارغ لتفويض واجهة RecognitionListener — نعيد تعريف الأحداث المهمة فقط */
private fun emptyListener() = object : android.speech.RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {}
    override fun onResults(results: Bundle?) {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
