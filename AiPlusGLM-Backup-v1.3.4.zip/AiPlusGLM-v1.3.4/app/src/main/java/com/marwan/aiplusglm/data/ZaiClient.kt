package com.marwan.aiplusglm.data

import com.marwan.aiplusglm.ZaiConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Call
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

/**
 * عميل Z.ai — مصمم ليكون مستحيل الانهيار:
 * • كل العمليات داخل Dispatchers.IO (لا NetworkOnMainThreadException)
 * • كل تحليل JSON داخل runCatching (لا JSONException غير الملتقطة)
 * • CancellationException يُعاد رميه دائماً (إلغاء نظيف دون تعارض مع Result)
 * • كل خطأ شبكة يعيد Result.failure برسالة عربية واضحة
 */
object ZaiClient {

    /** رمز خطأ الرصيد من Z.ai — يُكتشف تلقائياً ويحوّله التطبيق لبطاقة حلول تفاعلية */
    const val CODE_BALANCE = 1113

    /** رسالة خطأ الرصيد المترجمة حسب لغة التطبيق الحالية */
    val balanceMessage: String get() = AppLocale.s.balanceMessage

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    /** الطلب النشط حالياً — لتمكين إيقاف البث فوراً (يقطع القراءة المحجوبة) */
    @Volatile
    private var activeCall: Call? = null

    fun cancelActive() {
        runCatching { activeCall?.cancel() }
        activeCall = null
    }

    // ═══════════════════════ المحادثة المتدفقة ═══════════════════════

    suspend fun streamChat(
        messages: List<ChatMessage>,
        modelId: String,
        thinkingEnabled: Boolean,
        endpoint: ZaiConfig.Endpoint,
        language: AppLanguage = AppLanguage.ARABIC,
        onDelta: (content: String, reasoning: String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (!endpoint.ready) throw ApiException(-100, "NOT_CONFIGURED")

            val body = JSONObject().apply {
                put("model", modelId)
                put("stream", true)
                // تعليمات لغة الردود (v1.3.4): النموذج يتبع لغة التطبيق المختارة دائماً
                put("messages", buildMessagesJson(messages, language))
                put("max_tokens", 8192)
                if (thinkingEnabled && ModelCatalog.byId(modelId).thinking) {
                    put("thinking", JSONObject().put("type", "enabled"))
                }
            }

            val request = Request.Builder()
                .url("${endpoint.baseUrl}/chat/completions")
                .header("Authorization", "Bearer ${endpoint.apiKey}")
                .header("Accept", "text/event-stream")
                .header("User-Agent", "AiPlusGLM/1.3.4")
                .post(body.toString().toRequestBody(JSON_TYPE))
                .build()

            val call = client.newCall(request)
            activeCall = call
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = runCatching { response.body?.string().orEmpty() }.getOrElse { "" }
                    val (errCode, errMsg) = parseApiError(errBody)
                    if (isBalanceError(errCode, errMsg, response.code)) {
                        throw ApiException(CODE_BALANCE, BALANCE_MESSAGE)
                    }
                    throw ApiException(response.code, errMsg
                        ?: String.format(AppLocale.s.errServer, response.code))
                }

                val source = response.body?.source() ?: throw ApiException(-1, AppLocale.s.errEmptyResponse)
                val fullContent = StringBuilder()
                val fullReasoning = StringBuilder()

                while (true) {
                    coroutineContext.ensureActive() // خروج نظيف عند الإيقاف
                    val line = runCatching { source.readUtf8Line() }.getOrNull() ?: break
                    if (line.isBlank()) continue
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload == "[DONE]") break

                    // تحليل دفاعي — أي سطر تالف يُتجاهل بدل الانهيار
                    val delta = runCatching { parseDelta(payload) }.getOrNull() ?: continue
                    if (delta.first.isNotEmpty() || delta.second.isNotEmpty()) {
                        fullContent.append(delta.first)
                        fullReasoning.append(delta.second)
                        onDelta(delta.first, delta.second)
                    }
                }

                if (fullContent.isBlank() && fullReasoning.isBlank()) {
                    throw ApiException(-2, AppLocale.s.errEmptyResponse)
                }
                fullContent.toString()
            }.let { Result.success(it) }
        } catch (ce: CancellationException) {
            throw ce // إلغاء نظيف — لا يتحول لخطأ وهمي
        } catch (e: Throwable) {
            Result.failure(
                when (e) {
                    is ApiException -> e
                    else -> ApiException(-3, friendlyNetworkError(e))
                }
            )
        } finally {
            activeCall = null
        }
    }

    private fun parseDelta(payload: String): Pair<String, String> {
        val obj = JSONObject(payload)
        val choices = obj.optJSONArray("choices") ?: return "" to ""
        if (choices.length() == 0) return "" to ""
        val delta = choices.getJSONObject(0).optJSONObject("delta") ?: return "" to ""
        val content = delta.optString("content", "")
        val reasoning = delta.optString("reasoning_content", "")
        return content to reasoning
    }

    // ═══════════════════════ فحص التحديثات ═══════════════════════

    data class UpdateInfo(
        val versionName: String,
        val versionCode: Int,
        val apkUrl: String,
        val whatsNew: String,
        val additions: List<String> = emptyList(), // ✨ إضافات جديدة
        val fixes: List<String> = emptyList(),    // 🛠 الإصلاحات
        val changes: List<String> = emptyList()   // 🔄 التغييرات
    )

    /**
     * فحص التحديثات — يمر على سلسلة المصادر (المخزن الحي ثم الاحتياطي):
     * أول مصدر ينجح يُعتمد، وكلها تفشل → رسالة خطأ واضحة بدل الصمت
     */
    suspend fun checkForUpdates(currentCode: Int): Result<UpdateInfo?> = withContext(Dispatchers.IO) {
        var parsed: UpdateInfo? = null
        var lastError: Throwable? = null

        for (url in ZaiConfig.updateSources()) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "AiPlusGLM/1.3.4")
                    .get()
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw ApiException(response.code, String.format(AppLocale.s.errUpdateFetch, response.code))
                    }
                    parsed = parseUpdateJson(response.body?.string().orEmpty())
                }
                break // نجح هذا المصدر — نكتفي به
            } catch (ce: CancellationException) {
                throw ce // إلغاء نظيف
            } catch (e: Throwable) {
                lastError = e // نجرّب المصدر التالي
            }
        }

        when {
            parsed != null -> Result.success(parsed!!.takeIf { it.versionCode > currentCode })
            else -> Result.failure(
                when (val e = lastError) {
                    is ApiException -> e
                    null -> ApiException(-3, AppLocale.s.errUpdateServer)
                    else -> ApiException(-3, friendlyNetworkError(e))
                }
            )
        }
    }

    private fun parseUpdateJson(text: String): UpdateInfo {
        val json = JSONObject(text)
        fun section(key: String): List<String> = runCatching {
            val arr = json.optJSONArray(key)
            (0 until (arr?.length() ?: 0)).mapNotNull { arr?.optString(it)?.takeIf(String::isNotBlank) }
        }.getOrDefault(emptyList())
        return UpdateInfo(
            versionName = json.optString("versionName", "1.0.0"),
            versionCode = json.optInt("versionCode", 1),
            apkUrl = json.optString("apkUrl", ""),
            whatsNew = json.optString("whatsNew", ""),
            additions = section("additions"),
            fixes = section("fixes"),
            changes = section("changes")
        )
    }

    // ═══════════════════════ بناء الرسائل ═══════════════════════

    private fun buildMessagesJson(messages: List<ChatMessage>, language: AppLanguage): JSONArray {
        val arr = JSONArray()
        // رسالة نظام لغة الردود — أول رسالة في الطلب دائماً (المتطلب: لغة التطبيق تغيّر الردود)
        arr.put(JSONObject().put("role", "system").put("content", language.systemPrompt()))
        for (m in messages) {
            if (m.isError) continue
            val obj = JSONObject()
            obj.put("role", if (m.isUser) "user" else "assistant")

            val hasImages = m.attachments.any { it.kind == Attachment.Kind.IMAGE }
            val textParts = StringBuilder(m.content)
            // دمج محتوى الملفات النصية في نص الطلب — تحليل عميق
            for (att in m.attachments) {
                if (att.kind == Attachment.Kind.TEXT && !att.textContent.isNullOrBlank()) {
                    textParts.append("\n\n")
                        .append(String.format(AppLocale.s.attachmentContent, att.name))
                        .append("\n```\n${att.textContent.take(60000)}\n```")
                }
            }

            if (hasImages) {
                val parts = JSONArray()
                if (textParts.isNotBlank()) {
                    parts.put(JSONObject().put("type", "text").put("text", textParts.toString()))
                }
                for (att in m.attachments) {
                    if (att.kind != Attachment.Kind.IMAGE) continue
                    val b64 = att.base64.orEmpty()
                    if (b64.isBlank()) continue
                    val dataUrl = if (b64.startsWith("data:")) b64
                    else "data:${att.mime.ifBlank { "image/jpeg" }};base64,$b64"
                    parts.put(
                        JSONObject().put("type", "image_url")
                            .put("image_url", JSONObject().put("url", dataUrl))
                    )
                }
                obj.put("content", parts)
            } else {
                obj.put("content", textParts.toString())
            }
            arr.put(obj)
        }
        return arr
    }

    // ═══════════════════════ رسائل الخطأ الودودة ═══════════════════════

    class ApiException(val code: Int, message: String) : Exception(message)

    /** رسالة خطأ الرصيد القصيرة داخل فقاعة المحادثة — التفاصيل في بطاقة الحلول بالشاشة */
    val BALANCE_MESSAGE: String get() = AppLocale.s.balanceMessage

    /**
     * كشف خطأ الرصيد بكل صيغه:
     * • رمز 1113 الرسمي من Z.ai
     * • رسائل Insufficient balance / no resource package / Please recharge
     * • HTTP 429 مصحوب بكلمة balance
     */
    private fun isBalanceError(errCode: String?, errMsg: String?, httpCode: Int): Boolean {
        val m = errMsg?.lowercase().orEmpty()
        return errCode == "1113" ||
            m.contains("insufficient balance") ||
            m.contains("no resource package") ||
            m.contains("please recharge") ||
            (httpCode == 429 && m.contains("balance"))
    }

    /** يعيد (رمز الخطأ، رسالته) من جسم استجابة الخطأ */
    private fun parseApiError(body: String): Pair<String?, String?> = runCatching {
        val obj = JSONObject(body)
        val err = obj.optJSONObject("error")
        val code = err?.optString("code")?.takeIf { it.isNotBlank() }
            ?: obj.optString("code").takeIf { it.isNotBlank() }
        val msg = err?.optString("message")?.takeIf { it.isNotBlank() }
            ?: obj.optString("message").takeIf { it.isNotBlank() }
        code to msg
    }.getOrDefault(null to null)

    private fun extractApiError(body: String): String? = parseApiError(body).second

    private fun friendlyNetworkError(e: Throwable): String {
        val m = e.message.orEmpty()
        return when {
            e is ApiException && m == "NOT_CONFIGURED" -> AppLocale.s.errNotConfigured
            m.contains("timeout", true) || m.contains("timed out", true) -> AppLocale.s.errTimeout
            m.contains("Unable to resolve host") || m.contains("resolve", true) -> AppLocale.s.errNoInternet
            m.contains("401") -> AppLocale.s.errKey401
            m.contains("429") -> AppLocale.s.err429
            m.contains("Canceled", true) -> AppLocale.s.errStopped
            else -> String.format(AppLocale.s.errUnexpected, m.take(160).ifBlank { e.javaClass.simpleName })
        }
    }
}
