# 🗂️ BACKUP CONTEXT — Ai Plus GLM v1.3.2
# ملف السياق الشامل — أُنشئ لاستعادة المشروع كاملاً في أي جلسة مستقبلية

## 📌 هوية المشروع الثابتة (لا تتغير أبداً)
- اسم التطبيق: **Ai Plus GLM** — مساعد ذكاء اصطناعي عربي
- المطوّر: **مروان السيدى (Marwan Alsidi)** — ليبيا 🇱🇾
- applicationId: `com.marwan.aiplusglm` • package: com.marwan.aiplusglm
- Kotlin + Jetpack Compose • minSdk 29 • targetSdk 35 • compileSdk 35
- الترخيص: MIT • Gradle 8.9 • JDK 17 (Temurin في /home/z/tools/jdk-17.0.21+9)
- Android SDK: /home/z/tools/android-sdk (platforms;android-35 + build-tools;35.0.0)
- التوقيع: `keystore/aiplus-release.jks` • كلمتا المرور: `AiPlusGLM2026` • alias: `aiplus`
- شهادة SHA-256: `10fd3942...ab5d50` — نفسها في كل الإصدارات (التثبيت فوقها مباشرة)
- أمر البناء: `./gradlew assembleRelease --no-daemon` → app/build/outputs/apk/release/app-release.apk

## 📍 الإصدار الحالي: 1.3.2 (versionCode 9) — 2026-10-28
يجمع: كل ميزات v1.2.0 + v1.3.0 + v1.3.1 + إصلاحات v1.3.2:
1. **حرية التمرير الكاملة** — رصد السحب الحقيقي عبر `interactionSource/DragInteraction` (لا isScrollInProgress) + استئناف تلقائي عند العودة للأسفل عبر `canScrollForward`
2. **المظاهر تعمل في كل الأوضاع** — اشتقاق نسخة نهارية/ليلية لكل مظر من الثمانية (`effectiveLight/effectiveDark` + `resolveTheme` بدل resolveThemeId)
3. **مفتاح التفكير العميق** في شريط الإدخال (ChatScreen InputBar) — يظهر للنماذج الداعمة (model.thinking) ويستدعي setThinking المحفوظ
4. **خانة الأذونات قائمة منفصلة تتوسع وتنطوي** في SettingsScreen (نمط خانة المظهر)
5. **فحص التحديثات أُصلح جذرياً**: مخزنان حيان قابلان للتحديث الدائم (extendsclass json-storage) + سلسلة مصادر في ZaiClient.checkForUpdates + رسائل حالة واضحة
6. نص «حول التطبيق»: «تطبيق الذكاء الاصطناعي Ai Plus GLM هوا مساعدك ورفيقك الذكي في كل شي. (الاصدار المتطور ✅)»

## 🏗️ بنية الكود (app/src/main/java/com/marwan/aiplusglm/)
- `MainActivity.kt` — resolveTheme + MaterialTheme bridge + imePadding + BackHandler + توجيه webChat + UpdateDialog تلقائي + GlassNavBar
- `ZaiConfig.kt` — EMBEDDED_API_KEY/PROXY + UPDATE_JSON_URL (مخزن حي cbdaccd) + UPDATE_JSON_URL_FALLBACK (مخزن حي ddbcdcf) + updateSources() + CODING_BASE_URL + resolveEndpoint
- `data/ZaiClient.kt` — SSE آمن + UpdateInfo (additions/fixes/changes) + checkForUpdates بسلسلة مصادر + parseUpdateJson + كشف خطأ رصيد 1113 + UA "AiPlusGLM/1.3.2"
- `data/ModelCatalog.kt` — 10 نماذج (5 منها thinking=true: glm-5.3-flash/flashx/4.6/4.5) + webChat flag + CODING_PLAN_MODEL=glm-4.6
- `data/NotificationReaderService.kt` — خدمة قراءة الإشعارات
- `vm/AppViewModel.kt` — الحالة المركزية + thinkingEnabled (محفوظ، افتراضي false) + displayMode + lastConversation + فحص تحديث صامت + حل الرصيد التلقائي
- `ui/theme/Theme.kt` — 8 مظاهر + DisplayMode + deriveLight/deriveDark + effectiveLight/effectiveDark + resolveTheme + toColorScheme + ThemedBackground
- `ui/screens/ChatScreen.kt` — حرية تمرير (interactionSource) + رقاقة التفكير العميق في InputBar (model param) + شريط آخر محادثة + كاميرا + ميكروفون
- `ui/screens/SettingsScreen.kt` — المظهر Expandable + الأذونات Expandable (permsOpen) + بطاقة الاتصال + مفاتيح التفكير/النطق
- `ui/screens/AboutScreen.kt` — الترخيص + زر التحديثات + النص الجديد تحت الشعار
- بقية: WebChat / Models / Setup / WebViewScreen / UpdateDialog / SetupScreen
- `res/xml/`: backup_rules + data_extraction_rules + network_security_config + file_paths
- `assets/license.txt` — نص MIT المعروض في نافذة الترخيص
- الأيقونة: mipmap بكل الكثافات + adaptive — مولدة بـ `/home/z/my-project/scripts/gen_icon_v140.py`

## 🔗 روابط إصدار 1.3.2 النهائية
- APK الموقّع: https://gofile.io/d/BZ7LEtkN (SHA-256: c2d7683c1d429e0096d8da573cd6997631ea24375433293dc9d869981a8c34fa • 3,395,228 بايت)
- **المخزن الحي للتحديثات (أساسي، مدمج في APK)**: https://extendsclass.com/api/json-storage/bin/cbdaccd — يُحدَّث بطلب PUT بنفس المحتوى (scripts/publish_update_v132.py)
- **المخزن الحي الاحتياطي (مدمج في APK)**: https://extendsclass.com/api/json-storage/bin/ddbcdcf
- Update.json مرآة pomf: https://pomf2.lain.la/f/bt0zm0ze.json
- README.md v1.3.2: https://pomf2.lain.la/f/4boal7iw.md
- النسخة الاحتياطية الشاملة: (انظر Direct-Links.txt)

## 📜 سجل الإصدارات (ملخص)
- v1.0.0 → v1.1.0 (13 متطلباً) → v1.1.1 (شاشة تفعيل) → v1.1.2 (حل ذكي للرصيد) → v1.1.3 (GLM-5.3) → v1.2.0 (webChat + كيبورد) → v1.3.0 (ترخيص + مظهر + نافذة تحديث + أيقونة) → v1.3.1 (تمرير + جسر MaterialTheme + أذونات + Play + رجوع) → **v1.3.2 الحالي** (حرية تمرير + مظاهر لكل الأوضاع + مفتاح تفكير + أذونات قابلة للطي + مخزن تحديث حي)
- التفاصيل الكاملة في README.md

## ⚠️ دروس حرجة من هذا الإصدار
1. **البيئة تراجعت مرة** إلى لقطة قديمة وفقدت المصدر — لذلك: بعد كل إصدار ارفع نسخة احتياطية شاملة خارجياً (هذه الحزمة هي تلك النسخة)
2. **pomf/gofile لا يمكن الكتابة فوقها** — لذلك ملف التحديثات انتقل لمخزن حي (extendsclass) يُحدَّث بـ PUT على نفس الرابط: ابنِ → ارفع APK → حدّث المخزنين بـ PUT → انتهى (بلا حلقة إعادة بناء!)
3. pomf يرفض رفع APK (HTTP 500) — استخدم gofile عبر store1.gofile.io مباشرة (scripts/upload_v113.py gofile)
4. 0x0.st وcatbox وjsonblob وpixeldrain محجوبة/مرفوضة من بيئة العمل — extendsclass وpomf (للنصية) وgofile (للملفات) تعمل
5. gradle.properties يجب أن يحوي org.gradle.java.home=/home/z/tools/jdk-17.0.21+9
6. ملفات المستخدم الموزعة الحية (للأرشيف): v1.3.1 APK gofile 5clFcZ8P • v1.3.0 07aZZLC3 • v1.2.0 X35SGsCX • v1.1.3 xZeXkwn5 • v1.1.2 SLU0oGdR • v1.1.0 fKShbthO

## 🚀 بداية جلسة تعديل مستقبلية — خطوات
1. تأكد أن `/home/z/my-project/AiPlusGLM/` موجود — إن تراجعت البيئة: فك هذه الحزمة إلى الموقع نفسه
2. `cd /home/z/my-project/AiPlusGLM && ./gradlew assembleRelease --no-daemon`
3. إن نقص SDK/JDK: أعيد تثبيتهما كما في worklog (أوامر كاملة هناك)
4. ارفع بالسكربت: `python3 /home/z/my-project/scripts/upload_v113.py gofile <file>` أو `pomf <file>`
5. لنشر تحديث جديد: ارفع versionCode + User-Agent → ابنِ → ارفع APK → عدّل scripts/publish_update_v132.py (versionCode/whatsNew/apkUrl/sha) → شغّله (يحدّث المخزنين الحيين والمحلي) — النسخ المثبتة ستكتشف التحديث فوراً بلا إعادة بناء
6. حدّث README.md + BACKUP-CONTEXT.md + قائمة الروابط المباشرة (العادة الإلزامية)
