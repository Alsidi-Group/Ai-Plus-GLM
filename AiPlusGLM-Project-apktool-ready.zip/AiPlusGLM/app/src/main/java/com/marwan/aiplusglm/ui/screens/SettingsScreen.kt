package com.marwan.aiplusglm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.ui.theme.BgPattern
import com.marwan.aiplusglm.ui.theme.Themes
import com.marwan.aiplusglm.vm.AppViewModel

/**
 * الإعدادات — لا توجد خانة مفتاح API (مدمج مخفياً داخل التطبيق حسب المتطلب ②)
 * تحتوي: مركز المظاهر والخلفيات + تفضيلات المحادثة + زر البحث عن تحديثات
 */
@Composable
fun SettingsScreen(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color,
    thinking: Boolean,
    tts: Boolean,
    updateState: AppViewModel.UpdateState,
    onCheckUpdates: () -> Unit
) {
    val scroll = rememberScrollState()
    val selectedThemeId by vm.themeId.collectAsState()
    val selectedPatternId by vm.patternId.collectAsState()
    val connected by vm.endpointReady.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(horizontal = 14.dp)
            .padding(bottom = 90.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        Text("المظاهر والخلفيات", color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))

        // شبكة المظاهر الثمانية — المظهر النشط يُعلّم بعلامة صح وإطار متوهج
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Themes.all.take(4).forEach { t ->
                ThemeCard(t, selectedThemeId == t.id, Modifier.weight(1f)) { vm.setTheme(t.id) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Themes.all.drop(4).forEach { t ->
                ThemeCard(t, selectedThemeId == t.id, Modifier.weight(1f)) { vm.setTheme(t.id) }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("نمط الخلفية", color = theme.textPrimaryColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BgPattern.entries.forEach { p ->
                val selected = selectedPatternId == p.id
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) accent.copy(alpha = 0.2f) else theme.surfaceColor.copy(alpha = 0.6f))
                        .border(1.dp, if (selected) accent else theme.borderColor, RoundedCornerShape(10.dp))
                        .clickable { vm.setPattern(p.id) }
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) { Text(p.nameAr, color = if (selected) accent else theme.textSecondaryColor, fontSize = 11.sp) }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("الاتصال", color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        // بطاقة حالة الاتصال — بديل أنيق لخانة المفتاح القديمة (ضغطة تفتح شاشة التفعيل)
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (connected) Color(0xFF4CAF50).copy(alpha = 0.1f) else Color(0xFFFF7043).copy(alpha = 0.12f))
                .border(1.dp, if (connected) Color(0xFF4CAF50).copy(alpha = 0.5f) else Color(0xFFFF7043).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                .clickable { vm.openSetup() }
                .padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (connected) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                null,
                tint = if (connected) Color(0xFF4CAF50) else Color(0xFFFF7043),
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (connected) "متصل — المحادثة مفعّلة ✓" else "غير مفعّل — المحادثة مقفلة",
                    color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    if (connected) "اضغط لتغيير المفتاح أو السيرفر الوسيط" else "اضغط هنا للتفعيل — خطوة واحدة فقط",
                    color = theme.textSecondaryColor, fontSize = 11.sp
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("تفضيلات المحادثة", color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        SettingSwitch(
            icon = { Icon(Icons.Filled.Psychology, null, tint = accent, modifier = Modifier.size(20.dp)) },
            title = "التفكير العميق",
            subtitle = "يتيح للنماذج المتقدمة التفكير قبل الإجابة (أبطأ لكن أدق)",
            checked = thinking,
            accent = accent, theme = theme
        ) { vm.setThinking(it) }

        Spacer(Modifier.height(8.dp))
        SettingSwitch(
            icon = { Icon(Icons.Filled.VolumeUp, null, tint = accent, modifier = Modifier.size(20.dp)) },
            title = "نطق الردود صوتياً",
            subtitle = "قراءة ردود الذكاء الاصطناعي بالعربية تلقائياً",
            checked = tts,
            accent = accent, theme = theme
        ) { vm.setTts(it) }

        Spacer(Modifier.height(20.dp))
        Text("التحديثات", color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        // زر البحث عن تحديثات — يفحص ملف Update.json عند الضغط (المتطلب ⑥)
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.6f))))
                .clickable(onClick = onCheckUpdates)
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (updateState is AppViewModel.UpdateState.Loading) {
                    Text("⏳", fontSize = 15.sp)
                } else {
                    Icon(Icons.Filled.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    when (updateState) {
                        is AppViewModel.UpdateState.Loading -> "جاري الفحص..."
                        else -> "البحث عن تحديثات"
                    },
                    color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
            }
        }

        when (updateState) {
            is AppViewModel.UpdateState.UpToDate -> StatusCard("✓ أنت تستخدم أحدث إصدار — لا توجد تحديثات", Color(0xFF4CAF50), theme)
            is AppViewModel.UpdateState.Available -> UpdateAvailableCard(updateState.info, theme, accent)
            is AppViewModel.UpdateState.Failed -> StatusCard("✕ ${updateState.message}", Color(0xFFFF7043), theme)
            else -> {}
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "مفتاحك محفوظ على جهازك فقط داخل مساحة التطبيق الخاصة — لا يُشارك مع أي جهة.",
            color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 16.sp
        )
    }
}

@Composable
private fun ThemeCard(t: AppTheme, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) t.accentColor else t.borderColor,
                RoundedCornerShape(13.dp)
            )
            .background(if (selected) t.accentColor.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Brush.verticalGradient(listOf(Color(t.bgTop), Color(t.bgBottom))))
        ) {
            Box(
                Modifier.align(Alignment.Center).size(14.dp).background(Color(t.accent), CircleShape)
            )
            // علامة صح على المظهر النشط
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(3.dp)
                        .size(15.dp)
                        .background(t.accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.CheckCircle, null,
                        tint = Color.White, modifier = Modifier.size(11.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            t.nameAr,
            color = if (selected) t.accentColor else Color(t.textPrimary),
            fontSize = 10.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun SettingSwitch(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    checked: Boolean,
    accent: Color,
    theme: AppTheme,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent,
                uncheckedThumbColor = theme.textSecondaryColor,
                uncheckedTrackColor = theme.borderColor
            )
        )
    }
}

@Composable
private fun StatusCard(text: String, color: Color, theme: AppTheme) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 13.dp, vertical = 10.dp)
    ) { Text(text, color = color, fontSize = 12.sp, lineHeight = 17.sp) }
}

@Composable
private fun UpdateAvailableCard(info: com.marwan.aiplusglm.data.ZaiClient.UpdateInfo, theme: AppTheme, accent: Color) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(accent.copy(alpha = 0.1f))
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .padding(13.dp)
    ) {
        Text(
            "🎉 تحديث جديد متاح — الإصدار ${info.versionName}",
            color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold
        )
        if (info.whatsNew.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(info.whatsNew, color = theme.textSecondaryColor, fontSize = 12.sp, lineHeight = 18.sp)
        }
        Spacer(Modifier.height(10.dp))
        if (info.apkUrl.isNotBlank()) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent)
                    .clickable {
                        runCatching {
                            val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(info.apkUrl))
                            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(i)
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Download, null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("تحميل التحديث الآن", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
