package com.marwan.aiplusglm.ui.screens

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marwan.aiplusglm.data.Attachment
import com.marwan.aiplusglm.data.ChatMessage
import com.marwan.aiplusglm.data.GlmModel
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.ui.theme.BgPattern
import com.marwan.aiplusglm.vm.AppViewModel
import kotlinx.coroutines.launch

/** شاشة المحادثة الفورية — نص + صوت + مرفقات + بث حي */
@Composable
fun ChatScreen(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color,
    model: GlmModel,
    onOpenModels: () -> Unit
) {
    val messages by vm.messages.collectAsState()
    val isStreaming by vm.isStreaming.collectAsState()
    val liveContent by vm.liveContent.collectAsState()
    val liveReasoning by vm.liveReasoning.collectAsState()
    val hasStarted by vm.hasStartedChat.collectAsState()
    val balanceHelp by vm.balanceHelp.collectAsState()

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // تمرير تلقائي للأسفل عند وصول كل جزء جديد
    LaunchedEffect(messages.size, liveContent.length) {
        if (messages.isNotEmpty() || liveContent.isNotEmpty()) {
            runCatching {
                listState.animateScrollToItem(if (liveContent.isNotEmpty()) messages.size else messages.size - 1)
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        // شريط النموذج النشط — يفتح قائمة النماذج عند اللمس
        ActiveModelBar(model, accent, theme, onOpenModels)

        if (!hasStarted && !isStreaming) {
            // ⚠️ وزن 1f إلزامي — بدونها يأخذ الترحيب كامل الشاشة وتُدفع خانة الكتابة خارجها
            WelcomeSection(model, accent, theme, Modifier.weight(1f)) { suggestion ->
                vm.send(suggestion)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    MessageBubble(msg, theme, accent, model)
                }
                if (isStreaming) {
                    item(key = "live") {
                        LiveStreamBubble(liveContent, liveReasoning, theme, accent)
                    }
                }
            }
        }

        // بطاقة حلول خطأ الرصيد — تظهر فوق شريط الإدخال مباشرة
        AnimatedVisibility(visible = balanceHelp && !isStreaming) {
            BalanceHelpCard(vm, theme, accent)
        }

        InputBar(
            vm = vm,
            accent = accent,
            theme = theme,
            isStreaming = isStreaming,
            onSuggestion = null
        )
    }
}

// ═══════════════════ بطاقة حلول الرصيد ═══════════════════

@Composable
private fun BalanceHelpCard(vm: AppViewModel, theme: AppTheme, accent: Color) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(theme.surfaceColor.copy(alpha = 0.92f))
            .border(1.dp, Color(0xFFFFB74D).copy(alpha = 0.55f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💳", fontSize = 17.sp)
            Spacer(Modifier.width(7.dp))
            Text(
                "مشكلة في رصيد الحساب — اختر حلاً",
                color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                "✕", color = theme.textSecondaryColor, fontSize = 14.sp,
                modifier = Modifier.clickable { vm.consumeBalanceHelp() }.padding(4.dp)
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "مفتاحك صحيح لكن حسابه بلا رصيد أو حزمة موارد —\nأو أنه مفتاح اشتراك «خطة البرمجة» يحتاج نقطة نهايتها الخاصة.",
            color = theme.textSecondaryColor, fontSize = 11.5.sp, lineHeight = 16.sp
        )
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            // الحل ① — النموذج المجاني (يعمل بلا رصيد)
            HelpChip("⚡ النموذج المجاني", accent) { vm.useFreeModelAndRetry() }
            // الحل ② — وضع خطة البرمجة (لمفاتيح الاشتراك)
            HelpChip("🧩 وضع الخطة", accent) { vm.enableCodingModeAndRetry() }
            // الحل ③ — فتح صفحة الشحن
            HelpChip("💳 شحن", accent) {
                runCatching {
                    context.startActivity(
                        android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(com.marwan.aiplusglm.ZaiConfig.RECHARGE_URL))
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
        }
    }
}

@Composable
private fun HelpChip(label: String, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(11.dp))
            .background(accent.copy(alpha = 0.14f))
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 8.dp)
    ) { Text(label, color = accent, fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
}

// ═════════════════════ شريط النموذج النشط ═════════════════════

@Composable
private fun ActiveModelBar(model: GlmModel, accent: Color, theme: AppTheme, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(theme.surfaceColor.copy(alpha = 0.75f))
            .border(1.dp, accent.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.55f))), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(model.icon, fontSize = 15.sp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(model.nameAr, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                if (model.vision) "نموذج رؤية — يحلل الصور" else "نشط وجاهز للمحادثة",
                color = accent, fontSize = 11.sp
            )
        }
        model.badge?.let {
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(accent.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) { Text(it, color = accent, fontSize = 10.sp) }
        }
    }
}

// ═════════════════════ شاشة الترحيب ═════════════════════

@Composable
private fun WelcomeSection(
    model: GlmModel,
    accent: Color,
    theme: AppTheme,
    modifier: Modifier = Modifier,
    onSuggestion: (String) -> Unit
) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val scale by transition.animateFloat(
        initialValue = 0.96f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "s"
    )

    Box(
        modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        contentAlignment = Alignment.Center
    ) {
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 430.dp)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(92.dp)
                .scale(scale)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.45f))), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(model.icon, fontSize = 38.sp) }

        Spacer(Modifier.height(18.dp))
        Text("أهلاً بك في Ai Plus GLM", color = theme.textPrimaryColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "نموذج ${model.nameAr} جاهز — اسألني أي شيء",
            color = theme.textSecondaryColor, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(26.dp))

        val suggestions = listOf(
            "اكتب لي مقالاً عن الذكاء الاصطناعي",
            "ساعدني في حل مسألة رياضيات",
            "ترجم نصاً من العربية للإنجليزية",
            "اقترح لي أفكار تطبيقات مبتكرة"
        )
        suggestions.forEach { s ->
            Box(
                Modifier
                    .padding(vertical = 5.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(theme.surfaceColor.copy(alpha = 0.8f))
                    .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
                    .clickable { onSuggestion(s) }
                    .padding(horizontal = 16.dp, vertical = 11.dp)
            ) { Text(s, color = theme.textPrimaryColor, fontSize = 13.sp) }
        }
    }
    }
}

// ═════════════════════ فقاعة رسالة ═════════════════════

@Composable
fun MessageBubble(msg: ChatMessage, theme: AppTheme, accent: Color, model: GlmModel) {
    var showReasoning by remember(msg.id) { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp),
        horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
    ) {
        if (!msg.isUser) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp)) {
                Text(model.icon, fontSize = 11.sp)
                Spacer(Modifier.width(4.dp))
                Text(model.nameAr, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // بطاقة التفكير العميق القابلة للطي
        if (!msg.reasoning.isNullOrBlank()) {
            Box(
                Modifier
                    .padding(bottom = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.08f))
                    .clickable { showReasoning = !showReasoning }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (showReasoning) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        null, tint = accent, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("التفكير العميق", color = accent, fontSize = 11.sp)
                }
            }
            AnimatedVisibility(visible = showReasoning) {
                Text(
                    msg.reasoning!!,
                    color = theme.textSecondaryColor,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier
                        .padding(bottom = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(theme.surfaceColor.copy(alpha = 0.5f))
                        .padding(10.dp)
                )
            }
        }

        Box(
            Modifier
                .widthIn(max = 310.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = if (msg.isUser) 18.dp else 4.dp,
                        topEnd = if (msg.isUser) 4.dp else 18.dp,
                        bottomStart = 18.dp, bottomEnd = 18.dp
                    )
                )
                .background(
                    if (msg.isUser) Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.72f)))
                    else SolidOrError(msg.isError, theme)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                // شارات المرفقات
                if (msg.attachments.isNotEmpty()) {
                    Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        msg.attachments.forEach { att ->
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.22f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    "📎 ${att.name.take(18)}",
                                    color = Color.White, fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
                Text(
                    msg.content,
                    color = if (msg.isUser) Color.White
                    else if (msg.isError) Color(0xFFFFB4AB) else theme.textPrimaryColor,
                    fontSize = 14.5.sp,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
private fun SolidOrError(isError: Boolean, theme: AppTheme): Brush =
    if (isError) Brush.linearGradient(listOf(Color(0xFF4A1F1F), Color(0xFF3A1616)))
    else Brush.linearGradient(listOf(theme.surfaceColor, theme.surfaceColor.copy(alpha = 0.92f)))

// ═════════════════════ فقاعة البث الحي ═════════════════════

@Composable
fun LiveStreamBubble(content: String, reasoning: String, theme: AppTheme, accent: Color) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp)) {
            val t = rememberInfiniteTransition(label = "dot")
            val s by t.animateFloat(0.6f, 1.2f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "ss")
            Text("●", color = accent, fontSize = 8.sp, modifier = Modifier.scale(s))
            Spacer(Modifier.width(5.dp))
            Text(
                if (content.isEmpty() && reasoning.isNotEmpty()) "يفكر بعمق..." else "يكتب الآن...",
                color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold
            )
        }

        if (reasoning.isNotBlank()) {
            Text(
                reasoning.takeLast(400),
                color = theme.textSecondaryColor.copy(alpha = 0.85f),
                fontSize = 11.5.sp, lineHeight = 17.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(theme.surfaceColor.copy(alpha = 0.45f))
                    .padding(9.dp)
            )
        }

        if (content.isNotBlank()) {
            Box(
                Modifier
                    .widthIn(max = 310.dp)
                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp))
                    .background(theme.surfaceColor)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(content, color = theme.textPrimaryColor, fontSize = 14.5.sp, lineHeight = 22.sp)
            }
        }
    }
}

// ═════════════════════ شريط الإدخال: نص + صوت + مرفقات ═════════════════════

@Composable
fun InputBar(
    vm: AppViewModel,
    accent: Color,
    theme: AppTheme,
    isStreaming: Boolean,
    onSuggestion: String? = null
) {
    var text by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<List<Attachment>>(emptyList()) }
    var listening by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val att = vm.readAttachment(uri)
                if (att != null) pending = pending + att
            }
        }
    }

    // الإدخال الصوتي — SpeechRecognizer بدون أي صلاحية وقت تشغيل مطلوبة
    val speechRecognizer = remember {
        runCatching {
            if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
        }.getOrNull()
    }

    fun startListening() {
        if (speechRecognizer == null) {
            vm.consumeToast()
            android.widget.Toast.makeText(context, "⚠️ الجهاز لا يدعم الإدخال الصوتي", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        listening = true
        runCatching {
            speechRecognizer.setRecognitionListener(object : android.speech.RecognitionListener by emptyListener() {
                override fun onResults(results: Bundle?) {
                    listening = false
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) text = (text + (if (text.isBlank()) "" else " ") + t).trim()
                }
                override fun onError(error: Int) { listening = false }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer.startListening(intent)
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        // رقائق المرفقات المعلقة
        if (pending.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                pending.take(3).forEach { att ->
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(accent.copy(alpha = 0.12f))
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("📎 ${att.name.take(14)} · ${att.displaySize}", color = accent, fontSize = 11.sp)
                        Spacer(Modifier.width(6.dp))
                        Text("✕",
                            color = accent.copy(alpha = 0.7f), fontSize = 12.sp,
                            modifier = Modifier.clickable { pending = pending - att }
                        )
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.Bottom) {
            // زر المرفقات — تحليل عميق جداً للملفات
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(theme.surfaceColor.copy(alpha = 0.8f))
                    .border(1.dp, theme.borderColor, CircleShape)
                    .clickable { filePicker.launch("*/*") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.AttachFile, "إرفاق ملف", tint = accent, modifier = Modifier.size(21.dp)) }

            Spacer(Modifier.width(8.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f).heightIn(min = 46.dp, max = 130.dp),
                placeholder = { Text("اكتب رسالتك هنا...", color = theme.textSecondaryColor, fontSize = 14.sp) },
                shape = RoundedCornerShape(23.dp),
                keyboardOptions = KeyboardOptions.Default,
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = theme.textPrimaryColor,
                    unfocusedTextColor = theme.textPrimaryColor,
                    cursorColor = accent,
                    focusedBorderColor = accent.copy(alpha = 0.65f),
                    unfocusedBorderColor = theme.borderColor,
                    focusedContainerColor = theme.surfaceColor.copy(alpha = 0.85f),
                    unfocusedContainerColor = theme.surfaceColor.copy(alpha = 0.65f)
                ),
                textStyle = TextStyle(fontSize = 14.5.sp, color = theme.textPrimaryColor)
            )

            Spacer(Modifier.width(8.dp))

            // زر الميكروفون
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (listening) Brush.linearGradient(listOf(Color(0xFFFF5252), Color(0xFFD50000)))
                        else Brush.linearGradient(listOf(theme.surfaceColor, theme.surfaceColor))
                    )
                    .border(1.dp, if (listening) Color.Transparent else theme.borderColor, CircleShape)
                    .clickable { startListening() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Mic, "إدخال صوتي", tint = if (listening) Color.White else accent, modifier = Modifier.size(21.dp)) }

            Spacer(Modifier.width(8.dp))

            // زر إرسال / إيقاف — يتوهج أثناء البث
            val glow by rememberInfiniteTransition(label = "g").animateFloat(
                if (isStreaming) 0.75f else 1f, 1f,
                infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "gg"
            )
            Box(
                Modifier
                    .size(46.dp)
                    .scale(if (isStreaming) glow else 1f)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            if (isStreaming) listOf(Color(0xFFFF7043), Color(0xFFE64A19))
                            else listOf(accent, accent.copy(alpha = 0.6f))
                        )
                    )
                    .clickable {
                        if (isStreaming) vm.cancelStreaming()
                        else {
                            vm.send(text, pending)
                            text = ""
                            pending = emptyList()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isStreaming) Icons.Filled.Stop else Icons.AutoMirrored.Filled.Send,
                    if (isStreaming) "إيقاف" else "إرسال",
                    tint = Color.White, modifier = Modifier.size(21.dp)
                )
            }
        }
    }
}

/** مستمع فارغ لتفويض واجهة RecognitionListener — نعيد تعريف الأحداث المهمة فقط */
private fun emptyListener() = object : android.speech.RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {}
    override fun onResults(results: Bundle?) {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
