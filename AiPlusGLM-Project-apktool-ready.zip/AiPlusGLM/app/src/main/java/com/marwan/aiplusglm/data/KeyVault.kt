package com.marwan.aiplusglm.data

import android.content.Context

/**
 * خزنة الاتصال — تحفظ مفتاح API أو رابط السيرفر الوسيط على جهاز المستخدم
 * داخل المساحة الخاصة بالتطبيق (filesDir) التي لا يستطيع أي تطبيق آخر قراءتها.
 *
 * الخصوصية:
 * • المفتاح يُرسل فقط إلى https://api.z.ai (أو سيرفر المطوّر الوسيط)
 * • لا يُرفع لأي جهة أخرى، ولا يظهر في أي شاشة إلا بحقل مخفي (•••)
 * • التطبيق يعمل بدون إنترنت في قراءته — لا حسابات ولا تسجيل
 */
object KeyVault {

    private const val FILE = "aiplus_vault"
    private const val K_KEY = "api_key"
    private const val K_PROXY = "proxy_url"
    private const val K_CODING = "coding_mode"

    fun saveKey(context: Context, key: String) {
        runCatching {
            context.getFileStreamPath(FILE).parentFile?.mkdirs()
            val props = readAll(context).toMutableMap()
            props[K_KEY] = key.trim()
            writeAll(context, props)
        }
    }

    fun saveProxy(context: Context, url: String) {
        runCatching {
            val props = readAll(context).toMutableMap()
            props[K_PROXY] = url.trim()
            writeAll(context, props)
        }
    }

    fun loadKey(context: Context): String =
        runCatching { readAll(context)[K_KEY].orEmpty() }.getOrDefault("")

    fun loadProxy(context: Context): String =
        runCatching { readAll(context)[K_PROXY].orEmpty() }.getOrDefault("")

    /** وضع خطة البرمجة — يوجّه المفتاح لنقطة نهاية الاشتراك بدل النقطة العادية */
    fun saveCodingMode(context: Context, on: Boolean) {
        runCatching {
            val props = readAll(context).toMutableMap()
            props[K_CODING] = if (on) "1" else "0"
            writeAll(context, props)
        }
    }

    fun loadCodingMode(context: Context): Boolean =
        runCatching { readAll(context)[K_CODING] == "1" }.getOrDefault(false)

    fun clearAll(context: Context) {
        runCatching { context.deleteFile(FILE) }
    }

    private fun readAll(context: Context): Map<String, String> {
        val f = context.getFileStreamPath(FILE)
        if (!f.exists()) return emptyMap()
        val map = mutableMapOf<String, String>()
        f.readLines().forEach { line ->
            val idx = line.indexOf('=')
            if (idx > 0) map[line.substring(0, idx)] = line.substring(idx + 1)
        }
        return map
    }

    private fun writeAll(context: Context, props: Map<String, String>) {
        context.openFileOutput(FILE, Context.MODE_PRIVATE).use { out ->
            props.forEach { (k, v) -> out.write("$k=$v\n".toByteArray()) }
        }
    }
}
