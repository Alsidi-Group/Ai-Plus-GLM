package com.marwan.aiplusglm.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.vm.AppViewModel

/**
 * شاشة التفعيل — تظهر مرة واحدة فقط عندما لا يوجد مفتاح أو سيرفر وسيط.
 * خطوة واحدة: لصق المفتاح من Z.ai (أو رابط السيرفر) ← حفظ ← المحادثة تنطلق فوراً.
 * المفتاح يُحفظ في مساحة التطبيق الخاصة على الجهاز ولا يغادره إلا نحو Z.ai.
 */
@Composable
fun SetupScreen(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color
) {
    var key by remember { mutableStateOf("") }
    var proxy by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    var codingPlan by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val pulse = rememberInfiniteTransition(label = "p").animateFloat(
        0.97f, 1.03f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "ps"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(theme.bgColorTop.copy(alpha = 0.97f), theme.bgColorBottom.copy(alpha = 0.99f))
                )
            )
            .verticalScroll(rememberScrollState())
            .systemBarsPadding()
            .imePadding()
    ) {
        // زر إغلاق — للمتصفحين دون تفعيل (الإرسال يعيد فتح الشاشة تلقائياً)
        IconButton(
            onClick = { vm.closeSetup() },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) { Icon(Icons.Filled.Close, "إغلاق", tint = theme.textSecondaryColor) }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp)
                .padding(top = 30.dp, bottom = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .size(84.dp)
                    .scale(pulse.value)
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.5f))), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("🔐", fontSize = 34.sp) }

            Spacer(Modifier.height(14.dp))
            Text("تفعيل المحادثة", color = theme.textPrimaryColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "خطوة واحدة تُنجزها مرة واحدة فقط —\nالمفتاح يُحفظ على جهازك ولا يُطلب مجدداً",
                color = theme.textSecondaryColor, fontSize = 13.sp, lineHeight = 19.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))

            // اختيار نوع المفتاح — يحدد نقطة النهاية التي يُوجّه إليها التطبيق
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TypeChip(
                    label = "🔑 مفتاح عادي",
                    desc = "دفع حسب الاستخدام",
                    selected = !codingPlan, accent = accent, theme = theme,
                    onClick = { codingPlan = false },
                    modifier = Modifier.weight(1f)
                )
                TypeChip(
                    label = "🧩 خطة البرمجة",
                    desc = "مفتاح اشتراك Coding Plan",
                    selected = codingPlan, accent = accent, theme = theme,
                    onClick = { codingPlan = true },
                    modifier = Modifier.weight(1f)
                )
            }
            AnimatedVisibility(visible = codingPlan) {
                Column {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "مفاتيح اشتراك خطة البرمجة لا تعمل على النقطة العادية\n(تُرجع: Insufficient balance) — سيستخدمها التطبيق تلقائياً\nمن نقطة نهاية الخطة api/coding/paas/v4 مع GLM-4.6",
                        color = accent, fontSize = 10.5.sp, lineHeight = 15.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // حقل المفتاح — مخفي بنقاط مع زر إظهار
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; error = null },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(
                        if (codingPlan) "الصق مفتاح خطة البرمجة هنا"
                        else "الصق مفتاح API هنا (sk-...)",
                        color = theme.textSecondaryColor, fontSize = 13.sp
                    )
                },
                leadingIcon = { Icon(Icons.Filled.Key, null, tint = accent, modifier = Modifier.size(20.dp)) },
                trailingIcon = {
                    IconButton(onClick = { showKey = !showKey }) {
                        Icon(
                            if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            "إظهار/إخفاء",
                            tint = theme.textSecondaryColor, modifier = Modifier.size(19.dp)
                        )
                    }
                },
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = theme.textPrimaryColor,
                    unfocusedTextColor = theme.textPrimaryColor,
                    cursorColor = accent,
                    focusedBorderColor = accent.copy(alpha = 0.7f),
                    unfocusedBorderColor = theme.borderColor,
                    focusedContainerColor = theme.surfaceColor.copy(alpha = 0.8f),
                    unfocusedContainerColor = theme.surfaceColor.copy(alpha = 0.55f)
                ),
                textStyle = TextStyle(fontSize = 14.sp, color = theme.textPrimaryColor)
            )

            // زر الحصول على مفتاح مجاني
            Row(
                Modifier
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(theme.surfaceColor.copy(alpha = 0.6f))
                    .border(1.dp, theme.borderColor, RoundedCornerShape(10.dp))
                    .clickable {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(com.marwan.aiplusglm.ZaiConfig.GET_KEY_URL))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                    .padding(horizontal = 13.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🌐", fontSize = 13.sp)
                Spacer(Modifier.width(6.dp))
                Text("احصل على مفتاحك مجاناً من Z.ai", color = accent, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
            }

            error?.let {
                Spacer(Modifier.height(8.dp))
                Text("✕ $it", color = Color(0xFFFF7043), fontSize = 12.sp, textAlign = TextAlign.Center)
            }

            // زر الحفظ والانطلاق
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.6f))))
                    .clickable {
                        if (saving) return@clickable
                        saving = true
                        vm.prepareCredentials(codingPlan) // نوع الاتصال أولاً ثم المفتاح
                        val ok = vm.saveCredentials(key, proxy)
                        saving = false
                        if (ok) {
                            vm.closeSetup()
                            vm.consumeToast()
                            vm.notifyConnected()
                        } else {
                            error = when {
                                key.isBlank() && proxy.isBlank() ->
                                    "الصق مفتاحك أو رابط السيرفر الوسيط أولاً"
                                key.isNotBlank() && key.trim().length < 20 ->
                                    "المفتاح قصير جداً — انسخه كاملاً من Z.ai"
                                proxy.isNotBlank() && !proxy.trim().startsWith("http") ->
                                    "رابط السيرفر يجب أن يبدأ بـ https://"
                                else -> "تعذر الحفظ — تحقق من البيانات وحاول مجدداً"
                            }
                        }
                    }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (saving) "جاري الحفظ..." else "حفظ وانطلاق 🚀",
                    color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold
                )
            }

            // قسم متقدم مطوي — السيرفر الوسيط
            Spacer(Modifier.height(14.dp))
            Text(
                if (advanced) "▲ إخفاء الخيار المتقدم" else "▼ خيار متقدم: السيرفر الوسيط (للمطوّر)",
                color = theme.textSecondaryColor, fontSize = 11.5.sp,
                modifier = Modifier.clickable { advanced = !advanced }.padding(6.dp)
            )
            AnimatedVisibility(
                visible = advanced,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(
                        "إن نشرت worker.js على Cloudflare املأ الرابط فقط واترك المفتاح فارغاً — أأمن للأجهزة المشتركة",
                        color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 16.sp
                    )
                    Spacer(Modifier.height(7.dp))
                    OutlinedTextField(
                        value = proxy,
                        onValueChange = { proxy = it; error = null },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("https://aiplus-glm.xxx.workers.dev", color = theme.textSecondaryColor, fontSize = 12.5.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = theme.textPrimaryColor,
                            unfocusedTextColor = theme.textPrimaryColor,
                            cursorColor = accent,
                            focusedBorderColor = accent.copy(alpha = 0.7f),
                            unfocusedBorderColor = theme.borderColor,
                            focusedContainerColor = theme.surfaceColor.copy(alpha = 0.8f),
                            unfocusedContainerColor = theme.surfaceColor.copy(alpha = 0.55f)
                        ),
                        textStyle = TextStyle(fontSize = 13.sp, color = theme.textPrimaryColor)
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                "🔒 خصوصيتك: المفتاح يُخزن داخل مساحة التطبيق الخاصة على جهازك،\nولا يُرسل إلا إلى Z.ai الرسمية مباشرة.",
                color = theme.textSecondaryColor.copy(alpha = 0.85f),
                fontSize = 10.5.sp, lineHeight = 15.sp, textAlign = TextAlign.Center
            )
        }
    }
}

// ═══════════════════ رقاقة اختيار نوع المفتاح ═══════════════════

@Composable
private fun TypeChip(
    label: String,
    desc: String,
    selected: Boolean,
    accent: Color,
    theme: AppTheme,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .background(
                if (selected) accent.copy(alpha = 0.14f)
                else theme.surfaceColor.copy(alpha = 0.6f)
            )
            .border(
                1.dp,
                if (selected) accent.copy(alpha = 0.6f) else theme.borderColor,
                RoundedCornerShape(13.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            label, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            color = if (selected) accent else theme.textPrimaryColor,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(2.dp))
        Text(
            desc, fontSize = 9.5.sp,
            color = if (selected) accent.copy(alpha = 0.85f) else theme.textSecondaryColor,
            textAlign = TextAlign.Center
        )
    }
}
