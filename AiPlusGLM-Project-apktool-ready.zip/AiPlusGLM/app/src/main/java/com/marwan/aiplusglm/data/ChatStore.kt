package com.marwan.aiplusglm.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** تخزين المحادثات محلياً — ملف JSON لكل محادثة في filesDir/conversations */
object ChatStore {

    private fun dir(context: Context): File =
        File(context.filesDir, "conversations").apply { mkdirs() }

    fun save(context: Context, conv: Conversation) {
        runCatching {
            val arr = JSONArray()
            for (m in conv.messages) {
                val mo = JSONObject()
                    .put("role", if (m.isUser) "user" else "assistant")
                    .put("content", m.content)
                    .put("time", m.time)
                m.reasoning?.let { mo.put("reasoning", it) }
                if (m.isError) mo.put("isError", true)
                if (m.attachments.isNotEmpty()) {
                    val ats = JSONArray()
                    for (a in m.attachments) {
                        ats.put(JSONObject()
                            .put("name", a.name)
                            .put("mime", a.mime)
                            .put("kind", a.kind.name)
                            .put("text", a.textContent ?: ""))
                    }
                    mo.put("attachments", ats)
                }
                arr.put(mo)
            }
            File(dir(context), "${conv.id}.json").writeText(arr.toString())
        }
    }

    fun loadAll(context: Context): List<Conversation> {
        val list = mutableListOf<Conversation>()
        runCatching {
            for (f in dir(context).listFiles()?.filter { it.name.endsWith(".json") }.orEmpty()) {
                runCatching {
                    val arr = JSONArray(f.readText())
                    val msgs = mutableListOf<ChatMessage>()
                    var modelId = ModelCatalog.default().id
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val ats = mutableListOf<Attachment>()
                        if (o.has("attachments")) {
                            val ja = o.getJSONArray("attachments")
                            for (j in 0 until ja.length()) {
                                val a = ja.getJSONObject(j)
                                ats.add(Attachment(
                                    name = a.optString("name"),
                                    mime = a.optString("mime"),
                                    kind = runCatching { Attachment.Kind.valueOf(a.optString("kind")) }.getOrElse { Attachment.Kind.OTHER },
                                    textContent = a.optString("text").ifBlank { null }
                                ))
                            }
                        }
                        msgs.add(ChatMessage(
                            id = System.nanoTime() + i,
                            role = if (o.optString("role") == "user") ChatMessage.Role.USER else ChatMessage.Role.ASSISTANT,
                            content = o.optString("content"),
                            reasoning = o.optString("reasoning").ifBlank { null },
                            isError = o.optBoolean("isError", false),
                            attachments = ats,
                            time = o.optLong("time", System.currentTimeMillis())
                        ))
                    }
                    list.add(Conversation(
                        id = f.nameWithoutExtension,
                        title = msgs.firstOrNull { it.isUser }?.content?.take(40) ?: "محادثة",
                        modelId = modelId,
                        messages = msgs,
                        updatedAt = f.lastModified()
                    ))
                }
            }
        }
        return list.sortedByDescending { it.updatedAt }
    }

    fun delete(context: Context, id: String) {
        runCatching { File(dir(context), "$id.json").delete() }
    }
}
