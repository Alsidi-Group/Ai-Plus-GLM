package com.marwan.aiplusglm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marwan.aiplusglm.ui.theme.AppTheme

@Composable
fun AboutScreen(theme: AppTheme, accent: Color, versionName: String, onOpenUrl: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 90.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        Box(
            Modifier
                .size(88.dp)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.5f))), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text("Ai", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black) }

        Spacer(Modifier.height(14.dp))
        Text("Ai Plus GLM", color = theme.textPrimaryColor, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text("الإصدار $versionName", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "مساعد ذكاء اصطناعي عربي مبني على نماذج GLM من Z.ai — محادثات فورية متدفقة، تحليل صور وملفات، إدخال صوتي، ومظاهر فاخرة",
            color = theme.textSecondaryColor, fontSize = 13.sp, lineHeight = 20.sp, textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(22.dp))

        // بطاقة المطور
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.75f))
                .border(1.dp, theme.borderColor, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Text("المطور", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("مروان السيدى — Marwan Alsidi", color = theme.textPrimaryColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("ليبيا 🇱🇾", color = theme.textSecondaryColor, fontSize = 13.sp)
        }

        Spacer(Modifier.height(12.dp))

        LinkRow(Icons.Filled.Language, "الموقع الرسمي — chat.z.ai", "المحادثة عبر الويب مباشرة من التطبيق", theme, accent) { onOpenUrl("https://chat.z.ai") }
        LinkRow(Icons.Filled.Code, "وثائق المطورين — docs.z.ai", "الحصول على مفتاح API ومرجع النماذج", theme, accent) { onOpenUrl("https://docs.z.ai") }
        LinkRow(Icons.Filled.Star, "نماذج GLM المتاحة", "8 نماذج: من Flash الفوري إلى 4.6 الرائد", theme, accent) { onOpenUrl("https://docs.z.ai/guides/llm/glm-4.6") }

        Spacer(Modifier.height(18.dp))
        Text(
            "مرخّص بموجب رخصة MIT — الكود المصدري متاح للجميع\n© 2026 مروان السيدى",
            color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun LinkRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    theme: AppTheme,
    accent: Color,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(36.dp)
                .background(accent.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = theme.textSecondaryColor, fontSize = 11.sp)
        }
    }
}
