package com.marwan.aiplusglm.data

/**
 * كتالوج نماذج GLM — كل نموذج له لونه المميز الذي يعيد تلوين واجهة التطبيق
 * عند تفعيله (المتطلب: تغيّر الواجهة ويتفعل النموذج تلقائياً عند اختياره)
 *
 * webChat = true ← النموذج يعمل عبر الواجهة الرسمية لموقع Z.ai داخل التطبيق
 * (WebView مدمج) بدل مفتاح API — لا يحتاج مفتاحاً ولا رصيداً إطلاقاً
 */
data class GlmModel(
    val id: String,
    val nameAr: String,
    val descAr: String,
    val accent: Long,          // لون واجهة النموذج
    val vision: Boolean = false,
    val thinking: Boolean = false,
    val badge: String? = null, // شارة مثل "مجاني" أو "الأقوى"
    val icon: String = "✦",
    val webChat: Boolean = false // يعمل عبر الواجهة الرسمية داخل التطبيق
)

object ModelCatalog {

    val models = listOf(
        GlmModel(
            id = "glm-5.3-flash", nameAr = "GLM-5.3-Flash",
            descAr = "أحدث جيل GLM-5 متعدد الوسائط — يعمل هنا عبر الواجهة الرسمية لموقع Z.ai داخل التطبيق مباشرة، بلا مفتاح ولا رصيد",
            accent = 0xFF00D4FF, vision = true, thinking = true, badge = "واجهة رسمية ⚡", icon = "🌟",
            webChat = true
        ),
        GlmModel(
            id = "glm-5.3-flashx", nameAr = "GLM-5.3-FlashX",
            descAr = "النسخة المتسارعة 200 توكن/ثانية — نفس ذكاء الجيل الخامس باستجابة فورية للبرق",
            accent = 0xFF7C4DFF, vision = true, thinking = true, badge = "فائق السرعة", icon = "🚀"
        ),
        GlmModel(
            id = "glm-4.6", nameAr = "GLM-4.6", descAr = "العلم الرائد — أذكى نموذج للبرمجة والتحليل العميق",
            accent = 0xFF7C6BFF, thinking = true, badge = "الأقوى", icon = "👑"
        ),
        GlmModel(
            id = "glm-4.5", nameAr = "GLM-4.5", descAr = "متوازن وقوي للمحادثات العامة والمهام المعقدة",
            accent = 0xFF4E8CFF, thinking = true, icon = "◆"
        ),
        GlmModel(
            id = "glm-4.5-air", nameAr = "GLM-4.5-Air", descAr = "خفيف وسريع بجودة عالية — مثالي للاستخدام اليومي",
            accent = 0xFF00BFA6, icon = "✈"
        ),
        GlmModel(
            id = "glm-4.5-flash", nameAr = "GLM-4.5-Flash", descAr = "استجابة فورية كالبرق — مجاني للاستخدام",
            accent = 0xFFFFB300, badge = "مجاني", icon = "⚡"
        ),
        GlmModel(
            id = "glm-4.5v", nameAr = "GLM-4.5V", descAr = "نموذج الرؤية — يحلل الصور والملفات بعمق فائق",
            accent = 0xFFFF6D9D, vision = true, badge = "رؤية", icon = "👁"
        ),
        GlmModel(
            id = "glm-4-flash", nameAr = "GLM-4-Flash", descAr = "سريع ومجاني — مناسب للمحادثات القصيرة",
            accent = 0xFF9CCC65, badge = "مجاني", icon = "✧"
        ),
        GlmModel(
            id = "glm-4-plus", nameAr = "GLM-4-Plus", descAr = "دقة عالية في الفهم والصياغة العربية",
            accent = 0xFF26C6DA, icon = "✦"
        ),
        GlmModel(
            id = "glm-4-long", nameAr = "GLM-4-Long", descAr = "ذاكرة ضخمة — يحلل ملفات ومستندات طويلة جداً",
            accent = 0xFFFF8A65, badge = "طويل", icon = "📜"
        )
    )

    fun byId(id: String): GlmModel =
        models.firstOrNull { it.id == id } ?: models.first { it.id == "glm-4.5-flash" }

    fun default(): GlmModel = models.first { it.id == "glm-4.5-flash" } // يعمل فوراً ومجاني

    /** أول نموذج رؤية متاح — يستخدم للتفعيل التلقائي عند إرفاق صورة */
    fun visionModel(): GlmModel =
        models.firstOrNull { it.vision && !it.webChat }
            ?: models.first { it.vision }

    /** النموذج المجاني — يعمل حتى بلا رصيد على النقطة العادية */
    fun freeModel(): GlmModel = byId("glm-4.5-flash")

    fun isFree(id: String): Boolean = id == "glm-4.5-flash" || id == "glm-4-flash"

    /**
     * النماذج التي تغطيها «خطة البرمجة» من اشتراك Z.ai —
     * أياً كان النموذج المختار سيتحول لأقربها عند تفعيل وضع الخطة.
     * ملاحظة: النموذج الافتراضي للخطة هو GLM-4.6 (وليس GLM-5.3-Flash
     * لأن الأخير يعمل عبر الواجهة الرسمية داخل التطبيق).
     */
    const val CODING_PLAN_MODEL = "glm-4.6"
    fun codingPlanModel(): GlmModel = byId(CODING_PLAN_MODEL)

    fun isCodingPlanCompatible(id: String): Boolean =
        id == "glm-5.3-flash" || id == "glm-4.6" || id == "glm-4.5-air"

    /** رابط الواجهة الرسمية للمحادثة — يُفتح داخل التطبيق لنماذج webChat */
    const val WEB_CHAT_URL = "https://chat.z.ai/"

    /** هل هذا النموذج يعمل عبر الواجهة الرسمية؟ */
    fun isWebChat(id: String): Boolean = models.firstOrNull { it.id == id }?.webChat == true
}
