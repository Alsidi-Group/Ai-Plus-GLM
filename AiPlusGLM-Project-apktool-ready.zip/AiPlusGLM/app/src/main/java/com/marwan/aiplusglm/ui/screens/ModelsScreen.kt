package com.marwan.aiplusglm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marwan.aiplusglm.data.ModelCatalog
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.vm.AppViewModel

/**
 * قائمة النماذج — اللمس يفعّل النموذج فوراً ويعيد تلوين كل واجهة التطبيق بلونه المميز
 * (المتطلب: عند اختيار نموذج تتغير الواجهة ويتفعل تلقائياً)
 * نموذج webChat (مثل GLM-5.3-Flash) ينقل فوراً للواجهة الرسمية داخل التطبيق
 */
@Composable
fun ModelsScreen(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color,
    currentId: String,
    onOpenChat: () -> Unit = {}
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Spacer(Modifier.height(10.dp))
        Text("اختر نموذج الذكاء", color = theme.textPrimaryColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            "كل نموذج يعيد تلوين واجهتك بلونه الخاص ويتفعل فوراً",
            color = theme.textSecondaryColor, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            items(ModelCatalog.models) { model ->
                val selected = model.id == currentId
                val mc = Color(model.accent)
                Column(
                    Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(theme.surfaceColor.copy(alpha = if (selected) 0.95f else 0.6f))
                        .border(
                            if (selected) 2.dp else 1.dp,
                            if (selected) mc else theme.borderColor,
                            RoundedCornerShape(18.dp)
                        )
                        .clickable {
                            vm.setModel(model)
                            // نموذج الواجهة الرسمية → نقل فوري لمحادثة الويب داخل التطبيق
                            if (model.webChat) onOpenChat()
                        }
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(38.dp)
                                .background(Brush.linearGradient(listOf(mc, mc.copy(alpha = 0.5f))), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text(model.icon, fontSize = 16.sp) }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(model.nameAr, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            model.badge?.let {
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(mc.copy(alpha = 0.16f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) { Text(it, color = mc, fontSize = 9.sp) }
                            }
                        }
                        if (selected) {
                            Icon(Icons.Filled.CheckCircle, null, tint = mc, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(model.descAr, color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}
