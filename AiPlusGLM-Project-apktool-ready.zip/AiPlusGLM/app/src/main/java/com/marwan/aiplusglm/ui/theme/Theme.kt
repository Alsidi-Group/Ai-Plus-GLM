package com.marwan.aiplusglm.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.sin

/** ثيم كامل قابل للاختيار — 8 مظاهر فاخرة (المتطلب: العديد من المظاهر والخلفيات) */
data class AppTheme(
    val id: String,
    val nameAr: String,
    val isDark: Boolean,
    val bgTop: Long,
    val bgBottom: Long,
    val surface: Long,
    val surfaceBorder: Long,
    val textPrimary: Long,
    val textSecondary: Long,
    val accent: Long
) {
    val bgColorTop: Color get() = Color(bgTop)
    val bgColorBottom: Color get() = Color(bgBottom)
    val surfaceColor: Color get() = Color(surface)
    val borderColor: Color get() = Color(surfaceBorder)
    val textPrimaryColor: Color get() = Color(textPrimary)
    val textSecondaryColor: Color get() = Color(textSecondary)
    val accentColor: Color get() = Color(accent)
}

object Themes {
    val all = listOf(
        AppTheme("midnight", "منتصف الليل", true,
            0xFF0B1026, 0xFF1A1040, 0xFF161B35, 0xFF2A3157, 0xFFF3F5FF, 0xFF9BA3C7, 0xFF7C6BFF),
        AppTheme("libya", "ليبيا الليلية", true,
            0xFF071A12, 0xFF0E2A1C, 0xFF0F241A, 0xFF1E4030, 0xFFF0FFF7, 0xFF93B8A5, 0xFF00C896),
        AppTheme("aurora", "الشفق القطبي", true,
            0xFF04121F, 0xFF0A2E3D, 0xFF0B2233, 0xFF14405A, 0xFFEAFBFF, 0xFF8FB4C7, 0xFF00E5C7),
        AppTheme("ocean", "المحيط الأزرق", true,
            0xFF041428, 0xFF0A2A52, 0xFF0C2440, 0xFF16406E, 0xFFEFF7FF, 0xFF8FB0D0, 0xFF4E9BFF),
        AppTheme("royal", "الملكي البنفسجي", true,
            0xFF14051F, 0xFF2A0A45, 0xFF200A33, 0xFF3D1560, 0xFFF8F0FF, 0xFFB99BC9, 0xFFB36BFF),
        AppTheme("sunset", "الغروب الذهبي", true,
            0xFF1F0A05, 0xFF3D150A, 0xFF2E1009, 0xFF55241A, 0xFFFFF5EF, 0xFFCFA791, 0xFFFF8A50),
        AppTheme("soft", "الفاتح الناعم", false,
            0xFFF7F8FC, 0xFFEBEEF7, 0xFFFFFFFF, 0xFFE2E6F0, 0xFF141A2E, 0xFF5D6784, 0xFF5B5BFF),
        AppTheme("amoled", "الأسود الفاخر", true,
            0xFF000000, 0xFF0A0A0F, 0xFF101014, 0xFF23232B, 0xFFF5F5F7, 0xFF8E8E9A, 0xFF00D4AA)
    )

    fun byId(id: String): AppTheme = all.firstOrNull { it.id == id } ?: all[0]
}

/** أنماط الخلفية الزخرفية */
enum class BgPattern(val id: String, val nameAr: String) {
    NONE("none", "بدون"),
    DOTS("dots", "نقاط شبكية"),
    WAVES("waves", "أمواج حريرية"),
    GLOW("glow", "هالات متوهجة"),
    GRID("grid", "شبكة هندسية");

    companion object { fun byId(id: String): BgPattern = entries.firstOrNull { it.id == id } ?: NONE }
}

/** خلفية التطبيق: تدرج + نمط زخرفي مرسوم برمجياً */
@Composable
fun ThemedBackground(
    theme: AppTheme,
    pattern: BgPattern,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Box(modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(listOf(theme.bgColorTop, theme.bgColorBottom)))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val a = accent.copy(alpha = if (theme.isDark) 0.16f else 0.20f)
            when (pattern) {
                BgPattern.NONE -> {}
                BgPattern.DOTS -> {
                    val step = 46f
                    var y = 0f
                    var row = 0
                    while (y < size.height) {
                        var x = if (row % 2 == 0) 0f else step / 2
                        while (x < size.width) {
                            drawCircle(color = a, radius = 2.2f, center = Offset(x, y))
                            x += step
                        }
                        y += step; row++
                    }
                }
                BgPattern.WAVES -> {
                    for (i in 0 until 7) {
                        val amp = 42f + i * 14f
                        val yBase = size.height * (0.18f + i * 0.11f)
                        val path = Path()
                        var x = 0f
                        path.moveTo(0f, yBase)
                        while (x <= size.width) {
                            path.lineTo(x, yBase + sin(x / 160f + i) * amp)
                            x += 18f
                        }
                        drawPath(path, color = a.copy(alpha = 0.05f + i * 0.012f), style = Stroke(width = 1.6f))
                    }
                }
                BgPattern.GLOW -> {
                    val r = size.width * 0.55f
                    drawCircle(accent.copy(alpha = 0.10f), r * 0.9f, Offset(size.width * 0.15f, size.height * 0.12f))
                    drawCircle(theme.bgColorBottom.copy(alpha = 0.0f), 1f)
                    drawCircle(Color(0xFF7C6BFF).copy(alpha = 0.08f), r, Offset(size.width * 0.9f, size.height * 0.3f))
                    drawCircle(a, r * 0.7f, Offset(size.width * 0.4f, size.height * 0.85f))
                }
                BgPattern.GRID -> {
                    val step = 64f
                    var y = 0f
                    while (y < size.height) {
                        drawLine(a.copy(alpha = 0.35f), Offset(0f, y), Offset(size.width, y), 1f)
                        y += step
                    }
                    var x = 0f
                    while (x < size.width) {
                        drawLine(a.copy(alpha = 0.35f), Offset(x, 0f), Offset(x, size.height), 1f)
                        x += step
                    }
                }
            }
        }
    }
}
