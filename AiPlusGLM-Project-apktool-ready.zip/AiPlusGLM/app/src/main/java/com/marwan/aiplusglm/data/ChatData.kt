package com.marwan.aiplusglm.data

data class Attachment(
    val name: String,
    val mime: String,
    val kind: Kind,
    val base64: String? = null,   // للصور
    val textContent: String? = null // للملفات النصية
) {
    enum class Kind { IMAGE, TEXT, OTHER }

    val displaySize: String
        get() {
            val bytes = (base64?.length ?: 0) * 3 / 4 + (textContent?.toByteArray()?.size ?: 0)
            return when {
                bytes < 1024 -> "$bytes بايت"
                bytes < 1024 * 1024 -> "%.1f ك.ب".format(bytes / 1024f)
                else -> "%.1f م.ب".format(bytes / 1024f / 1024f)
            }
        }
}

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val role: Role,
    val content: String,
    val reasoning: String? = null,
    val attachments: List<Attachment> = emptyList(),
    val isError: Boolean = false,
    val time: Long = System.currentTimeMillis()
) {
    enum class Role { USER, ASSISTANT }

    val isUser: Boolean get() = role == Role.USER
}

data class Conversation(
    val id: String,
    val title: String,
    val modelId: String,
    val messages: List<ChatMessage>,
    val updatedAt: Long
)
