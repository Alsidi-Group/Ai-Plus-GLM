package com.marwan.aiplusglm.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.marwan.aiplusglm.data.GlmModel
import com.marwan.aiplusglm.data.ModelCatalog
import com.marwan.aiplusglm.ui.theme.AppTheme

/**
 * شاشة المحادثة عبر الواجهة الرسمية — عند اختيار نموذج webChat
 * (مثل GLM-5.3-Flash) تُفتح واجهة الموقع الرسمي chat.z.ai داخل
 * التطبيق مباشرة: بلا مفتاح API ولا رصيد، مع دعم رفع الملفات
 * والصور من الواجهة نفسها، والرجوع داخل تاريخ الموقع، وشريط تقدم.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebChatScreen(
    model: GlmModel,
    theme: AppTheme,
    accent: Color,
    cachedWebView: MutableState<WebView?>,
    onOpenModels: () -> Unit
) {
    val context = LocalContext.current
    val url = ModelCatalog.WEB_CHAT_URL

    // إن كان الـ WebView محفوظاً من زيارة سابقة نبدأ بحالة «تم التحميل» مباشرة
    val alreadyLoaded = cachedWebView.value != null
    var progress by remember { mutableIntStateOf(if (alreadyLoaded) 100 else 0) }
    var loading by remember { mutableStateOf(!alreadyLoaded) }
    var canGoBack by remember { mutableStateOf(false) }

    // رفع الملفات والصور من واجهة الموقع الرسمي
    var fileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val fileChooserLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        fileCallback?.onReceiveValue(uris ?: arrayOf())
        fileCallback = null
    }

    // زر الرجوع النظامي يعود داخل تاريخ الموقع أولاً قبل مغادرة الشاشة
    BackHandler(enabled = canGoBack) { cachedWebView.value?.goBack() }

    Column(Modifier.fillMaxSize()) {

        // ═══ شريط علوي: رجوع + هوية النموذج + تحديث + متصفح ═══
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.82f))
                .padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack, "رجوع",
                tint = theme.textPrimaryColor,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable {
                        val wv = cachedWebView.value
                        if (wv != null && wv.canGoBack()) wv.goBack() else onOpenModels()
                    }
                    .padding(8.dp)
            )
            Spacer(Modifier.width(4.dp))
            Box(
                Modifier
                    .size(32.dp)
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.55f))), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(model.icon, fontSize = 14.sp) }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "${model.nameAr} — الواجهة الرسمية",
                    color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    if (loading) "جاري تحميل واجهة Z.ai..." else "متصل بموقع Z.ai داخل التطبيق ✓",
                    color = accent, fontSize = 10.5.sp, maxLines = 1
                )
            }
            Icon(
                Icons.Filled.Refresh, "تحديث",
                tint = theme.textSecondaryColor,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable { cachedWebView.value?.reload() }
                    .padding(8.dp)
            )
            Icon(
                Icons.Filled.OpenInBrowser, "فتح في المتصفح",
                tint = theme.textSecondaryColor,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                    .padding(8.dp)
            )
        }

        // شريط التقدم أثناء التحميل
        if (loading && progress < 100) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().height(2.5.dp),
                color = accent,
                trackColor = Color.Transparent
            )
        }

        // ═══ الواجهة الرسمية للموقع داخل التطبيق ═══
        // الـ WebView يُحفظ في ذاكرة مشتركة — لا يُعاد تحميل الصفحة عند التنقل
        AndroidView(
            factory = { ctx ->
                val cached = cachedWebView.value
                if (cached != null) {
                    (cached.parent as? ViewGroup)?.removeView(cached)
                    cached
                } else {
                    WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    // إزالة علامة WebView من الوكيل — بعض المواقع تعرض إعلان «حمّل تطبيقنا» معها
                    settings.userAgentString = settings.userAgentString?.replace("; wv", "")

                    // الكوكيز — لتبقى الجلسة محفوظة بين المرات
                    val cm = android.webkit.CookieManager.getInstance()
                    cm.setAcceptCookie(true)
                    cm.setAcceptThirdPartyCookies(this, true)

                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView,
                            request: WebResourceRequest
                        ): Boolean {
                            val u = request.url.toString()
                            // مواقع Z.ai تبقى داخل التطبيق — الروابط الخارجية تفتح في المتصفح
                            val internal = u.contains("z.ai") || u.contains("zhipuai") ||
                                u.contains("bigmodel") || u.startsWith("about:") ||
                                u.startsWith("data:")
                            if (!internal) {
                                runCatching {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, request.url)
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                }
                                return true
                            }
                            return false
                        }

                        override fun onPageFinished(view: WebView, u: String) {
                            loading = false
                            canGoBack = view.canGoBack()
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView, newProgress: Int) {
                            progress = newProgress
                            if (newProgress >= 100) loading = false
                        }

                        override fun onShowFileChooser(
                            v: WebView,
                            callback: ValueCallback<Array<Uri>>,
                            params: FileChooserParams
                        ): Boolean {
                            fileCallback?.onReceiveValue(null)
                            fileCallback = callback
                            return try {
                                fileChooserLauncher.launch(params.createIntent())
                                true
                            } catch (e: Exception) {
                                fileCallback = null
                                false
                            }
                        }
                    }

                    loadUrl(url)
                    }.also { cachedWebView.value = it }
                }
            },
            update = { view -> canGoBack = view.canGoBack() },
            modifier = Modifier.fillMaxSize().weight(1f)
        )
    }
}
