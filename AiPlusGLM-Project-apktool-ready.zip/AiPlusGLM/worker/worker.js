/**
 * ═══════════════════════════════════════════════════════════════
 *  Ai Plus GLM — السيرفر الوسيط (Cloudflare Worker)
 *  يربط التطبيق مباشرة بموقع Z.ai الرسمي بدون إدخال أي مفتاح
 *  المفتاح يبقى محفوظاً هنا في السيرفر — آمن تماماً
 * ═══════════════════════════════════════════════════════════════
 *
 *  خطوات النشر (5 دقائق، مجاني):
 *  1. أنشئ حساباً على https://workers.cloudflare.com
 *  2. Workers & Pages → Create Worker → الصق هذا الكود كاملاً
 *  3. غيّر قيمة ZAI_API_KEY أدناه لمفتاحك من https://z.ai/model-api
 *  4. Deploy → انسخ رابطك مثل: https://aiplus-glm.xxx.workers.dev
 *  5. الصق الرابط في ZaiConfig.kt داخل EMBEDDED_PROXY_URL ثم أعد بناء التطبيق
 */

const ZAI_API_KEY = "PASTE_YOUR_ZAI_KEY_HERE"; // 🔴 الصق مفتاحك هنا فقط
const ZAI_BASE = "https://api.z.ai/api/paas/v4";

// كلمة مرور اختيارية للتطبيق (اتركها فارغة للجميع)
const ACCESS_TOKEN = "";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, Accept",
  "Access-Control-Max-Age": "86400",
};

export default {
  async fetch(request) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }

    // ── صفحة ترحيب عند فتح الرابط في المتصفح ──
    if (url.pathname === "/" && request.method === "GET") {
      return new Response(
        `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Ai Plus GLM — السيرفر الوسيط</title>
<style>body{font-family:system-ui;background:linear-gradient(160deg,#0b1026,#2a1560);color:#fff;
display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;text-align:center}
.c{max-width:520px;padding:40px}.b{font-size:64px}h1{margin:10px 0;font-size:28px}
.p{color:#9ba3c7;line-height:1.8}.ok{display:inline-block;background:#00c89622;color:#00e5c7;
padding:8px 22px;border-radius:99px;font-weight:700;margin-top:14px}</style></head>
<body><div class="c"><div class="b">💬</div><h1>Ai Plus GLM — السيرفر الوسيط يعمل</h1>
<p class="p">هذا السيرفر يربط تطبيق Ai Plus GLM بموقع Z.ai الرسمي<br>ويمرر المحادثات المتدفقة بأمان — المفتاح محفوظ هنا فقط</p>
<div class="ok">✓ جاهز — ضع هذا الرابط في ZaiConfig.kt</div>
<p class="p" style="font-size:13px">${url.hostname} • تطوير مروان السيدى 🇱🇾</p></div></body></html>`,
        { status: 200, headers: { "Content-Type": "text/html; charset=utf-8", ...CORS } }
      );
    }

    // ── فحص صحة ──
    if (url.pathname === "/health") {
      return Response.json({ ok: true, service: "aiplus-glm-proxy", version: "1.1.0" }, { headers: CORS });
    }

    // ── ملف التحديثات الديناميكي — عدّل متغيرات البيئة UPDATE_VERSION و UPDATE_URL و UPDATE_NOTES دون إعادة نشر الكود ──
    if (url.pathname === "/update.json") {
      const env = (request).cf?.env || {};
      return Response.json({
        app: "Ai Plus GLM",
        versionName: env.UPDATE_VERSION || "1.1.0",
        versionCode: parseInt(env.UPDATE_CODE || "2", 10),
        apkUrl: env.UPDATE_URL || "",
        whatsNew: env.UPDATE_NOTES || "",
      }, { headers: CORS });
    }

    // ── تمرير كل مسارات v4 إلى Z.ai الرسمية ──
    if (url.pathname.startsWith("/api/paas/v4") || url.pathname.startsWith("/v4")) {
      if (ACCESS_TOKEN) {
        const auth = request.headers.get("Authorization") || "";
        if (auth !== `Bearer ${ACCESS_TOKEN}`) {
          return Response.json({ error: { message: "رمز الوصول غير صحيح" } }, { status: 401, headers: CORS });
        }
      }

      const target = ZAI_BASE + url.pathname.replace(/^\/v4/, "").replace(/^\/api\/paas\/v4/, "");
      const headers = new Headers();
      headers.set("Authorization", `Bearer ${ZAI_API_KEY}`);
      headers.set("Content-Type", "application/json");
      headers.set("Accept", request.headers.get("Accept") || "application/json");

      const upstream = await fetch(target, {
        method: request.method,
        headers,
        body: request.method === "POST" ? request.body : undefined,
        // @ts-ignore — تمرير البث كما هو بدون تخزين مؤقت
        duplex: "half",
      });

      const respHeaders = new Headers(CORS);
      respHeaders.set("Content-Type", upstream.headers.get("Content-Type") || "application/json");

      if (upstream.body) {
        return new Response(upstream.body, { status: upstream.status, headers: respHeaders });
      }
      return new Response(await upstream.text(), { status: upstream.status, headers: respHeaders });
    }

    return Response.json({ error: { message: "مسار غير معروف" } }, { status: 404, headers: CORS });
  },
};
