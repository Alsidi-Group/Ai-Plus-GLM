package com.marwan.aiplusglm.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * خلفيات المحادثة الفخمة — 10 خلفيات تُطبق فورياً وتُحفظ تلقائياً
 * المطور: مروان السيدى | Marwan Alsidi - ليبيا 🇱🇾
 */

data class ChatBgDef(val id: String, val nameAr: String)

object ChatBackgrounds {

    val all: List<ChatBgDef> = listOf(
        ChatBgDef("classic", "الكلاسيكي الهادئ"),
        ChatBgDef("nebula", "السديم البنفسجي"),
        ChatBgDef("dusk", "الغسق الذهبي"),
        ChatBgDef("ocean", "المحيط العميق"),
        ChatBgDef("forest", "الغابة الزمردية"),
        ChatBgDef("royalgold", "الليل الملكي"),
        ChatBgDef("stars", "سماء النجوم"),
        ChatBgDef("grid", "الشبكة التقنية"),
        ChatBgDef("dots", "النقاط الأنيقة"),
        ChatBgDef("midnight", "منتصف الليل")
    )

    fun byId(id: String): ChatBgDef = all.firstOrNull { it.id == id } ?: all.first()
}

/** طبقة خلفية المحادثة — تُرسم خلف الرسائل وتتأقلم مع الوضع الليلي/النهاري */
@Composable
fun ChatBackgroundLayer(bgId: String, modifier: Modifier = Modifier) {
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val id = ChatBackgrounds.byId(bgId).id

    Box(modifier.fillMaxSize()) {
        when (id) {
            "classic" -> { /* لون الخلفية الأساسي */ }

            "nebula" -> Box(
                Modifier.fillMaxSize().background(
                    if (isDark) Brush.verticalGradient(listOf(Color(0xFF1A1040), Color(0xFF3B1E7A), Color(0xFF12102E)))
                    else Brush.verticalGradient(listOf(Color(0xFFE8E4FF), Color(0xFFF3EDFF), Color(0xFFF6F7FB)))
                )
            )

            "dusk" -> Box(
                Modifier.fillMaxSize().background(
                    if (isDark) Brush.verticalGradient(listOf(Color(0xFF2B1206), Color(0xFF4A1D3F), Color(0xFF1A0E2E)))
                    else Brush.verticalGradient(listOf(Color(0xFFFFF3E0), Color(0xFFFFE4EC), Color(0xFFF6F7FB)))
                )
            )

            "ocean" -> Box(
                Modifier.fillMaxSize().background(
                    if (isDark) Brush.verticalGradient(listOf(Color(0xFF06283D), Color(0xFF0B4F6C), Color(0xFF0A1931)))
                    else Brush.verticalGradient(listOf(Color(0xFFE0F7FA), Color(0xFFE3F2FD), Color(0xFFF6F7FB)))
                )
            )

            "forest" -> Box(
                Modifier.fillMaxSize().background(
                    if (isDark) Brush.verticalGradient(listOf(Color(0xFF052E1F), Color(0xFF0B3D2E), Color(0xFF071A12)))
                    else Brush.verticalGradient(listOf(Color(0xFFE8F5E9), Color(0xFFF1F8E9), Color(0xFFF6F7FB)))
                )
            )

            "royalgold" -> {
                Box(
                    Modifier.fillMaxSize().background(
                        if (isDark) Brush.verticalGradient(listOf(Color(0xFF0D0B1F), Color(0xFF1F1633), Color(0xFF0D0B1F)))
                        else Brush.verticalGradient(listOf(Color(0xFFFDF6E3), Color(0xFFFBEED0), Color(0xFFF6F7FB)))
                    )
                )
                Canvas(Modifier.fillMaxSize()) { drawGoldSheen(isDark) }
            }

            "stars" -> {
                Box(
                    Modifier.fillMaxSize().background(
                        if (isDark) Brush.verticalGradient(listOf(Color(0xFF05060F), Color(0xFF0D1030), Color(0xFF05060F)))
                        else Brush.verticalGradient(listOf(Color(0xFFE3E9FF), Color(0xFFF1F4FF), Color(0xFFF6F7FB)))
                    )
                )
                Canvas(Modifier.fillMaxSize()) { drawStars(isDark) }
            }

            "grid" -> Canvas(Modifier.fillMaxSize()) { drawGrid(isDark) }

            "dots" -> Canvas(Modifier.fillMaxSize()) { drawDots(isDark) }

            "midnight" -> if (isDark) {
                Box(Modifier.fillMaxSize().background(Color(0xFF050507)))
            }
        }
    }
}

/** وهج ذهبي قطري فخم */
private fun DrawScope.drawGoldSheen(isDark: Boolean) {
    val w = size.width
    val h = size.height
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(
                Color(0xFFF5C76A).copy(alpha = if (isDark) 0.14f else 0.22f),
                Color.Transparent,
                Color(0xFFF5C76A).copy(alpha = if (isDark) 0.08f else 0.14f)
            ),
            start = Offset(w * 0.15f, 0f),
            end = Offset(w * 0.85f, h)
        )
    )
}

/** سماء النجوم — نقاط لامعة موزعة عشوائياً بثبات */
private fun DrawScope.drawStars(isDark: Boolean) {
    val random = Random(42)
    val starColor = if (isDark) Color.White else Color(0xFF3D5AFE)
    repeat(90) { i ->
        val x = random.nextFloat() * size.width
        val y = random.nextFloat() * size.height
        val radius = (if (i % 7 == 0) 2.6f else 1.1f + random.nextFloat()) * (size.width / 1080f + 0.75f)
        drawCircle(
            color = starColor.copy(alpha = if (isDark) 0.25f + random.nextFloat() * 0.5f else 0.10f + random.nextFloat() * 0.15f),
            radius = radius,
            center = Offset(x, y)
        )
    }
}

/** الشبكة التقنية */
private fun DrawScope.drawGrid(isDark: Boolean) {
    val step = 34.dp.toPx()
    val lineColor = if (isDark) Color(0xFF7C9AFF).copy(alpha = 0.07f) else Color(0xFF3D5AFE).copy(alpha = 0.06f)
    var x = 0f
    while (x <= size.width) {
        drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1.2f)
        x += step
    }
    var y = 0f
    while (y <= size.height) {
        drawLine(lineColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.2f)
        y += step
    }
}

/** النقاط الأنيقة */
private fun DrawScope.drawDots(isDark: Boolean) {
    val step = 26.dp.toPx()
    val dotColor = if (isDark) Color(0xFFB39DFF).copy(alpha = 0.10f) else Color(0xFF7C4DFF).copy(alpha = 0.09f)
    var row = 0
    var y = step / 2f
    while (y <= size.height) {
        var x = step / 2f + (if (row % 2 == 1) step / 2f else 0f)
        while (x <= size.width) {
            drawCircle(dotColor, radius = 2.4f, center = Offset(x, y))
            x += step
        }
        y += step
        row++
    }
}
