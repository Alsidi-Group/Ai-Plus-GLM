package com.marwan.aiplusglm.vm

import android.app.Application
import android.content.Context
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.webkit.MimeTypeMap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.marwan.aiplusglm.BuildConfig
import com.marwan.aiplusglm.ZaiConfig
import com.marwan.aiplusglm.data.Attachment
import com.marwan.aiplusglm.data.ChatMessage
import com.marwan.aiplusglm.data.ChatStore
import com.marwan.aiplusglm.data.Conversation
import com.marwan.aiplusglm.data.KeyVault
import com.marwan.aiplusglm.data.ModelCatalog
import com.marwan.aiplusglm.data.GlmModel
import com.marwan.aiplusglm.data.AppLanguages
import com.marwan.aiplusglm.data.ZaiClient
import com.marwan.aiplusglm.ui.theme.DisplayMode
import com.marwan.aiplusglm.ui.theme.Themes
import com.marwan.aiplusglm.ui.theme.BgPattern
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Base64

private val Context.dataStore by preferencesDataStore(name = "aiplus_prefs")

/**
 * نموذج العرض الرئيسي — كل شيء يعمل عبر StateFlow وكوروتينات آمنة.
 * لا يوجد أي مسار كود يستطيع إسقاط التطبيق: كل الأخطاء تتحول لرسائل داخل المحادثة.
 */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    // ═══════════ تفضيلات الواجهة ═══════════
    private val _currentModel = MutableStateFlow(ModelCatalog.default())
    val currentModel: StateFlow<GlmModel> = _currentModel.asStateFlow()

    private val _themeId = MutableStateFlow(Themes.all[0].id)
    val themeId: StateFlow<String> = _themeId.asStateFlow()

    private val _patternId = MutableStateFlow(BgPattern.GLOW.id)
    val patternId: StateFlow<String> = _patternId.asStateFlow()

    private val _thinkingEnabled = MutableStateFlow(false)
    val thinkingEnabled: StateFlow<Boolean> = _thinkingEnabled.asStateFlow()

    private val _ttsEnabled = MutableStateFlow(false)
    val ttsEnabled: StateFlow<Boolean> = _ttsEnabled.asStateFlow()

    /** وضع العرض: نهاري ☀ / ليلي ☾ / تلقائي ◐ حسب النظام (المتطلب ⑥ من v1.3.0) */
    private val _displayMode = MutableStateFlow(DisplayMode.AUTO)
    val displayMode: StateFlow<DisplayMode> = _displayMode.asStateFlow()

    /** لغة التطبيق — تحدد لغة ردود الذكاء الاصطناعي والنطق (الميزة الجديدة v1.3.3) */
    private val _appLanguage = MutableStateFlow("ar")
    val appLanguage: StateFlow<String> = _appLanguage.asStateFlow()

    // ═══════════ حالة المحادثة ═══════════
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    private val _liveContent = MutableStateFlow("")
    val liveContent: StateFlow<String> = _liveContent.asStateFlow()

    private val _liveReasoning = MutableStateFlow("")
    val liveReasoning: StateFlow<String> = _liveReasoning.asStateFlow()

    private val _hasStartedChat = MutableStateFlow(false)
    val hasStartedChat: StateFlow<Boolean> = _hasStartedChat.asStateFlow()

    // ═══════════ المحادثات المحفوظة ═══════════
    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    /** آخر محادثة تم فتحها — تعرض في شريط المحادثة (المتطلب ⑦) */
    private val _lastConversation = MutableStateFlow<Conversation?>(null)
    val lastConversation: StateFlow<Conversation?> = _lastConversation.asStateFlow()

    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast.asStateFlow()

    // ═══════════ التحديثات ═══════════
    sealed class UpdateState {
        data object Idle : UpdateState()
        data object Loading : UpdateState()
        data class Available(val info: ZaiClient.UpdateInfo) : UpdateState()
        data object UpToDate : UpdateState()
        data class Failed(val message: String) : UpdateState()
    }

    private val _updateState = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val updateState: StateFlow<UpdateState> = _updateState.asStateFlow()

    // ═══════════ حالة الاتصال (المفتاح / السيرفر الوسيط) ═══════════
    private val _endpointReady = MutableStateFlow(false)
    val endpointReady: StateFlow<Boolean> = _endpointReady.asStateFlow()

    private val _showSetup = MutableStateFlow(false)
    val showSetup: StateFlow<Boolean> = _showSetup.asStateFlow()

    // ═══════════ بطاقة حلول الرصيد ═══════════
    // تظهر عند خطأ «Insufficient balance / no resource package» بعد استنفاد الحل التلقائي
    private val _balanceHelp = MutableStateFlow(false)
    val balanceHelp: StateFlow<Boolean> = _balanceHelp.asStateFlow()

    fun consumeBalanceHelp() { _balanceHelp.value = false }

    // وضع خطة البرمجة — يوجّه المفتاح لنقطة نهاية الاشتراك
    private val _codingMode = MutableStateFlow(false)
    val codingMode: StateFlow<Boolean> = _codingMode.asStateFlow()

    @Volatile
    private var userTouchedPrefs = false

    private var streamJob: Job? = null
    private var currentConvId: String = newConvId()
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        viewModelScope.launch { loadPrefs() }
        _conversations.value = ChatStore.loadAll(app)
        refreshEndpoint()
        // التفعيل مطلوب لمرة واحدة — تظهر شاشة التفعيل الأنيقة إن لم يوجد مفتاح
        _showSetup.value = !_endpointReady.value
        // المتطلب ⑦: آخر محادثة تُفتح تلقائياً عند بدء التطبيق مع استرجاع نموذجها
        _conversations.value.firstOrNull()?.let { last ->
            loadConversation(last)
        }
        initTts()
        // المتطلب ④ من v1.3.0: فحص تحديث صامت عند الإقلاع — بلا إزعاج عند فشل الشبكة
        viewModelScope.launch {
            runCatching { checkForUpdatesInternal(BuildConfig.VERSION_CODE) }
        }
    }

    private fun refreshEndpoint() {
        val app = getApplication<Application>()
        _codingMode.value = KeyVault.loadCodingMode(app)
        _endpointReady.value = ZaiConfig.resolveEndpoint(
            savedKey = KeyVault.loadKey(app),
            savedProxy = KeyVault.loadProxy(app),
            codingMode = _codingMode.value
        ).ready
    }

    /** تحضير نوع الاتصال من شاشة التفعيل — صامت (يُستدعى قبل saveCredentials) */
    fun prepareCredentials(codingPlan: Boolean) {
        val app = getApplication<Application>()
        KeyVault.saveCodingMode(app, codingPlan)
        _codingMode.value = codingPlan
        refreshEndpoint()
    }

    /** تبديل وضع خطة البرمجة من بطاقة الحلول — مع محاذاة النموذج تلقائياً */
    fun setCodingMode(on: Boolean) {
        prepareCredentials(on)
        if (on) {
            if (!ModelCatalog.isCodingPlanCompatible(_currentModel.value.id)) {
                val m = ModelCatalog.codingPlanModel()
                _currentModel.value = m
                savePref("model", m.id)
            }
            _toast.value = "🧩 وضع خطة البرمجة مفعّل — النماذج المتوافقة: GLM-5.3-Flash و GLM-4.6 و GLM-4.5-Air"
        } else {
            _toast.value = "🔑 عاد التطبيق لنقطة النهاية العادية"
        }
    }

    /** زر البطاقة: تحويل للنموذج المجاني وإعادة إرسال آخر رسالة */
    fun useFreeModelAndRetry() {
        val free = ModelCatalog.freeModel()
        _currentModel.value = free
        savePref("model", free.id)
        _balanceHelp.value = false
        retryLast()
    }

    /** زر البطاقة: تفعيل وضع خطة البرمجة وإعادة إرسال آخر رسالة */
    fun enableCodingModeAndRetry() {
        setCodingMode(true)
        _balanceHelp.value = false
        retryLast()
    }

    /** حفظ بيانات الاتصال من شاشة التفعيل — يُتحقق من صحتها أولاً */
    fun saveCredentials(key: String, proxy: String): Boolean {
        val k = key.trim()
        val p = proxy.trim()
        if (k.isBlank() && p.isBlank()) return false
        if (k.isNotBlank() && !k.startsWith("sk") && k.length < 20) return false
        if (p.isNotBlank() && !(p.startsWith("http://") || p.startsWith("https://"))) return false
        val app = getApplication<Application>()
        if (k.isNotBlank()) KeyVault.saveKey(app, k)
        if (p.isNotBlank()) KeyVault.saveProxy(app, p)
        refreshEndpoint()
        return _endpointReady.value
    }

    fun openSetup() { _showSetup.value = true }
    fun closeSetup() { if (_endpointReady.value) _showSetup.value = false }

    /** رسالة نجاح بعد حفظ المفتاح — تأكيد ودود أن كل شيء انطلق */
    fun notifyConnected() {
        _toast.value = "✓ تم التفعيل — المحادثة جاهزة الآن"
    }

    // ═══════════ التخزين ═══════════

    private suspend fun loadPrefs() {
        runCatching {
            if (userTouchedPrefs) return // المستخدم سبق التحميل — لا نلغي اختياره
            val p = getApplication<Application>().dataStore.data.first()
            _themeId.value = p[stringPreferencesKey("theme")] ?: Themes.all[0].id
            _patternId.value = p[stringPreferencesKey("pattern")] ?: BgPattern.GLOW.id
            val mid = p[stringPreferencesKey("model")] ?: ModelCatalog.default().id
            _currentModel.value = ModelCatalog.byId(mid)
            _thinkingEnabled.value = p[stringPreferencesKey("thinking")] == "1"
            _ttsEnabled.value = p[stringPreferencesKey("tts")] == "1"
            _displayMode.value = DisplayMode.byId(p[stringPreferencesKey("display_mode")] ?: "auto")
            _appLanguage.value = p[stringPreferencesKey("app_language")] ?: "ar"
        }
    }

    private fun savePref(key: String, value: String) {
        viewModelScope.launch {
            runCatching {
                getApplication<Application>().dataStore.edit { it[stringPreferencesKey(key)] = value }
            }
        }
    }

    // ═══════════ اختيار النموذج — تفعيل فوري وإعادة تلوين الواجهة ═══════════

    fun setModel(model: GlmModel) {
        _currentModel.value = model
        savePref("model", model.id)
        if (model.webChat) {
            _toast.value = "🌐 تم تفعيل الواجهة الرسمية chat.z.ai — المحادثة تعمل بلا مفتاح ولا رصيد"
        } else {
            _toast.value = "تم تفعيل نموذج ${model.nameAr} ✓"
        }
    }

    fun setTheme(id: String) { userTouchedPrefs = true; _themeId.value = id; savePref("theme", id) }
    fun setPattern(id: String) { userTouchedPrefs = true; _patternId.value = id; savePref("pattern", id) }
    fun setDisplayMode(mode: DisplayMode) { userTouchedPrefs = true; _displayMode.value = mode; savePref("display_mode", mode.id) }
    fun setThinking(on: Boolean) { userTouchedPrefs = true; _thinkingEnabled.value = on; savePref("thinking", if (on) "1" else "0") }
    fun setTts(on: Boolean) { userTouchedPrefs = true; _ttsEnabled.value = on; savePref("tts", if (on) "1" else "0") }

    /** تغيير لغة التطبيق — تُحفظ وتُطبق فوراً على الردود والنطق (v1.3.3) */
    fun setLanguage(id: String) {
        userTouchedPrefs = true
        _appLanguage.value = id
        savePref("app_language", id)
        _toast.value = "تم اختيار لغة ${AppLanguages.byId(id).nameAr} ${AppLanguages.byId(id).flag} — الردود والنطق ستتبعها"
    }

    fun consumeToast() { _toast.value = null }

    // ═══════════ المحادثة ═══════════

    fun newConversation() {
        if (_messages.value.isNotEmpty()) persistCurrent()
        currentConvId = newConvId()
        _messages.value = emptyList()
        _liveContent.value = ""
        _liveReasoning.value = ""
        _hasStartedChat.value = false
        _lastConversation.value = null
    }

    fun loadConversation(conv: Conversation) {
        if (_isStreaming.value) cancelStreaming()
        currentConvId = conv.id
        _messages.value = conv.messages
        _hasStartedChat.value = conv.messages.isNotEmpty()
        _lastConversation.value = conv
        // استرجاع نموذج المحادثة إن كان معروفاً
        if (conv.modelId.isNotBlank()) {
            val m = ModelCatalog.byId(conv.modelId)
            if (m.id == conv.modelId) _currentModel.value = m
        }
    }

    fun deleteConversation(conv: Conversation) {
        ChatStore.delete(getApplication(), conv.id)
        _conversations.value = _conversations.value.filter { it.id != conv.id }
        if (currentConvId == conv.id) newConversation()
    }

    private fun newConvId(): String = "c${System.currentTimeMillis()}"

    /** الإرسال الرئيسي — مدرع بالكامل ضد الانهيار */
    fun send(text: String, attachments: List<Attachment> = emptyList()) {
        dispatch(text, attachments, autoRetry = false)
    }

    /**
     * قلب الإرسال — عند autoRetry=true لا تُضاف رسالة المستخدم مجدداً
     * (هي موجودة في التاريخ بالفعل من المحاولة الأولى) ولا يُلمس النموذج المختار.
     */
    private fun dispatch(text: String, attachments: List<Attachment>, autoRetry: Boolean) {
        val content = text.trim()
        if (content.isBlank() && attachments.isEmpty()) return
        if (_isStreaming.value) return

        // بدون مفتاح/سيرفر → فتح شاشة التفعيل فوراً بدل رسالة خطأ جامدة
        if (!_endpointReady.value) {
            _showSetup.value = true
            _toast.value = "فعّل المحادثة أولاً — خطوة واحدة وتنطلق"
            return
        }

        if (!autoRetry) {
            // تفعيل تلقائي لنموذج الرؤية عند إرفاق صورة (المتطلب ③)
            val hasImage = attachments.any { it.kind == Attachment.Kind.IMAGE }
            if (hasImage && !_currentModel.value.vision) {
                val vision = ModelCatalog.visionModel()
                _currentModel.value = vision
                savePref("model", vision.id)
                _toast.value = "أرفقت صورة — تم تفعيل نموذج الرؤية ${vision.nameAr} تلقائياً"
            }

            val userMsg = ChatMessage(
                role = ChatMessage.Role.USER,
                content = content,
                attachments = attachments
            )
            _messages.value = _messages.value + userMsg
        }
        _hasStartedChat.value = true
        _liveContent.value = ""
        _liveReasoning.value = ""
        _isStreaming.value = true

        streamJob = viewModelScope.launch {
            var accContent = ""
            var accReasoning = ""
            var cancelledByUser = false
            var result: Result<String>? = null

            try {
                val endpoint = ZaiConfig.resolveEndpoint(
                    savedKey = KeyVault.loadKey(getApplication()),
                    savedProxy = KeyVault.loadProxy(getApplication()),
                    codingMode = _codingMode.value
                )
                result = ZaiClient.streamChat(
                    messages = _messages.value,
                    modelId = _currentModel.value.id,
                    thinkingEnabled = _thinkingEnabled.value,
                    endpoint = endpoint,
                    languageId = _appLanguage.value
                ) { deltaContent, deltaReasoning ->
                    // يُستدعى داخل هذا الكوروتين — تحديث آمن
                    if (deltaContent.isNotEmpty()) accContent += deltaContent
                    if (deltaReasoning.isNotEmpty()) accReasoning += deltaReasoning
                    _liveContent.value = accContent
                    _liveReasoning.value = accReasoning
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                // أوقفه المستخدم — نحتفظ بالجزء الواصل من الرد ثم نكمل الإلغاء بنظافة
                cancelledByUser = true
                if (accContent.isNotBlank()) {
                    appendAssistant(accContent, accReasoning.ifBlank { null }, stopped = true)
                }
                throw ce
            } finally {
                _isStreaming.value = false
                _liveContent.value = ""
                _liveReasoning.value = ""
                if (!cancelledByUser) persistCurrent()
            }

            // معالجة النتيجة بعد تحرير حالة البث — تتيح الحل التلقائي وإعادة الإرسال بأمان
            result?.fold(
                onSuccess = { full ->
                    val reply = if (full.isBlank()) accContent else full
                    appendAssistant(reply, accReasoning.ifBlank { null })
                    if (_ttsEnabled.value) speak(reply)
                },
                onFailure = { e ->
                    handleSendFailure(e, content, attachments, autoRetry)
                }
            )
        }
    }

    /**
     * معالج الأخطاء الذكي:
     * ① خطأ رصيد + نموذج مدفوع + النقطة العادية → تحويل صامت للنموذج المجاني GLM-4.5-Flash وإعادة إرسال فورية
     * ② خطأ رصيد مع النموذج المجاني أو وضع الخطة → بطاقة «حلول الرصيد» التفاعلية
     * ③ أي خطأ آخر → فقاعة خطأ عادية
     */
    private fun handleSendFailure(e: Throwable, text: String, attachments: List<Attachment>, autoRetry: Boolean) {
        val balance = (e as? ZaiClient.ApiException)?.code == ZaiClient.CODE_BALANCE

        if (balance && !autoRetry && !_codingMode.value && !ModelCatalog.isFree(_currentModel.value.id)) {
            val prev = _currentModel.value
            val free = ModelCatalog.freeModel()
            _currentModel.value = free
            savePref("model", free.id)
            _toast.value = "💳 الرصيد لا يغطي ${prev.nameAr} — تحويل تلقائي إلى ${free.nameAr} المجاني وجارٍ الإرسال"
            dispatch(text, attachments, autoRetry = true)
            return
        }

        if (balance) {
            _balanceHelp.value = true
            appendAssistant(ZaiClient.BALANCE_MESSAGE, null, isError = true)
            return
        }

        appendAssistant("⚠️ ${e.message ?: "خطأ غير معروف"}", null, isError = true)
    }

    fun cancelStreaming() {
        ZaiClient.cancelActive() // يقطع القراءة المحجوبة فوراً
        streamJob?.cancel()
        _isStreaming.value = false
    }

    fun retryLast() {
        val msgs = _messages.value
        val lastUser = msgs.lastOrNull { it.isUser } ?: return
        val idx = msgs.indexOf(lastUser)
        _messages.value = msgs.subList(0, idx)
        send(lastUser.content, lastUser.attachments)
    }

    private fun appendAssistant(content: String, reasoning: String?, isError: Boolean = false, stopped: Boolean = false) {
        val suffix = if (stopped) "\n\n⏹ (أوقفتَ التوليد)" else ""
        _messages.value = _messages.value + ChatMessage(
            role = ChatMessage.Role.ASSISTANT,
            content = content + suffix,
            reasoning = reasoning,
            isError = isError
        )
    }

    private fun persistCurrent() {
        val msgs = _messages.value
        if (msgs.isEmpty()) return
        val conv = Conversation(
            id = currentConvId,
            title = msgs.firstOrNull { it.isUser }?.content?.take(40)?.ifBlank { "محادثة" } ?: "محادثة",
            modelId = _currentModel.value.id,
            messages = msgs,
            updatedAt = System.currentTimeMillis()
        )
        ChatStore.save(getApplication(), conv)
        _conversations.value = ChatStore.loadAll(getApplication())
        _lastConversation.value = conv
    }

    // ═══════════ النطق الصوتي للردود ═══════════

    private fun initTts() {
        runCatching {
            tts = TextToSpeech(getApplication()) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                if (ttsReady) runCatching { tts?.language = java.util.Locale("ar") }
            }
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        runCatching {
            // النطق يتبع لغة التطبيق المختارة (v1.3.3)
            tts?.language = java.util.Locale(AppLanguages.byId(_appLanguage.value).id)
            tts?.speak(text.take(1200), TextToSpeech.QUEUE_FLUSH, null, "reply")
        }
    }

    override fun onCleared() {
        runCatching { tts?.shutdown() }
        super.onCleared()
    }

    // ═══════════ قراءة الملفات المرفقة (تحليل عميق) ═══════════

    suspend fun readAttachment(uri: Uri): Attachment? = withContext(Dispatchers.IO) {
        runCatching {
            val cr = getApplication<Application>().contentResolver
            val name = queryName(cr, uri) ?: "ملف"
            val mime = cr.getType(uri) ?: guessMime(name)
            val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: return@runCatching null

            if (bytes.size > 10 * 1024 * 1024) {
                _toast.value = "الملف أكبر من 10 م.ب — تم تجاهله"
                return@runCatching null
            }

            when {
                mime.startsWith("image/") -> Attachment(
                    name = name, mime = mime, kind = Attachment.Kind.IMAGE,
                    base64 = Base64.getEncoder().encodeToString(bytes)
                )
                isTextLike(mime, name) -> Attachment(
                    name = name, mime = mime, kind = Attachment.Kind.TEXT,
                    textContent = String(bytes, Charsets.UTF_8).take(60000)
                )
                else -> {
                    _toast.value = "صيغة $name غير مدعومة للتحليل — الصور والملفات النصية فقط"
                    null
                }
            }
        }.getOrNull()
    }

    private fun isTextLike(mime: String, name: String): Boolean {
        if (mime.startsWith("text/")) return true
        if (mime.contains("json") || mime.contains("xml") || mime.contains("csv")) return true
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("txt", "md", "json", "xml", "csv", "html", "css", "js", "ts", "kt", "java", "py", "c", "cpp", "h", "sh", "yml", "yaml", "log", "sql", "php", "rb", "go", "rs", "swift", "gradle", "properties", "toml")
    }

    private fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun queryName(cr: android.content.ContentResolver, uri: Uri): String? = runCatching {
        cr.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }
    }.getOrNull()

    // ═══════════ البحث عن تحديثات ═══════════

    fun checkForUpdates(currentVersionCode: Int) {
        _updateState.value = UpdateState.Loading
        viewModelScope.launch { checkForUpdatesInternal(currentVersionCode) }
    }

    /** الفحص الفعلي — يُستخدم يدوياً وصامتاً عند الإقلاع (الفشل الصامت لا يغيّر الحالة) */
    private suspend fun checkForUpdatesInternal(currentVersionCode: Int) {
        ZaiClient.checkForUpdates(currentVersionCode).fold(
            onSuccess = { info ->
                if (info != null) _updateState.value = UpdateState.Available(info)
                else if (_updateState.value != UpdateState.Idle) _updateState.value = UpdateState.UpToDate
            },
            onFailure = { e ->
                // الصامت: يبقى Idle بلا رسائل فاشلة عند الإقلاع
                if (_updateState.value != UpdateState.Idle) {
                    _updateState.value = UpdateState.Failed(e.message ?: "تعذر الفحص")
                }
            }
        )
    }

    fun consumeUpdateState() { _updateState.value = UpdateState.Idle }
}
