package com.marwan.aiplusglm.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.ui.theme.BgPattern
import com.marwan.aiplusglm.ui.theme.DisplayMode
import com.marwan.aiplusglm.ui.theme.Themes
import com.marwan.aiplusglm.data.AppLanguages
import com.marwan.aiplusglm.vm.AppViewModel

/**
 * الإعدادات (v1.3.3):
 * ① خانة «المظهر» — قائمة مخصصة تتوسع وتنطوي تضم المظاهر الثمانية وأنماط الخلفية
 * ② وضع العرض: نهاري ☀ / ليلي ☾ / تلقائي ◐ حسب إعدادات النظام
 * ③ خانة «اللغة» — قائمة منفصلة تتوسع وتنطوي بـ 9 لغات وعلم لكل لغة (طلب المستخدم)
 * ④ مركز الأذونات الحقيقية — قائمة منفصلة تتوسع وتنطوي بأزرار طلب فعّالة
 * ⑤ زر رجوع في الأعلى + تفضيلات المحادثة
 */
@Composable
fun SettingsScreen(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color,
    thinking: Boolean,
    tts: Boolean,
    onBack: () -> Unit
) {
    val scroll = rememberScrollState()
    val selectedThemeId by vm.themeId.collectAsState()
    val selectedPatternId by vm.patternId.collectAsState()
    val displayMode by vm.displayMode.collectAsState()
    val appLanguage by vm.appLanguage.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(horizontal = 14.dp)
            .padding(bottom = 90.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        // رأس الشاشة مع زر الرجوع (المتطلب ④ v1.4.0)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = theme.textPrimaryColor)
            }
            Text("الإعدادات", color = theme.textPrimaryColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))

        // ═══════════ خانة المظهر — قائمة تتوسع وتنغلق (المتطلب ② v1.3.0) ═══════════
        var appearanceOpen by remember { mutableStateOf(false) }

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.72f))
                .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            // رأس القائمة — يعرض المظهر الحالي ووضع العرض دائماً
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { appearanceOpen = !appearanceOpen }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // عيّنة المظهر الحالي
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Themes.byId(selectedThemeId).bgColorTop, Themes.byId(selectedThemeId).bgColorBottom)
                            )
                        )
                        .border(1.dp, theme.borderColor, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(13.dp).background(Themes.byId(selectedThemeId).accentColor, CircleShape))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("المظهر", color = theme.textPrimaryColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${Themes.byId(selectedThemeId).nameAr} · ${displayMode.label}",
                        color = theme.textSecondaryColor, fontSize = 11.5.sp
                    )
                }
                Icon(
                    if (appearanceOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    "توسيع", tint = accent, modifier = Modifier.size(24.dp)
                )
            }

            // محتوى القائمة — يتوسع وينغلق بحركة سلسة
            AnimatedVisibility(
                visible = appearanceOpen,
                enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                exit = shrinkVertically(tween(220)) + fadeOut(tween(180))
            ) {
                Column(Modifier.padding(horizontal = 14.dp).padding(bottom = 14.dp)) {
                    // وضع العرض: تلقائي / نهاري / ليلي (المتطلب ⑥ v1.3.0)
                    Text("وضع العرض", color = theme.textPrimaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        DisplayMode.entries.forEach { m ->
                            val selected = displayMode == m
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(if (selected) accent.copy(alpha = 0.2f) else theme.surfaceColor.copy(alpha = 0.6f))
                                    .border(1.dp, if (selected) accent else theme.borderColor, RoundedCornerShape(11.dp))
                                    .clickable { vm.setDisplayMode(m) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) { Text(m.label, color = if (selected) accent else theme.textSecondaryColor, fontSize = 11.5.sp) }
                        }
                    }

                    Spacer(Modifier.height(13.dp))
                    Text("المظاهر الثمانية", color = theme.textPrimaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))

                    // شبكة المظاهر — المظهر النشط يُعلّم بعلامة صح
                    for (row in Themes.all.chunked(4)) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            row.forEach { t ->
                                ThemeCard(t, selectedThemeId == t.id, Modifier.weight(1f)) { vm.setTheme(t.id) }
                            }
                            if (row.size < 4) repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text("نمط الخلفية", color = theme.textPrimaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BgPattern.entries.forEach { p ->
                            val selected = selectedPatternId == p.id
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) accent.copy(alpha = 0.2f) else theme.surfaceColor.copy(alpha = 0.6f))
                                    .border(1.dp, if (selected) accent else theme.borderColor, RoundedCornerShape(10.dp))
                                    .clickable { vm.setPattern(p.id) }
                                    .padding(horizontal = 10.dp, vertical = 7.dp)
                            ) { Text(p.nameAr, color = if (selected) accent else theme.textSecondaryColor, fontSize = 11.sp) }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("الاتصال", color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        // بطاقة حالة الاتصال — بديل أنيق لخانة المفتاح القديمة
        val connected by vm.endpointReady.collectAsState()
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (connected) Color(0xFF4CAF50).copy(alpha = 0.1f) else Color(0xFFFF7043).copy(alpha = 0.12f))
                .border(1.dp, if (connected) Color(0xFF4CAF50).copy(alpha = 0.5f) else Color(0xFFFF7043).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                .clickable { vm.openSetup() }
                .padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (connected) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                null,
                tint = if (connected) Color(0xFF4CAF50) else Color(0xFFFF7043),
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (connected) "متصل — المحادثة مفعّلة ✓" else "غير مفعّل — المحادثة مقفلة",
                    color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    if (connected) "اضغط لتغيير المفتاح أو السيرفر الوسيط" else "اضغط هنا للتفعيل — خطوة واحدة فقط",
                    color = theme.textSecondaryColor, fontSize = 11.sp
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("تفضيلات المحادثة", color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        SettingSwitch(
            icon = { Icon(Icons.Filled.Psychology, null, tint = accent, modifier = Modifier.size(20.dp)) },
            title = "التفكير العميق",
            subtitle = "يتيح للنماذج المتقدمة التفكير قبل الإجابة (أبطأ لكن أدق)",
            checked = thinking,
            accent = accent, theme = theme
        ) { vm.setThinking(it) }

        Spacer(Modifier.height(8.dp))
        SettingSwitch(
            icon = { Icon(Icons.Filled.VolumeUp, null, tint = accent, modifier = Modifier.size(20.dp)) },
            title = "نطق الردود صوتياً",
            subtitle = "قراءة ردود الذكاء الاصطناعي بالعربية تلقائياً",
            checked = tts,
            accent = accent, theme = theme
        ) { vm.setTts(it) }

        Spacer(Modifier.height(20.dp))
        // ═══════════ خانة اللغة — قائمة منفصلة تتوسع وتنطوي (الميزة الجديدة v1.3.3) ═══════════
        var langOpen by remember { mutableStateOf(false) }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.72f))
                .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            // رأس القائمة — يعرض اللغة الحالية بعلمها دائماً
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { langOpen = !langOpen }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // العلم الحالي داخل بطاقة صغيرة
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(theme.bgColorTop.copy(alpha = 0.6f))
                        .border(1.dp, theme.borderColor, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) { Text(AppLanguages.byId(appLanguage).flag, fontSize = 21.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("لغة التطبيق", color = theme.textPrimaryColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${AppLanguages.byId(appLanguage).nameAr} ${AppLanguages.byId(appLanguage).flag} · الردود والنطق يتبعانها",
                        color = theme.textSecondaryColor, fontSize = 11.5.sp
                    )
                }
                Icon(
                    if (langOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    "توسيع", tint = accent, modifier = Modifier.size(24.dp)
                )
            }

            // محتوى القائمة — يتوسع وينطوي بحركة سلسة
            AnimatedVisibility(
                visible = langOpen,
                enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                exit = shrinkVertically(tween(220)) + fadeOut(tween(180))
            ) {
                Column(Modifier.padding(horizontal = 14.dp).padding(bottom = 14.dp)) {
                    Text("اختر اللغة — ردود الذكاء الاصطناعي والنطق الصوتي ستتبعها فوراً",
                        color = theme.textPrimaryColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(9.dp))

                    // شبكة اللغات التسع — 3 صفوف × 3 أعمدة، كل بطاقة بعلمها
                    for (row in AppLanguages.all.chunked(3)) {
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { lang ->
                                LanguageCard(
                                    lang = lang,
                                    selected = appLanguage == lang.id,
                                    theme = theme,
                                    accent = accent,
                                    modifier = Modifier.weight(1f)
                                ) { vm.setLanguage(lang.id) }
                            }
                            if (row.size < 3) repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }

                    Spacer(Modifier.height(2.dp))
                    Text(
                        "العربية ترتفع بعلم ليبيا 🇱🇾 — لغة المطور والمشروع",
                        color = theme.textSecondaryColor, fontSize = 10.5.sp, lineHeight = 15.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        // ═══════════ خانة الأذونات والصلاحيات — قائمة منفصلة تتوسع وتنطوي ═══════════
        var permsOpen by remember { mutableStateOf(false) }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.72f))
                .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            // رأس القائمة — اضغطه للتوسيع أو الطوي
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { permsOpen = !permsOpen }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Security, null, tint = accent, modifier = Modifier.size(21.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("الأذونات والصلاحيات", color = theme.textPrimaryColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "ست صلاحيات حقيقية يمنحها النظام — اضغط للتوسع وطلب كل واحدة",
                        color = theme.textSecondaryColor, fontSize = 11.5.sp
                    )
                }
                Icon(
                    if (permsOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    "توسيع", tint = accent, modifier = Modifier.size(24.dp)
                )
            }

            // محتوى القائمة — يتوسع وينطوي بحركة سلسة
            AnimatedVisibility(
                visible = permsOpen,
                enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                exit = shrinkVertically(tween(220)) + fadeOut(tween(180))
            ) {
                Column(Modifier.padding(horizontal = 10.dp).padding(bottom = 12.dp)) {
                    PermissionCenter(theme, accent)
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "مفتاحك محفوظ على جهازك فقط داخل مساحة التطبيق الخاصة — لا يُشارك مع أي جهة.",
            color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 16.sp
        )
    }
}

// ═════════════════════ مركز الأذونات الحقيقية ═════════════════════

@Composable
private fun PermissionCenter(theme: AppTheme, accent: Color) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }

    fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    // ── ① الإشعارات ──
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    PermissionRow(
        icon = Icons.Filled.Notifications, accent = accent, theme = theme,
        title = "قراءة الإشعارات",
        subtitle = {
            val prefs = context.getSharedPreferences("aiplus_permissions", Context.MODE_PRIVATE)
            val connectedListener = prefs.getBoolean("notif_listener_connected", false)
            val lastTitle = prefs.getString("notif_last_title", null)
            val count = prefs.getInt("notif_count", 0)
            when {
                connectedListener && lastTitle != null ->
                    "مفعّلة ✓ — آخر إشعار: «${lastTitle.take(28)}» (${count} إشعار مقروء)"
                connectedListener -> "مفعّلة ✓ — جاهزة لقراءة إشعارات الجهاز"
                else -> "لم تُمنح بعد — اضغط ثم فعّلها من إعدادات النظام"
            }
        },
        grantedState = { Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS) },
        buttonText = { if (Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)) "مستمع الإشعارات" else "طلب الصلاحية" }
    ) {
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            // فتح شاشة منح «قراءة الإشعارات» في إعدادات النظام
            runCatching {
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    // ── ② حالة الاتصال بالإنترنت (WiFi أو بيانات الهاتف) ──
    PermissionRow(
        icon = Icons.Filled.Wifi, accent = accent, theme = theme,
        title = "حالة الاتصال بالإنترنت",
        subtitle = {
            val connText = connectionTypeText(context)
            "ممنوحة تلقائياً ✓ — الحالة الآن: $connText"
        },
        grantedState = { granted(Manifest.permission.ACCESS_NETWORK_STATE) },
        buttonText = { "تحديث الحالة" }
    ) { refresh++ }

    // ── ③ قراءة الملفات والتعديل عليها ──
    val allFiles = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh++ }
    val mediaPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    PermissionRow(
        icon = Icons.Filled.Folder, accent = accent, theme = theme,
        title = "قراءة الملفات والتعديل عليها",
        subtitle = {
            if (Build.VERSION.SDK_INT >= 30) {
                val manage = runCatching { android.os.Environment.isExternalStorageManager() }.getOrDefault(false)
                if (manage) "ممنوحة ✓ — وصول كامل لكل الملفات (قراءة وتعديل)"
                else "لم تُمنح — اضغط للسماح بالوصول لكل الملفات"
            } else if (granted(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                "ممنوحة ✓ — قراءة وتعديل ملفات الهاتف"
            } else "لم تُمنح بعد — اضغط لطلبها"
        },
        grantedState = {
            (Build.VERSION.SDK_INT >= 30 && runCatching { android.os.Environment.isExternalStorageManager() }.getOrDefault(false)) ||
                granted(Manifest.permission.READ_EXTERNAL_STORAGE)
        },
        buttonText = { "منح الوصول" }
    ) {
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                allFiles.launch(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }.onFailure {
                runCatching { allFiles.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        } else {
            mediaPerms.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }

    // ── ④ رفع ملفات الهاتف ──
    val uploadTest = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        refresh++
        if (uri != null) {
            android.widget.Toast.makeText(context, "✓ تم اختيار الملف — جاهز للرفع والتحليل في المحادثة", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    PermissionRow(
        icon = Icons.Filled.UploadFile, accent = accent, theme = theme,
        title = "رفع ملفات الهاتف",
        subtitle = { "تعمل عبر منتقي النظام — بلا صلاحيات حساسة • اضغط لتجربة رفع ملف الآن" },
        grantedState = { true },
        buttonText = { "تجربة الرفع" }
    ) { uploadTest.launch("*/*") }

    // ── ⑤ الكاميرا والصوت والتسجيل ──
    val avPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    PermissionRow(
        icon = Icons.Filled.PhotoCamera, accent = accent, theme = theme,
        title = "الكاميرا والصوت والتسجيل",
        subtitle = {
            val cam = granted(Manifest.permission.CAMERA)
            val mic = granted(Manifest.permission.RECORD_AUDIO)
            when {
                cam && mic -> "ممنوحة ✓ — التصوير والتسجيل جاهزان في المحادثة"
                cam -> "الكاميرا ✓ — الميكروفون لم يُمنح"
                mic -> "الميكروفون ✓ — الكاميرا لم تُمنح"
                else -> "لم تُمنح — تُستخدم لالتقاط الصور وإدخال الصوت"
            }
        },
        grantedState = { granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO) },
        buttonText = { if (granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO)) "ممنوحة ✓" else "طلب الصلاحيتين" }
    ) {
        if (!(granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO))) {
            avPerms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    // ── ⑥ موقع GPS الدقيق ──
    val locationPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    PermissionRow(
        icon = Icons.Filled.LocationOn, accent = accent, theme = theme,
        title = "موقع GPS الدقيق",
        subtitle = {
            if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
                val loc = lastKnownLocation(context)
                if (loc != null) "ممنوحة ✓ — الموقع: ${"%.4f".format(loc.first)}, ${"%.4f".format(loc.second)}"
                else "ممنوحة ✓ — افتح خرائط الهاتف مرة ثم عد للحصول على الإحداثيات"
            } else "لم تُمنح — لخدمات الموقع الذكية والردود المترجمة محلياً"
        },
        grantedState = { granted(Manifest.permission.ACCESS_FINE_LOCATION) },
        buttonText = { if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) "تحديث الموقع" else "طلب الصلاحية" }
    ) { locationPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }

    key(refresh) { Spacer(Modifier.height(2.dp)) }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    accent: Color,
    theme: AppTheme,
    title: String,
    subtitle: @Composable () -> String,
    grantedState: () -> Boolean,
    buttonText: () -> String,
    onClick: () -> Unit
) {
    val ok = grantedState()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(
                1.dp,
                if (ok) Color(0xFF4CAF50).copy(alpha = 0.45f) else theme.borderColor,
                RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(36.dp).background(
                if (ok) Color(0xFF4CAF50).copy(alpha = 0.15f) else accent.copy(alpha = 0.15f),
                CircleShape
            ),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (ok) Icons.Filled.CheckCircle else icon, null,
                tint = if (ok) Color(0xFF4CAF50) else accent, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            Text(subtitle(), color = theme.textSecondaryColor, fontSize = 10.5.sp, lineHeight = 14.sp)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (ok) Color(0xFF4CAF50).copy(alpha = 0.14f) else accent.copy(alpha = 0.16f))
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = 7.dp)
        ) {
            Text(buttonText(), color = if (ok) Color(0xFF4CAF50) else accent, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ═════════════════════ أدوات مساعدة للأذونات ═════════════════════

/** نوع الاتصال الحالي: WiFi أو بيانات الهاتف أو غير متصل (المتطلب ②) */
private fun connectionTypeText(context: Context): String = runCatching {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    when {
        caps == null -> "غير متصل"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "متصل عبر WiFi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "متصل عبر بيانات الهاتف"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "متصل عبر الإيثرنت"
        else -> "متصل"
    }
}.getOrDefault("غير معروف")

/** آخر موقع معروف من GPS أو الشبكة (المتطلب ⑥) */
private fun lastKnownLocation(context: Context): Pair<Double, Double>? = runCatching {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) return@runCatching null
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val gps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
    val net = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
    val loc = gps ?: net ?: return@runCatching null
    loc.latitude to loc.longitude
}.getOrNull()

// ═════════════════════ بطاقة لغة — العلم والاسم واسمها الأصلي ═════════════════════

@Composable
private fun LanguageCard(
    lang: com.marwan.aiplusglm.data.AppLanguage,
    selected: Boolean,
    theme: AppTheme,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) accent else theme.borderColor,
                RoundedCornerShape(13.dp)
            )
            .background(if (selected) accent.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(lang.flag, fontSize = 24.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            lang.nameAr,
            color = if (selected) accent else theme.textPrimaryColor,
            fontSize = 11.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            lang.nativeName,
            color = theme.textSecondaryColor,
            fontSize = 9.sp, maxLines = 1
        )
    }
}

// ═════════════════════ عناصر واجهة عامة ═════════════════════

@Composable
private fun ThemeCard(t: AppTheme, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) t.accentColor else t.borderColor,
                RoundedCornerShape(13.dp)
            )
            .background(if (selected) t.accentColor.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Brush.verticalGradient(listOf(Color(t.bgTop), Color(t.bgBottom))))
        ) {
            Box(
                Modifier.align(Alignment.Center).size(14.dp).background(Color(t.accent), CircleShape)
            )
            // علامة صح على المظهر النشط
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(3.dp)
                        .size(15.dp)
                        .background(t.accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.CheckCircle, null,
                        tint = Color.White, modifier = Modifier.size(11.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            t.nameAr,
            color = if (selected) t.accentColor else Color(t.textPrimary),
            fontSize = 10.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun SettingSwitch(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    checked: Boolean,
    accent: Color,
    theme: AppTheme,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent,
                uncheckedThumbColor = theme.textSecondaryColor,
                uncheckedTrackColor = theme.borderColor
            )
        )
    }
}
