package com.marwan.aiplusglm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.vm.AppViewModel

/**
 * حول التطبيق (v1.4.0):
 * ① خانة «الترخيص» — نافذة منبثقة بنص رخصة MIT المدمجة داخل التطبيق
 * ② زر «البحث عن تحديثات» في الأسفل (نُقل من الإعدادات — المتطلب ② v1.3.0)
 * ③ زر رجوع في الأعلى (المتطلب ④ v1.4.0)
 */
@Composable
fun AboutScreen(
    theme: AppTheme,
    accent: Color,
    versionName: String,
    updateState: AppViewModel.UpdateState,
    onCheckUpdates: () -> Unit,
    onOpenUrl: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var showLicense by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            // زر الرجوع في الأعلى — يعود للمحادثة تلقائياً (المتطلب ④ v1.4.0)
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = theme.textPrimaryColor)
                }
                Spacer(Modifier.width(2.dp))
                Text("حول التطبيق", color = theme.textPrimaryColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }

            Box(
                Modifier
                    .size(88.dp)
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.5f))), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("Ai", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black) }

            Spacer(Modifier.height(14.dp))
            Text("Ai Plus GLM", color = theme.textPrimaryColor, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("الإصدار $versionName", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "تطبيق الذكاء الاصطناعي Ai Plus GLM هوا مساعدك ورفيقك الذكي في كل شي. (الاصدار المتطور ✅)",
                color = theme.textSecondaryColor, fontSize = 13.sp, lineHeight = 20.sp, textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(22.dp))

            // بطاقة المطور
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(theme.surfaceColor.copy(alpha = 0.75f))
                    .border(1.dp, theme.borderColor, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text("المطور", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text("مروان السيدى — Marwan Alsidi", color = theme.textPrimaryColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("ليبيا 🇱🇾", color = theme.textSecondaryColor, fontSize = 13.sp)
            }

            Spacer(Modifier.height(12.dp))

            LinkRow(Icons.Filled.Language, "الموقع الرسمي — chat.z.ai", "المحادثة عبر الويب مباشرة من التطبيق", theme, accent) { onOpenUrl("https://chat.z.ai") }
            LinkRow(Icons.Filled.Code, "وثائق المطورين — docs.z.ai", "الحصول على مفتاح API ومرجع النماذج", theme, accent) { onOpenUrl("https://docs.z.ai") }
            LinkRow(Icons.Filled.Star, "نماذج GLM المتاحة", "10 نماذج: من Flash المجاني إلى 4.6 الرائد", theme, accent) { onOpenUrl("https://docs.z.ai/guides/llm/glm-4.6") }

            // ═══ خانة الترخيص (المتطلب ② v1.3.0) ═══
            LinkRow(
                Icons.Filled.Description,
                "الترخيص",
                "رخصة MIT مفتوحة المصدر — اضغط لعرض النص كاملاً",
                theme, accent
            ) { showLicense = true }

            Spacer(Modifier.height(18.dp))

            // ═══ زر البحث عن تحديثات — في الأسفل (المتطلب ② v1.3.0) ═══
            Text("التحديثات", color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.6f))))
                    .clickable(onClick = onCheckUpdates)
                    .padding(vertical = 13.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (updateState is AppViewModel.UpdateState.Loading) "جاري الفحص..." else "البحث عن تحديثات",
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
                    )
                }
            }

            // بطاقات حالة الفحص
            when (updateState) {
                is AppViewModel.UpdateState.UpToDate ->
                    StatusCard("✓ أنت تستخدم أحدث إصدار — لا توجد تحديثات", Color(0xFF4CAF50), theme)
                is AppViewModel.UpdateState.Available ->
                    StatusCard(
                        "🎉 تحديث جديد متوفر: الإصدار ${updateState.info.versionName} — نافذة التفاصيل ظاهرة الآن",
                        accent, theme
                    )
                is AppViewModel.UpdateState.Failed ->
                    StatusCard("✕ ${updateState.message}", Color(0xFFFF7043), theme)
                else -> {}
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "مرخّص بموجب رخصة MIT — الكود المصدري متاح للجميع\n© 2026 مروان السيدى",
                color = theme.textSecondaryColor, fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.Center
            )
        }
    }

    // ═══ نافذة الترخيص المنبثقة — نص MIT المدمج ═══
    if (showLicense) {
        LicenseDialog(theme, accent) { showLicense = false }
    }
}

/** نافذة عرض نص رخصة MIT المدمجة في أصول التطبيق */
@Composable
private fun LicenseDialog(theme: AppTheme, accent: Color, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val licenseText = remember {
        runCatching {
            context.assets.open("license.txt").bufferedReader().use { it.readText() }
        }.getOrDefault("MIT License\n\nCopyright (c) 2026 Marwan Alsidi — Libya")
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(theme.surfaceColor)
                .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .background(accent.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("⚖️", fontSize = 20.sp) }
                Spacer(Modifier.width(11.dp))
                Column {
                    Text("رخصة MIT", color = theme.textPrimaryColor, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("Ai Plus GLM — مفتوحة المصدر بالكامل", color = theme.textSecondaryColor, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                licenseText,
                color = theme.textSecondaryColor,
                fontSize = 11.5.sp,
                lineHeight = 17.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState())
                    .clip(RoundedCornerShape(12.dp))
                    .background(theme.bgColorTop.copy(alpha = 0.5f))
                    .border(1.dp, theme.borderColor, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            )
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.65f))))
                    .clickable(onClick = onDismiss)
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) { Text("إغلاق", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun StatusCard(text: String, color: Color, theme: AppTheme) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 13.dp, vertical = 10.dp)
    ) { Text(text, color = color, fontSize = 12.sp, lineHeight = 17.sp) }
}

@Composable
private fun LinkRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    theme: AppTheme,
    accent: Color,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(theme.surfaceColor.copy(alpha = 0.7f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(36.dp)
                .background(accent.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = theme.textPrimaryColor, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = theme.textSecondaryColor, fontSize = 11.sp)
        }
    }
}
