package com.marwan.aiplusglm.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.view.View
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.marwan.aiplusglm.ui.theme.AppTheme

/**
 * ═══════════════════════════════════════════════════════════════
 *  حاضنة WebView عامة — الإصلاح الجذري لبلاغ «صفحة GLM-5.3-Flash
 *  تتأخر أثناء الفتح داخل التطبيق»
 * ═══════════════════════════════════════════════════════════════
 *  السابق: كل دخول لشاشة الويب كان يُنشئ WebView جديداً ويعيد تحميل
 *  chat.z.ai من الصفر (صفحة ثقيلة بمكتبات React وبث حي) — فتح بطيء كل مرة.
 *
 *  الآن:
 *  • WebView واحد يُنشأ مرة واحدة لكل نشاط ويُعاد استخدامه عند كل فتح
 *    — الجلسة والمحتوى المُحمّل يبقيان حيّين: الفتح التالي فوري.
 *  • الخروج من الشاشة يوقف الصوت والبث فقط (stopLoading + pauseTimers)
 *    دون تدمير، والدخول يستأنف (resumeTimers) بنفس الصفحة.
 *  • ذاكرة تخزين مؤقت كاملة (LOAD_DEFAULT + domStorage + database).
 *  • يتدمر نهائياً فقط عند تدمير النشاط (MainActivity.onDestroy).
 */
object WebChatHolder {

    @Volatile private var cached: WebView? = null
    @Volatile private var cachedActivity: Activity? = null
    @Volatile private var lastLoadedUrl: String = ""

    /** يُعيد الـ WebView المحفوظ أو ينشئ جديداً محسّن الأداء — بلا إعادة تحميل لنفس الرابط */
    fun acquire(activity: Activity, url: String): WebView {
        val existing = cached
        if (existing != null && cachedActivity === activity) {
            // الجلسة نفسها — استئناف فوري بلا إنشاء ولا تحميل من جديد
            existing.resumeTimers()
            if (lastLoadedUrl != url && existing.url.isNullOrBlank()) existing.loadUrl(url)
            return existing
        }
        runCatching { existing?.destroy() }
        return create(activity, url).also {
            cached = it
            cachedActivity = activity
            lastLoadedUrl = url
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun create(activity: Activity, url: String): WebView = WebView(activity).apply {
        setBackgroundColor(AndroidColor.TRANSPARENT)

        // ── إعدادات الأداء والجلسة ──
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT // كاش كامل — العناصر المشتركة لا تُعاد تنزيلها
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.mediaPlaybackRequiresUserGesture = false // تشغيل الصوت داخل الموقع دون نقرات إضافية
        settings.loadsImagesAutomatically = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.allowFileAccess = true
        settings.userAgentString =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

        // جلسة مشتركة — الموقع لا يُعاد تحميله عند التنقل بين الشاشات
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                return if (u.contains("z.ai") || u.contains("bigmodel.cn")) {
                    false // مواقع Z.ai تبقى داخل التطبيق
                } else {
                    runCatching { // الروابط الخارجية تفتح في المتصفح
                        activity.startActivity(
                            Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    true
                }
            }

            override fun onPageFinished(view: WebView, u: String) {
                lastLoadedUrl = u
            }
        }

        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                WebChatHolder.progressObserver?.invoke(newProgress)
            }

            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(arrayOf())
                fileCallback = callback
                runCatching {
                    chooserLauncher?.launch(params.createIntent())
                }.onFailure {
                    fileCallback?.onReceiveValue(arrayOf())
                    fileCallback = null
                }
                return true
            }
        }

        loadUrl(url)
    }

    // ═══ قناة الأحداث الحية بين الـ WebView وشاشة Compose ═══
    @Volatile internal var progressObserver: ((Int) -> Unit)? = null
    @Volatile internal var fileCallback: ValueCallback<Array<Uri>>? = null
    @Volatile internal var chooserLauncher: androidx.activity.result.ActivityResultLauncher<Intent>? = null

    /** خروج مؤقت من الشاشة — الصوت والبث يتوقفان والمحتوى يبقى محفوظاً */
    fun suspendCurrent() {
        runCatching { cached?.stopLoading() }
        runCatching { cached?.pauseTimers() }
    }

    /** تدمير نهائي — فقط عند تدمير النشاط كله */
    fun destroy() {
        runCatching { cached?.destroy() }
        cached = null
        cachedActivity = null
        lastLoadedUrl = ""
    }
}

/**
 * الواجهة الرسمية لموقع Z.ai (chat.z.ai) داخل التطبيق — v1.3.3
 * تعمل بلا مفتاح API ولا رصيد: المحادثة من الموقع الرسمي مباشرة.
 *
 * • فتح فوري — WebView محفوظ يعاد استخدامه بلا إعادة تحميل (الإصلاح الجذري للبطء)
 * • دعم رفع الملفات والصور من واجهة الموقع (onShowFileChooser)
 * • الجلسة محفوظة بالكوكيز + الرجوع داخل تاريخ الموقع بزر الرجوع وزر النظام
 * • شريط تقدم أنيق + زر تحديث + زر فتح في المتصفح
 */
@Composable
fun WebChatScreen(url: String, title: String, theme: AppTheme, accent: Color, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    var currentUrl by remember { mutableStateOf(url) }
    var webView by remember { mutableStateOf<WebView?>(null) }

    // رفع الملفات والصور من واجهة الموقع نفسها
    val fileChooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uris = if (result.resultCode == Activity.RESULT_OK) {
            android.webkit.WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        } else null
        WebChatHolder.fileCallback?.onReceiveValue(uris ?: arrayOf())
        WebChatHolder.fileCallback = null
    }
    DisposableEffect(Unit) {
        WebChatHolder.chooserLauncher = fileChooser
        onDispose { WebChatHolder.chooserLauncher = null }
    }

    // زر النظام للرجوع: يرجع داخل تاريخ الموقع أولاً ثم يخرج من الشاشة
    BackHandler(enabled = true) {
        val wv = webView
        if (wv != null && wv.canGoBack()) wv.goBack() else onBack()
    }

    // تتبع التقدم عبر حالة الحاضنة
    val progressState = remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val observer = { p: Int -> progressState.intValue = p }
        WebChatHolder.progressObserver = observer
        onDispose { WebChatHolder.progressObserver = null }
    }

    Column(Modifier.fillMaxSize()) {
        // الشريط العلوي: رجوع + العنوان + تحديث + فتح في المتصفح
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.85f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                val wv = webView
                if (wv != null && wv.canGoBack()) wv.goBack() else onBack()
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = theme.textPrimaryColor)
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(
                    "واجهة رسمية — بلا مفتاح ولا رصيد · فتح فوري",
                    color = accent, fontSize = 10.sp
                )
            }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable { webView?.reload() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Refresh, "تحديث", tint = theme.textSecondaryColor, modifier = Modifier.size(19.dp)) }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.OpenInNew, "فتح في المتصفح", tint = theme.textSecondaryColor, modifier = Modifier.size(18.dp)) }
        }

        // شريط التقدم
        val p = progressState.intValue
        if (p in 1..99) {
            LinearProgressIndicator(
                progress = { p / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = accent,
                trackColor = Color.Transparent
            )
        }

        // الـ WebView المحفوظ — يُنشأ مرة واحدة ويُعاد استخدامه (فتح فوري دائماً)
        AndroidView(
            factory = { ctx ->
                // الـ WebView يحتاج Activity context — الشاشة تعمل دائماً داخل MainActivity
                val host = activity ?: (ctx as? Activity)
                if (host != null) {
                    val wv = WebChatHolder.acquire(host, url)
                    wv.also { webView = it }
                } else {
                    // مسار احتياطي لا يُفترض حدوثه — WebView عادي حتى لا يفشل الإنشاء أبداً
                    WebView(ctx).also { webView = it }
                }
            },
            onRelease = { WebChatHolder.suspendCurrent() }, // خروج مؤقت — بلا تدمير ولا فقدان للجلسة
            modifier = Modifier.fillMaxSize()
        )

        // تتبع الرابط الحالي لزر «فتح في المتصفح»
        LaunchedEffect(webView) {
            while (true) {
                webView?.let { wv -> currentUrl = wv.url ?: url }
                kotlinx.coroutines.delay(800)
            }
        }
    }
}
