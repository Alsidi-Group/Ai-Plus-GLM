package com.marwan.aiplusglm.data

/**
 * لغات التطبيق التسع (طلب المستخدم — v1.3.3):
 * كل لغة بعلمها المناسب واسمها بلغتها الأصلية، تُعرض في الإعدادات
 * داخل خانة منفصلة تتوسع وتنطوي.
 *
 * العربية ترفع علم ليبيا 🇱🇾 كما طلب المطور مروان السيدى.
 * أثر اختيار اللغة:
 *   • ردود الذكاء الاصطناعي تُكتب بلغة الاختيار (تعليمة نظام تُرفق مع كل طلب)
 *   • النطق الصوتي TTS ينطق بلغة الاختيار
 *   • اتجاه الواجهة يتبع اللغة (عربي RTL — بقية اللغات LTR)
 */
data class AppLanguage(
    val id: String,          // رمز اللغة (ISO 639)
    val nameAr: String,      // الاسم بالعربية — لغة واجهة التطبيق
    val nativeName: String,  // الاسم بلغته الأصلية
    val englishName: String, // الاسم الإنجليزي — يُستخدم في تعليمة النموذج
    val flag: String         // العلم المناسب للغة
)

object AppLanguages {

    val all = listOf(
        AppLanguage("ar", "العربية",   "العربية",   "Arabic",   "🇱🇾"), // العربية بعلم ليبيا
        AppLanguage("en", "الإنجليزية", "English",   "English",  "🇬🇧"),
        AppLanguage("fr", "الفرنسية",   "Français",  "French",   "🇫🇷"),
        AppLanguage("it", "الإيطالية",  "Italiano",  "Italian",  "🇮🇹"),
        AppLanguage("ru", "الروسية",    "Русский",   "Russian",  "🇷🇺"),
        AppLanguage("tr", "التركية",    "Türkçe",    "Turkish",  "🇹🇷"),
        AppLanguage("zh", "الصينية",    "中文",        "Chinese",  "🇨🇳"),
        AppLanguage("ja", "اليابانية",  "日本語",      "Japanese", "🇯🇵"),
        AppLanguage("hi", "الهندية",    "हिन्दी",     "Hindi",    "🇮🇳")
    )

    fun byId(id: String): AppLanguage = all.firstOrNull { it.id == id } ?: all[0]

    fun isRtl(id: String): Boolean = byId(id).id == "ar"

    /**
     * تعليمة النظام المرفقة مع كل طلب محادثة — تُلزم النموذج بالرد بلغة الاختيار.
     * العربية هي الافتراضية فلا تحتاج تعليمة (المحادثة تتبع لغة رسالة المستخدم طبيعياً).
     */
    fun systemPrompt(langId: String): String? {
        val lang = byId(langId)
        if (lang.id == "ar") return null
        return "You must always respond in ${lang.englishName} language, " +
            "regardless of the language used in the user's message. " +
            "Write naturally and fluently in ${lang.englishName}. " +
            "If the user explicitly requests a different language in their message, follow the user."
    }
}
