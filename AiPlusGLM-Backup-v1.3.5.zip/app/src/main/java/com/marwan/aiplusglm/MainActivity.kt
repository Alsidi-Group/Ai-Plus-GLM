package com.marwan.aiplusglm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.security.ProviderInstaller
import com.marwan.aiplusglm.data.AppLocale
import com.marwan.aiplusglm.data.LocalS
import com.marwan.aiplusglm.ui.theme.AppTheme
import com.marwan.aiplusglm.ui.theme.AppTypography
import com.marwan.aiplusglm.ui.theme.BgPattern
import com.marwan.aiplusglm.ui.theme.Themes
import com.marwan.aiplusglm.ui.theme.ThemedBackground
import com.marwan.aiplusglm.ui.theme.resolveTheme
import com.marwan.aiplusglm.ui.theme.toColorScheme
import com.marwan.aiplusglm.ui.screens.AboutScreen
import com.marwan.aiplusglm.ui.screens.ChatScreen
import com.marwan.aiplusglm.ui.screens.ModelsScreen
import com.marwan.aiplusglm.ui.screens.SetupScreen
import com.marwan.aiplusglm.ui.screens.SettingsScreen
import com.marwan.aiplusglm.ui.screens.UpdateDialog
import com.marwan.aiplusglm.ui.screens.WebChatScreen
import com.marwan.aiplusglm.ui.screens.WebViewScreen
import com.marwan.aiplusglm.ui.screens.WebChatHolder
import com.marwan.aiplusglm.vm.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setTheme(android.R.style.Theme_DeviceDefault_NoActionBar)

        // ═══ خدمات قوقل للحماية (المتطلب ③ v1.3.4) ═══
        // تحديث مزود الأمان عبر Google Play Services — يرقّع ثغرات TLS/SSL تلقائياً
        // ويجنّب حظر Play Protect للتطبيق عند نشره
        runCatching {
            ProviderInstaller.installIfNeededAsync(this, object : ProviderInstaller.ProviderInstallListener {
                override fun onProviderInstalled() {}
                override fun onProviderInstallFailed(errorCode: Int, recoveryIntent: android.content.Intent?) {
                    // فشل الترقية ليس قاتلاً — نعرض حل قوقل الرسمي إن وُجد (تحديث خدمات قوقل)
                    runCatching {
                        if (GoogleApiAvailability.getInstance().showErrorDialogFragment(this@MainActivity, errorCode, 1)) {
                            // نافذة الحل تعرضت تلقائياً
                        } else {
                            recoveryIntent?.let { startActivity(it) }
                        }
                    }
                }
            })
        }

        // تسخين محرك الويب مبكراً — يقلل زمن أول فتح للواجهة الرسمية (المتطلب ④ v1.3.4)
        WebChatHolder.warmup(this)

        setContent {
            Root()
        }
    }

    override fun onDestroy() {
        // التدمير النهائي للـ WebView الدائم — منع أي تسريب ذاكرة
        WebChatHolder.destroy()
        super.onDestroy()
    }

    @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
    @Composable
    private fun Root() {
        val vm: AppViewModel = viewModel()
        val themeId by vm.themeId.collectAsState()
        val patternId by vm.patternId.collectAsState()
        val displayMode by vm.displayMode.collectAsState()
        val appLanguage by vm.appLanguage.collectAsState()
        val model by vm.currentModel.collectAsState()
        val toast by vm.toast.collectAsState()
        val updateState by vm.updateState.collectAsState()

        // ═══ لغة الواجهة (v1.3.4): كل نصوص التطبيق تتبع اللغة المختارة فوراً ═══
        val s = remember(appLanguage) { AppLocale.stringsFor(appLanguage) }

        // وضع «تلقائي» يتبع إعدادات النظام: داكن ليلاً وفاتح نهاراً — وكل مظهر يُشتق منه
        // نسخة نهارية/ليلية متسقة مع هوية لونه (الإصلاح الجذري لبلاغ «المظهر لا يعمل في النهار/التلقائي»)
        val systemDark = isSystemInDarkTheme()
        val theme = resolveTheme(themeId, displayMode, systemDark)
        // لون الواجهة = لون النموذج النشط (يتغير تلقائياً عند اختيار نموذج)
        val accent = Color(model.accent)

        var screen by remember { mutableStateOf("chat") }
        var webViewUrl by remember { mutableStateOf("") }
        var showConversations by remember { mutableStateOf(false) }
        val showSetup by vm.showSetup.collectAsState()
        val context = LocalContext.current

        CompositionLocalProvider(LocalS provides s) {
            // جسر MaterialTheme — كل مكونات Material3 تتبع ألوان المظهر المختار
            // + طباعة Cairo (المتطلب: خط أجمل — v1.3.4)
            MaterialTheme(
                colorScheme = theme.toColorScheme(accent),
                typography = AppTypography,
                content = {
                    // زر النظام للرجوع: من أي شاشة فرعية يعود للمحادثة تلقائياً
                    BackHandler(enabled = screen != "chat" && !showSetup) { screen = "chat" }

                    // لون شريط الحالة يتبع الخلفية + أيقوناته تتبع إضاءة المظهر
                    LaunchedEffect(theme.id) {
                        runCatching {
                            window.statusBarColor = Color(theme.bgTop).toArgb()
                            window.navigationBarColor = Color(theme.bgBottom).toArgb()
                        }
                        runCatching {
                            val controller = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
                            controller.isAppearanceLightStatusBars = !theme.isDark
                            controller.isAppearanceLightNavigationBars = !theme.isDark
                        }
                    }

                    // تنبيهات النظام (تفعيل النموذج، نموذج الرؤية التلقائي...)
                    toast?.let { msg ->
                        LaunchedEffect(msg) {
                            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                            vm.consumeToast()
                        }
                    }

                    Box(Modifier.fillMaxSize()) {
                        ThemedBackground(theme, BgPattern.byId(patternId), accent, Modifier.fillMaxSize())

                        Column(
                            Modifier
                                .fillMaxSize()
                                .systemBarsPadding()
                                // إصلاح الكيبورد (v1.2.0): الرسائل وشريط الإدخال يرتفعان فوقه تلقائياً
                                .imePadding()
                        ) {
                            AnimatedContent(
                                targetState = screen,
                                transitionSpec = {
                                    (fadeIn(tween(280)) + slideInVertically(tween(280)) { it / 24 })
                                        .togetherWith(fadeOut(tween(180)))
                                },
                                label = "nav",
                                modifier = Modifier.weight(1f)
                            ) { sc ->
                                when (sc) {
                                    // توجيه webChat: نموذج الواجهة الرسمية يفتح chat.z.ai داخل التطبيق
                                    "chat" -> if (model.webChat) {
                                        WebChatScreen(
                                            url = "https://chat.z.ai",
                                            title = model.nameAr,
                                            theme = theme, accent = accent,
                                            onBack = { vm.setModel(com.marwan.aiplusglm.data.ModelCatalog.freeModel()) }
                                        )
                                    } else {
                                        ChatScreen(vm, theme, accent, model) { screen = "models" }
                                    }
                                    "models" -> ModelsScreen(vm, theme, accent, model.id, onBack = { screen = "chat" })
                                    "settings" -> SettingsScreen(
                                        vm, theme, accent,
                                        thinking = vm.thinkingEnabled.collectAsState().value,
                                        tts = vm.ttsEnabled.collectAsState().value,
                                        onBack = { screen = "chat" }
                                    )
                                    "about" -> AboutScreen(
                                        theme, accent,
                                        versionName = BuildConfig.VERSION_NAME,
                                        updateState = updateState,
                                        onCheckUpdates = { vm.checkForUpdates(BuildConfig.VERSION_CODE) },
                                        onOpenUrl = { url ->
                                            webViewUrl = url
                                            screen = "web"
                                        },
                                        onBack = { screen = "chat" }
                                    )
                                    "web" -> WebViewScreen(webViewUrl, s.linkSite, theme, accent) { screen = "about" }
                                }
                            }

                            // شريط تنقل زجاجي سفلي
                            GlassNavBar(
                                screen, theme, accent,
                                onChat = { screen = "chat" },
                                onModels = { screen = "models" },
                                onThemes = { screen = "settings" },
                                onAbout = { screen = "about" },
                                onHistory = { showConversations = true },
                                onNewChat = {
                                    vm.newConversation()
                                    // v1.3.5 إصلاح «زر الدردشة الجديدة لا يعمل»: مع الواجهة الرسمية
                                    // كان الزر يفرّغ المحادثة الأصلية فقط بينما صفحة chat.z.ai تبقى
                                    // كما هي — الآن يبدأ محادثة نظيفة على الواجهة الرسمية أيضاً
                                    if (model.webChat) WebChatHolder.newChat(WebChatHolder.HOME_URL)
                                    screen = "chat"
                                }
                            )
                        }

                        // نافذة التحديث المنسقة — تظهر تلقائياً عند وجود إصدار أحدث
                        if (updateState is AppViewModel.UpdateState.Available) {
                            UpdateDialog(
                                info = (updateState as AppViewModel.UpdateState.Available).info,
                                theme = theme,
                                accent = accent,
                                onDismiss = { vm.consumeUpdateState() }
                            )
                        }
                    }

                    // ورقة المحادثات المحفوظة
                    if (showConversations) {
                        ModalBottomSheet(
                            onDismissRequest = { showConversations = false },
                            containerColor = theme.surfaceColor,
                            contentColor = theme.textPrimaryColor
                        ) {
                            ConversationsSheet(vm, theme, accent, onOpen = {
                                showConversations = false
                                screen = "chat"
                            })
                        }
                    }

                    // شاشة التفعيل — تنجح مرة واحدة ثم تختفي للأبد
                    AnimatedVisibility(
                        visible = showSetup,
                        enter = fadeIn(tween(260)),
                        exit = fadeOut(tween(220)),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        SetupScreen(vm, theme, accent)
                    }
                }
            )
        }
    }
}

// ═════════════════════ شريط التنقل — أيقونات مدوّرة جديدة (المتطلب ⑧ v1.3.4) ═════════════════════

@Composable
private fun GlassNavBar(
    current: String,
    theme: AppTheme,
    accent: Color,
    onChat: () -> Unit,
    onModels: () -> Unit,
    onThemes: () -> Unit,
    onAbout: () -> Unit,
    onHistory: () -> Unit,
    onNewChat: () -> Unit
) {
    val s = LocalS.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(theme.surfaceColor.copy(alpha = 0.82f))
            .border(1.dp, theme.borderColor, RoundedCornerShape(22.dp))
            .padding(horizontal = 6.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem(Icons.Rounded.ChatBubble, s.navChat, current == "chat", accent, theme, onChat)
        NavItem(Icons.Rounded.AutoAwesome, s.navModels, current == "models", accent, theme, onModels)
        // زر محادثة جديدة — بارز
        Box(
            Modifier
                .size(46.dp)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.55f))), CircleShape)
                .clickable(onClick = onNewChat),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Add, s.navNewChat, tint = Color.White, modifier = Modifier.size(24.dp)) }
        NavItem(Icons.Rounded.History, s.navSaved, false, accent, theme, onHistory)
        NavItem(Icons.Rounded.Palette, s.navSettings, current == "settings", accent, theme, onThemes)
        NavItem(Icons.Rounded.Info, s.navAbout, current == "about", accent, theme, onAbout)
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    accent: Color,
    theme: AppTheme,
    onClick: () -> Unit
) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (selected) accent else theme.textSecondaryColor, modifier = Modifier.size(21.dp))
        Text(label, color = if (selected) accent else theme.textSecondaryColor, fontSize = 9.sp)
    }
}

// ═════════════════════ المحادثات المحفوظة ═════════════════════

@Composable
private fun ConversationsSheet(
    vm: AppViewModel,
    theme: AppTheme,
    accent: Color,
    onOpen: () -> Unit
) {
    val s = LocalS.current
    val conversations by vm.conversations.collectAsState()
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd · HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 24.dp)) {
        Text(s.savedTitle, color = theme.textPrimaryColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(String.format(s.savedCount, conversations.size), color = theme.textSecondaryColor, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        if (conversations.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(vertical = 30.dp), contentAlignment = Alignment.Center) {
                Text(s.savedEmpty,
                    color = theme.textSecondaryColor, fontSize = 13.sp, lineHeight = 20.sp)
            }
        } else {
            LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(conversations, key = { it.id }) { conv ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(theme.bgTop).copy(alpha = 0.5f))
                            .border(1.dp, theme.borderColor, RoundedCornerShape(14.dp))
                            .clickable { vm.loadConversation(conv); onOpen() }
                            .padding(horizontal = 13.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(conv.title.ifBlank { s.defaultConvTitle }, color = theme.textPrimaryColor,
                                fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(
                                "${fmt.format(Date(conv.updatedAt))} · ${String.format(s.msgCount, conv.messages.size)}",
                                color = theme.textSecondaryColor, fontSize = 11.sp
                            )
                        }
                        Icon(Icons.Rounded.Delete, s.delete, tint = theme.textSecondaryColor.copy(alpha = 0.6f),
                            modifier = Modifier
                                .size(19.dp)
                                .clickable { vm.deleteConversation(conv) })
                    }
                }
            }
        }
    }
}
