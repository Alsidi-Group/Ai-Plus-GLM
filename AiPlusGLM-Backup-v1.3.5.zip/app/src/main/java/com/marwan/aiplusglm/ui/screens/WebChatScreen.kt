package com.marwan.aiplusglm.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.marwan.aiplusglm.data.LocalS
import com.marwan.aiplusglm.ui.theme.AppTheme
import kotlinx.coroutines.delay

/**
 * حاضنة WebView الدائمة (v1.3.5 — الإصلاح الجذري الثالث لبلاغ «واجهة GLM-5.3-Flash لا تعمل»):
 *
 * • v1.3.5①: مؤشر التحميل يُهيأ من حالة المحرك الفعلية — إعادة فتح الواجهة تُظهر الصفحة
 *   المحفوظة فوراً بدل غطاء تحميل أبدي (كان onPageFinished لا يُطلق ثانيةً فتبدو الواجهة معطلة)
 * • v1.3.5②: التسخين على الخيط الرئيسي (كان على خيط خلفي بلا Looper فيرمي استثناءً
 *   يُبتلع صامتاً فلا يُسخّن شيئاً) — أول فتح الآن أسرع فعلياً
 * • v1.3.5③: منطق تحميل صريح بلا أي لبس نطاق — الصفحة الفارغة تُحمَّل دائماً
 * • v1.3.5④: مؤقت إنذار 30 ثانية — أي تحميل معلّق يتحول لصفحة الخطأ الودية مع زر إعادة محاولة
 * • v1.3.5⑤: newChat() — زر «محادثة جديدة» يبدأ محادثة نظيفة على الواجهة الرسمية أيضاً
 */
object WebChatHolder {
    @Volatile
    private var webView: WebView? = null

    /** الرابط الأساسي للواجهة الرسمية — يُستخدم لبدء محادثة جديدة نظيفة */
    const val HOME_URL = "https://chat.z.ai/"

    /**
     * يجهز الكوكيز ومحرك الويب مبكراً عند إقلاع التطبيق — يقلل زمن أول فتح.
     * v1.3.5: على الخيط الرئيسي عبر Handler (إنشاء WebView على خيط بلا Looper يرمي
     * استثناءً ويُبتلع صامتاً فلا يحدث تسخين أصلاً) — بعد 1.2 ثانية لكي لا يزاحم رسم أول إطار.
     */
    fun warmup(context: android.content.Context) {
        val app = context.applicationContext
        runCatching {
            Handler(Looper.getMainLooper()).postDelayed({
                runCatching {
                    CookieManager.getInstance().setAcceptCookie(true)
                    WebView(app).destroy() // يهيئ مزود WebView كاملاً ثم يُهدم فوراً
                }
            }, 1200L)
        }
    }

    /** الوصول للـ WebView المحفوظ — لمعرفة تاريخ الرجوع من أزرار الواجهة */
    val current: WebView? get() = webView

    /** هل توجد صفحة محمّلة فعلاً في المحرك الدائم؟ (يمنع مؤشر التحميل الأبدي عند إعادة الفتح) */
    fun hasLoadedPage(): Boolean =
        webView?.url?.let { it.isNotBlank() && it != "about:blank" } ?: false

    /** يستعيد WebView المحفوظ أو ينشئ جديداً مُهيّأً بالكامل */
    fun obtain(activity: Activity): WebView {
        webView?.let { return it }
        val wv = WebView(activity)
        configure(wv)
        webView = wv
        return wv
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(wv: WebView) = with(wv.settings) {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        loadWithOverviewMode = true
        useWideViewPort = true
        builtInZoomControls = false
        mediaPlaybackRequiresUserGesture = false
        cacheMode = WebSettings.LOAD_DEFAULT // كاش افتراضي — إعادة فتح أسرع بلا إعادة تحميل كل الموارد
        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        userAgentString =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        // تسريع: safe browsing يفحص كل مورد ويبطئ الفتح — الموقع موثوق (chat.z.ai)
        runCatching { setSafeBrowsingEnabled(false) }
        // أولوية قصوى لمحرك الرسم — لا يجمد أثناء التمرير السريع
        runCatching {
            val m = WebSettings::class.java.getMethod(
                "setRendererPriorityPolicy",
                Int::class.javaPrimitiveType, Boolean::class.javaPrimitiveType
            )
            m.invoke(wv, 1 /* RENDERER_PRIORITY_IMPORTANT */, false)
        }
        // جلسة مشتركة دائمة
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
    }

    /**
     * بدء «محادثة جديدة» نظيفة على الواجهة الرسمية (v1.3.5).
     * يوقف كل تحميل جارٍ، يمسح تاريخ التنقل، ويعيد تحميل الصفحة الرئيسية —
     * SPA يقلع من جديد فيعرض محادثة فارغة جديدة دون فقدان الجلسة/تسجيل الدخول.
     */
    fun newChat(homeUrl: String = HOME_URL) {
        runCatching {
            webView?.let {
                it.stopLoading()
                it.clearHistory()
                it.loadUrl(homeUrl)
            }
        }
    }

    /** إعادة تحميل الصفحة الحالية (زر التحديث) */
    fun reload() {
        runCatching { webView?.reload() }
    }

    /**
     * إعادة محاولة ذكية (صفحة الخطأ): إن كان المحرك فارغاً أو على about:blank
     * يُحمَّل الرابط الأساسي، وإلا يُعاد تحميل الصفحة الحالية — لا يبقى المستخدم
     * عالقاً خلف شاشة بيضاء مهما كانت حالة المحرك.
     */
    fun retry(defaultUrl: String) {
        runCatching {
            val wv = webView ?: return
            val u = wv.url
            if (u == null || u == "about:blank" || u.isBlank()) wv.loadUrl(defaultUrl) else wv.reload()
        }
    }

    /** إيقاف الصوت والفيديو عند مغادرة الشاشة — دون فقدان الجلسة */
    fun pause() {
        webView?.runCatching {
            onPause()
            pauseTimers()
        }
    }

    /** استئناف عند العودة للشاشة */
    fun resume() {
        webView?.runCatching {
            resumeTimers()
            onResume()
        }
    }

    /** تدمير نهائي — من MainActivity.onDestroy فقط */
    fun destroy() {
        runCatching {
            webView?.stopLoading()
            webView?.loadUrl("about:blank")
            webView?.onPause()
            webView?.destroy()
        }
        webView = null
    }
}

/**
 * الواجهة الرسمية لموقع Z.ai (chat.z.ai) داخل التطبيق — v1.3.5
 * تعمل بلا مفتاح API ولا رصيد: المحادثة من الموقع الرسمي مباشرة.
 *
 * • فتح فوري: الصفحة المحفوظة تظهر مباشرة عند العودة (بلا غطاء تحميل زائف)
 * • دعم رفع الملفات والصور من واجهة الموقع (onShowFileChooser)
 * • شريط تقدم + مؤشر تحميل مركزي + إنذار 30 ثانية + صفحة خطأ ودية مع إعادة محاولة
 * • الروابط الخارجية تفتح في متصفح الجهاز — مواقع Z.ai تبقى داخل التطبيق
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebChatScreen(url: String, title: String, theme: AppTheme, accent: Color, onBack: () -> Unit) {
    val context = LocalContext.current
    val s = LocalS.current
    var progress by remember { mutableStateOf(0) }
    // v1.3.5: يُهيأ من حالة المحرك الفعلية — إذا كانت الصفحة محفوظة تُعرض فوراً بلا مؤشر
    var pageReady by remember { mutableStateOf(WebChatHolder.hasLoadedPage()) }
    var loadFailed by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf(url) }
    var reloadKey by remember { mutableStateOf(0) }

    // رفع الملفات والصور من واجهة الموقع نفسها
    var fileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val fileChooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uris = if (result.resultCode == Activity.RESULT_OK) {
            android.webkit.WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        } else null
        fileCallback?.onReceiveValue(uris ?: arrayOf())
        fileCallback = null
    }

    // زر النظام للرجوع: يرجع داخل تاريخ الموقع أولاً ثم يخرج من الشاشة
    BackHandler(enabled = true) {
        val wv = WebChatHolder.current
        if (wv != null && wv.canGoBack()) wv.goBack() else onBack()
    }

    // إيقاف الصوت عند الخروج واستئنافه عند العودة — دون فقدان الجلسة
    DisposableEffect(Unit) {
        WebChatHolder.resume()
        onDispose { WebChatHolder.pause() }
    }

    // v1.3.5: مؤقت الإنذار — أي تحميل معلق أكثر من 30 ثانية يتحول لصفحة الخطأ الودية
    // بدل مؤشر تحميل أبدي بلا مخرج
    LaunchedEffect(reloadKey, pageReady, loadFailed) {
        if (!pageReady && !loadFailed) {
            delay(30_000)
            if (!pageReady && !loadFailed) loadFailed = true
        }
    }

    Column(Modifier.fillMaxSize()) {
        // الشريط العلوي: رجوع + العنوان + تحديث + فتح في المتصفح
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(theme.surfaceColor.copy(alpha = 0.85f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                val wv = WebChatHolder.current
                if (wv != null && wv.canGoBack()) wv.goBack() else onBack()
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back, tint = theme.textPrimaryColor)
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = theme.textPrimaryColor, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(s.wcSubtitle, color = accent, fontSize = 10.sp)
            }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable {
                        loadFailed = false
                        pageReady = false
                        progress = 0
                        WebChatHolder.retry(url)
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Refresh, s.wcRefresh, tint = theme.textSecondaryColor, modifier = Modifier.size(19.dp)) }
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.OpenInNew, s.wcOpenExternal, tint = theme.textSecondaryColor, modifier = Modifier.size(18.dp)) }
        }

        // شريط التقدم
        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = accent,
                trackColor = Color.Transparent
            )
        }

        Box(Modifier.fillMaxSize()) {
            // key(reloadKey): عند انهيار محرك الرسم يعاد بناء العرض بWebView نظيف جديد
            key(reloadKey) {
            AndroidView(
                factory = { ctx ->
                    val targetUrl = url
                    val wv = WebChatHolder.obtain(ctx as Activity)
                    wv.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val u = request.url.toString()
                            return if (u.contains("z.ai") || u.contains("bigmodel.cn")) {
                                false // مواقع Z.ai تبقى داخل التطبيق
                            } else {
                                runCatching { // الروابط الخارجية تفتح في المتصفح
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                }
                                true
                            }
                        }

                        override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
                            super.onPageStarted(view, u, favicon)
                            pageReady = false
                            loadFailed = false
                        }

                        override fun onPageFinished(view: WebView, u: String) {
                            canGoBack = view.canGoBack()
                            currentUrl = u
                            if (!loadFailed) pageReady = true
                        }

                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            if (request.isForMainFrame) {
                                loadFailed = true
                                pageReady = false
                            }
                        }

                        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                            // انهيار محرك الرسم — إعادة بناء نظيفة بدل شاشة بيضاء ميتة
                            runCatching { view.destroy() }
                            WebChatHolder.destroy()
                            loadFailed = true
                            reloadKey++
                            return true
                        }
                    }

                    wv.webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                        }

                        override fun onShowFileChooser(
                            view: WebView?,
                            callback: ValueCallback<Array<Uri>>,
                            params: FileChooserParams
                        ): Boolean {
                            fileCallback = callback
                            runCatching {
                                fileChooser.launch(params.createIntent())
                            }.onFailure {
                                fileCallback?.onReceiveValue(arrayOf())
                                fileCallback = null
                            }
                            return true
                        }
                    }

                    // v1.3.5: تحميل صريح بلا أي لبس نطاق — الصفحة الفارغة/about:blank تُحمَّل دائماً
                    val current = wv.url ?: ""
                    if (targetUrl.isNotBlank() && (current.isBlank() || current == "about:blank")) {
                        wv.loadUrl(targetUrl)
                    }
                    wv
                },
                modifier = Modifier.fillMaxSize()
            )
            }

            // مؤشر التحميل المركزي — يختفي فور جاهزية الصفحة (ولا يظهر أصلاً إن كانت محفوظة)
            if (!pageReady && !loadFailed) {
                Column(
                    Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = accent, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(14.dp))
                    Text(s.wcLoading, color = theme.textSecondaryColor, fontSize = 13.sp)
                }
            }

            // صفحة الخطأ الودية — مع زر إعادة المحاولة الذكية
            if (loadFailed) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .background(theme.bgColorBottom.copy(alpha = 0.96f))
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("📡", fontSize = 44.sp)
                    Spacer(Modifier.height(14.dp))
                    Text(s.wcErrorTitle, color = theme.textPrimaryColor, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        s.wcErrorBody, color = theme.textSecondaryColor,
                        fontSize = 12.5.sp, lineHeight = 19.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(20.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.6f))))
                            .clickable {
                                loadFailed = false
                                pageReady = false
                                progress = 0
                                WebChatHolder.retry(url)
                            }
                            .padding(horizontal = 26.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Refresh, null, tint = Color.White, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(s.wcRetry, color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
