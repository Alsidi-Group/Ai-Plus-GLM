# 📋 PROJECT-STATUS — Ai Plus GLM

**آخر تحديث لهذا الملف: 2026-10-29 — الإصدار الحالي v1.3.4 (versionCode 11) — منشور بالكامل**
**المطور: مروان السيدى (Marwan Alsidi) — ليبيا 🇱🇾 • الترخيص: MIT**

> هذا الملف هو ذاكرة المشروع الرسمية — يوثق الحالة الحية بالكامل لاستكمال أي تعديل مستقبلي دون فقدان أي شيء. **اقرأه كاملاً قبل أي عمل على المشروع.**
> ⚠️ **درس مهم:** تراجعت البيئة مرتين وفُقد المصدر المحلي — النسخة الاحتياطية الشاملة على gofile + هذا الملف هما خط الإنقاذ. اقرأ ② لإعادة بناء البيئة دائماً.

---

## ① الروابط الحية الدائمة (v1.3.4)

| الملف | الرابط | نوعه |
|---|---|---|
| APK موقّع v1.3.4 | https://gofile.io/d/5oksQakh | gofile صفحة تحميل |
| نسخة احتياطية شاملة ZIP (99 ملفاً) | https://gofile.io/d/pRa788xN | gofile |
| مركز التحميل (قائمة مفرزة تفاعلية) | https://gofile.io/d/eKq9KXTs | gofile — نزّل وافتح محلياً |
| README.md (سجل حتى v1.3.4) | https://pomf2.lain.la/f/4boal7iw.md | pomf مباشر |
| README-BUILD-AR.md (دليل البناء) | https://pomf2.lain.la/f/a3c9t1c2.md | pomf مباشر |
| Update.json (مرآة نصية v1.3.4) | https://pomf2.lain.la/f/huajd7ui.json | pomf مباشر |
| Direct-Links.txt (القائمة المفرزة) | https://pomf2.lain.la/f/x1yy4k07.txt | pomf مباشر |
| apktool-template.yml | https://pomf2.lain.la/f/xho9htmb.yml | pomf مباشر |
| LICENSE (MIT) | https://pomf2.lain.la/f/tj7a03qt.txt | pomf مباشر |
| icon-512.png (الأيقونة الجديدة) | https://pomf2.lain.la/f/xo3yb7zd.png | pomf مباشر |
| **المخزن الحي الأساسي** (مدمج في الكود) | https://extendsclass.com/api/json-storage/bin/cbdaccd | PUT للتحديث |
| **المخزن الحي الاحتياطي** (مدمج في الكود) | https://extendsclass.com/api/json-storage/bin/ddbcdcf | PUT للتحديث |

**SHA-256 للـ APK v1.3.4:** `de28bd20e6dbdc74d602894cec03eb63d7f4e2dd8f4b3b16029270eb4ad2e96f`

**أرشيف الإصدارات (gofile):** v1.3.3 `Aq1vzhGV` • v1.3.2 `BZ7LEtkN` • v1.3.1 `5clFcZ8P` • v1.3.0 `07aZZLC3` • v1.2.0 `X35SGsCX` • v1.1.3 `xZeXkwn5` • v1.1.2 `SLU0oGdR` • v1.1.0 `fKShbthO` — (أكمل: https://gofile.io/d/{الكود})

---

## ② بيئة البناء (تُفقد مع تراجع البيئة — تُعاد هكذا بالترتيب)

```bash
# ① JDK 17 كامل مع jlink:
mkdir -p /home/z/my-project/tmp && cd /home/z/my-project/tmp
wget -q "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse" -O jdk17.tar.gz
mkdir -p /home/z/tools && tar xzf jdk17.tar.gz -C /home/z/tools/   # → /home/z/tools/jdk-17.0.21+9

# ② Android SDK:
wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdtools.zip
mkdir -p /home/z/tools/android-sdk/cmdline-tools && unzip -q -o cmdtools.zip -d /tmp/ct
mv /tmp/ct/cmdline-tools /home/z/tools/android-sdk/cmdline-tools/latest
export ANDROID_HOME=/home/z/tools/android-sdk
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools"

# ③ المصدر: إن فُقد، انزل بالنسخة الشاملة من gofile (الرابط في ①) وفكّها في /home/z/my-project/AiPlusGLM/
#    ثم: echo "sdk.dir=/home/z/tools/android-sdk" > local.properties
#    gradle.properties فيه: org.gradle.java.home=/home/z/tools/jdk-17.0.21+9

# ④ البناء (foreground فقط — الخلفية تُقتل مع الجلسة، مهلة 590 ثانية):
cd /home/z/my-project/AiPlusGLM && ./gradlew assembleRelease --no-daemon
# الناتج الموقّع: app/build/outputs/apk/release/app-release.apk
```

**بيانات التوقيع:** `keystore/aiplus-release.jks` • alias `aiplus` • كلمة السر `AiPlusGLM2026` • SHA-256 الشهادة: `10fd394246a20b39430909ad4ef8499a90f8e412aa1e4fd40cececbd34ab5d50` (CN=Marwan Alsidi — موحدة من v1.1.0، التثبيت تراكمي فوق كل الإصدارات)

---

## ③ خريطة الكود المصدري (v1.3.4)

```
app/src/main/java/com/marwan/aiplusglm/
├── MainActivity.kt          — الجذر: CompositionLocal(LocalS) + MaterialTheme(لون+خط Cairo) + ProviderInstaller(حماية قوقل) + WebChatHolder.warmup/destroy + GlassNavBar أيقونات مدوّرة
├── ZaiConfig.kt             — المفاتيح المدمجة + resolveEndpoint + روابط المخزنين الحيين
├── data/
│   ├── AppLanguage.kt       — ★ v1.3.4: اللغات التسع بأعلامها + systemPrompt(id) لإلزام لغة الردود
│   ├── AppStrings.kt        — ★ v1.3.4: ترجمة كاملة (~150 مفتاحاً × 9 لغات) + LocalS + AppLocale
│   ├── ZaiClient.kt         — البث SSE + رسالة نظام اللغة + UA 1.3.4 + أخطاء مترجمة + فحص تحديث بسلسلة مصادر
│   ├── ModelCatalog.kt      — 10 نماذج بألوانها + webChat لعلم GLM-5.3-Flash
│   ├── ChatData/ChatStore   — المرفقات + المحادثات (JSON محلي)
│   ├── KeyVault.kt          — تخزين المفتاح/الوسيط
│   └── NotificationReaderService.kt — خدمة قراءة الإشعارات
├── vm/AppViewModel.kt       — StateFlows: displayMode + appLanguage(★) + thinking + tts + تحديثات + setAppLanguage يزامن AppLocale ويضبط TTS
└── ui/
    ├── screens/
    │   ├── ChatScreen.kt    — follow-scroll بـ DragInteraction + زر قفز + رقاقة تفكير + مرفقات/كاميرا/ميك (بلغة التطبيق)
    │   ├── SettingsScreen.kt— 3 خانات قابلة للطي: لغة التطبيق (★ 9 لغات بأعلامها) + المظهر + الأذونات — كلها مترجمة
    │   ├── AboutScreen.kt   — الشعار + الترخيص MIT + فحص التحديثات — مترجم
    │   ├── WebChatScreen.kt — ★ v1.3.4: WebChatHolder — WebView دائم + تسخين + كاش + صفحة خطأ ودية + تعافٍ من انهيار الرسم
    │   ├── ModelsScreen/SetupScreen/UpdateDialog — مترجمة بالكامل
    │   └── WebViewScreen.kt — عرض الروابط العامة
    └── theme/Theme.kt       — 8 مظاهر + اشتقاق نهاري/ليلي + toColorScheme + ★ CairoFamily + AppTypography + ThemedBackground
```

**الموارد الجديدة v1.3.4:** `res/font/cairo_variable.ttf` (خط Cairo المتغير) • `res/xml/locales_config.xml` (9 لغات للنظام) • أيقونة تكيفية جديدة: `mipmap-xxxhdpi/ic_launcher_{bg,fg,mono}.png` + `mipmap-anydpi-v26/*.xml` (خلفية+مقدمة+أحادية) + mipmaps تقليدية لكل الكثافات.

---

## ④ سجل القرارات التقنية المهمة (لماذا كذا؟)

1. **نظام الترجمة**: Kotlin pure (AppStrings open class + 9 objects) بلا res/values-XX — التبديل فوري بلا إعادة إنشاء Activity، والناقص يرجع للعربية آمناً. CompositionLocal للواجهة + AppLocale singleton للـ VM/ZaiClient.
2. **لغة الردود**: رسالة `system` تُحقن أولاً في كل طلب GLM — النموذج يتبع لغة التطبيق حتى لو السؤال بلغة أخرى.
3. **المظهر نهاري/ليلي**: لكل مظر نسخة مشتقة (`effectiveLight/effectiveDark`) + جسر `toColorScheme` — وألوان الحالة (Ok/Warn) ثابتة تعمل في الوضعين، وشريط الحالة يتبع `theme.isDark`.
4. **WebChatHolder**: WebView يُنشأ مرة (Activity context) ويُعاد استخدامه — warmup عند الإقلاع، pause/resume للصوت، destroy في MainActivity.onDestroy فقط، `key(reloadKey)` للتعافي من انهيار محرك الرسم، safe-browsing معطل للسرعة (الموقع موثوق).
5. **مخزن تحديثات حي**: extendsclass json-storage يُحدَّث بـ PUT — كل إصدار جديد يُنشر عليهما بـ versionCode أعلى (الآن 11) + حقل `downloadCenter`.
6. **الأيقونة التكيفية**: خلفية كاملة (bg) + مقدمة بالمنطقة الآمنة 58% (fg) + monochrome أبيض — تعمل مع أي قناع مشغل وMaterial You.
7. **خريطة المضيفين المختبرة (29-10-2026):** pomf2 = نصية فقط (يحجب APK وHTML حتى base64) • gofile = APK/ZIP/HTML بصفحة وسيطة (API الضيف يعمل: accounts→servers→uploadfile) • qu.ax ~30 يوم ويحجب APK/HTML • catbox/pixeldrain/krakenfiles/0x0 محجوبة أو بحسابات. **الخلاصة:** النصية→pomf2 مباشر، الثنائيات→gofile.
8. **البناء foreground فقط** بمهلة 590 ثانية. **الرفع أحياناً يفشل مؤقتاً (rate limit) — أعِد المحاولة بعد 30-120 ثانية فهو عابر.**
9. **سلسلة النشر بعد كل إصدار:** حدّث `publish_update_v134.py` → نفّذه (bins) → ارفع APK/ZIP/المركز بـ `upload_v134.py gofile` → README/Update.json/Direct-Links بـ `pomf` → حدّث هذا الملف + Direct-Links.txt → أرسل القائمة المفرزة في المحادثة.

---

## ⑤ ما طلب المستخدم دائماً (قواعد ثابتة — لا تُخالف)

1. **عند نهاية كل عمل**: قائمة روابط تحميل بصيغة «قائمة جاهزة مفرزة» وكل ملف أمامه زر (ترقيم + أقسام) في المحادثة وفي المركز و Direct-Links.txt معاً.
2. **حفظ المشروع بعد كل إصدار**: نسخة احتياطية ZIP شاملة مرفوعة + تحديث هذا الملف + README/Update.json في `download/AiPlusGLM/`.
3. **مراجعة شاملة قبل الانتهاء**: بناء نظيف بلا أخطاء = شرط التسليم.
4. **روابط دائمة وتلقائية**: المخزنان الحيان (PUT) — كل إصدار جديد versionCode أعلى.
5. README.md دائماً من ضمن الملفات القابلة للتنزيل.

## ⑥ حالة v1.3.4 عند كتابة هذا الملف (منشور ✓)

- ✅ ☀☾ المظهر يغيّر الواجهة والأيقونات في النهار والليل (نظام ألوان موحّد)
- ✅ 🌍 لغة التطبيق تغيّر كل النصوص (9 لغات كاملة) + الردود + النطق + الإدخال الصوتي
- ✅ 🛡 خدمات قوقل للحماية (ProviderInstaller) + localeConfig + معايير Play مكتملة
- ✅ ⚡ فتح فوري للواجهة الرسمية GLM-5.3-Flash (WebView دائم + تسخين + صفحة خطأ)
- ✅ 🎨 أيقونة جديدة Ai + كتب وأكواد وأبحاث — تكيفية من خارج وداخل + monochrome
- ✅ 🔤 خط Cairo متعدد الأوزان على كل الواجهة
- ✅ ✨ أيقونات مدوّرة موحّدة لكل الخدمات والأدوات
- ✅ بناء ناجح موقّع + مراجعة شاملة + رفع كامل + مخزنان حيان على code 11
- ✅ النسخة الاحتياطية الشاملة v1.3.4 (99 ملفاً) مرفوعة — المصدر محفوظ حتى لو تراجعت البيئة
